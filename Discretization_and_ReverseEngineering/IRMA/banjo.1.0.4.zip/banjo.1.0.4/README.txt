      ============================================================
      *   Banjo (Bayesian Network Inference with Java Objects)   *
      *                       Version 1.0.4                      *
      *                     16 September 2005                    *
      *                                                          *
      *          Banjo is licensed from Duke University.         *
      *       Copyright (c) 2005 by Alexander J. Hartemink.      *
      *                   All rights reserved.                   *
      ============================================================


Thank you for your interest in Banjo!  Version 1.0.4 represents our first
public release.  As we continue to improve Banjo, later versions will be
made available on the Banjo website, whose URL in September 2005 is:

http://www.cs.duke.edu/~amink/software/banjo/

If you are reading this file, you have probably successfully unzipped the
banjo.zip file.  Here's what we've included:

  README.txt    what you are currently reading

  LICENSE.txt   an overview of how Banjo may be licensed, along with the
                full text of the Non-Commercial Use License Agreement;
                please read this carefully before proceeding to use Banjo

  banjo.jar     a Java archive file containing all the compiled Banjo code,
                which you can use to run Banjo (see below)

  data/		a directory structure containing two subdirectories, one
                with an example settings file and data for learning static
                Bayesian networks; the other similarly for learning dynamic
                Bayesian networks; these will help you understand how Banjo
                works (see below for information on how to run these two
                examples)

  doc/		a directory with documentation describing Banjo; within
                this folder are PDF versions of the Banjo User Guide, the
                Banjo Developer Guide, and a Javadoc directory containing a
                description of the Banjo class APIs in browseable HTML

  src/          a directory containing Banjo's full Java source tree 

  template.txt  a template that can be filled in to create a settings file
                for using Banjo with your own data

If you have a properly installed JVM, you can see Banjo in operation by
running it with the two provided examples.  Within this directory, simply
type these two commands:

  java -jar banjo.jar settingsFile=data/static/static.settings.txt

  java -jar banjo.jar settingsFile=data/dynamic/dynamic.settings.txt

Enjoy!
