/*
 * Created on Mar 3, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.application;

import java.util.*;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.learner.*;
import edu.duke.cs.banjo.utility.*;

/**
 * Provides a simple interface to running the BANJO application.
 *
 * <p><strong>Details:</strong> <br>
 * Provides an application entry point for running the application
 * from the commandline. <br>
 * (Optional) arguments: <br>
 * 1. The name of the settings file. <br>
 * 2. The name of the directory where the settings file is found (defaults
 * to the application's (current) directory.
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 3, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class Banjo {
    
    /**
     * Simple access point to the BANJO application.
     *
     * @param args The (optional) arguments for running a search.
     * 
     */    
    public Banjo( String[] args ) {
     
        this.runSearch( args );
    }
    
    /**
     * Sets up, then initiates the execution of the BANJO application.
     *
     * @param args The (optional) arguments for running a search.
     * 
     */	
    public void runSearch(String[] args) {
	    
		String searcherChoice;
		SearcherI searcher;
		Settings settings;
		PostProcessor postProcessor;
		BanjoErrorHandler errorHandler = new BanjoErrorHandler();
				
		try {
		    
		    // Load the parameters for running the application 
			settings = new Settings( args );
		    
			// Get the user's choice for the search algorithm
		    searcherChoice = settings.getValidatedProcessParameter(
		            BANJO.SETTING_SEARCHERCHOICE );
		    
		    // ---------------------------------------
		    // Setup the searcher object
		    // ---------------------------------------
		    if ( searcherChoice == null ) {
		        
		        throw new BanjoException( BANJO.ERROR_INVALID_SEARCHER );
		    }
		    // Set-up the search based on user choice
		    else if ( searcherChoice.equalsIgnoreCase( 
		            BANJO.UI_SEARCH_SIMANNEAL )) {	
				
				searcher = new SearcherSimAnneal( settings );
			}
			else if ( searcherChoice.equalsIgnoreCase( 
			        BANJO.UI_SEARCH_GREEDY ) ) {
		
				searcher = new SearcherGreedy( settings );
			}
			else 
			{		
				
			    // UI_DEFAULT behaviour: We can't guess what searcher the user wants
			    // to use, so stop the application
			    throw new BanjoException( 
			            BANJO.ERROR_INVALID_SEARCHER );
			}

		    // ---------------------------------------
		    // Run the search
		    // ---------------------------------------
			if ( searcher == null ) {
				
			    // If the searcher choice was valid, but the associated object
			    // can't be created, we need to exit
			    throw new BanjoException( 
			            BANJO.ERROR_NULL_SEARCHER );
			}
			else {
				
			    // Note: based on the settings that govern the search process,
			    // this method may take a long time to execute. The search will
			    // provide periodic feedback about its progress, though, as well
			    // as save results to file intermittently.
			    searcher.executeSearch();
			}
			
		    // ---------------------------------------
		    // Do some post-processing
		    // ---------------------------------------
			//
			// This is a very basic example: it computes the cummulative weight of
			// an edge across the n best networks found in the search above
			//
			
			int varCount = Integer.parseInt( 
			        settings.getValidatedProcessParameter( 
			                BANJO.SETTING_VARCOUNT ) );
			int minMarkovLag = Integer.parseInt( 
			        settings.getValidatedProcessParameter( 
			                BANJO.SETTING_MINMARKOVLAG ) );
			int maxMarkovLag = Integer.parseInt( 
			        settings.getValidatedProcessParameter( 
			                BANJO.SETTING_MAXMARKOVLAG ) );
			
			// ---------------
			// Post-processing
			// ---------------
		
			postProcessor = new PostProcessor( settings );
			StringBuffer postProcessingData = new StringBuffer(
				BANJO.BUFFERLENGTH_STAT );
			
			BayesNetStructureI bayesNetStructure;
			
			if ( settings.getHighScoreStructureSet() == null ) {
			     
			    // if this set is empty then the search was not executed
			    // so it makes no sense to do any post-processing
			    return;
			}
			
			Iterator highScoreSetIterator = 
			    settings.getHighScoreStructureSet().iterator();

			int lineLength = BANJO.FEEDBACKLINELENGTH;
			String prefix = "\n";
			String newLinePlusPrefix = "\n" + BANJO.FEEDBACKDASH + " ";


			if ( highScoreSetIterator.hasNext() ) {
				
				bayesNetStructure = (BayesNetStructureI) 
						highScoreSetIterator.next();
				
				if ( BANJO.CONFIG_CREATEDOTOUTPUT ) {
					
				    postProcessingData.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength )); 
				    postProcessingData.append( StringUtil.formatRightLeftJustified( 
				            newLinePlusPrefix, "Post-processing", 
					        "DOT graphics format output", null, lineLength ) );
				    postProcessingData.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength ) + "\n" );
					
				    try {

					    postProcessingData.append( 
					            postProcessor.composeDotGraph( bayesNetStructure ) );
					}
				    catch (final BanjoException e) {

				        throw new BanjoException( BANJO.ERROR_POSTPROC_DOTOUTPUT,
				                "[Banjo] Error creating the dot output." );
					}
					catch (Exception e) {
					    
					    throw new Exception( e );
					} 
				}
				
				if ( BANJO.CONFIG_COMPUTEINFLUENCESCORES ) {
					
				    postProcessingData.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength )); 
				    postProcessingData.append( StringUtil.formatRightLeftJustified( 
				            newLinePlusPrefix, "Post-processing", 
					        "Influence scores", null, lineLength ) );
				    postProcessingData.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength )+ "\n" );
				    				    
				    try {
						
						InfluenceScorer influenceScorer = 
					    new InfluenceScorer( bayesNetStructure, settings );
						
						postProcessingData.append( 
						        influenceScorer.computeInfluenceScores( 
						                bayesNetStructure ) );
				    }
				    catch (final BanjoException e) {
					    
				        throw new BanjoException( e );
					}
					catch (Exception e) {
					    
					    throw new Exception( e );
					} 
				}

				Collection outputFileFlags = new HashSet();
				outputFileFlags.add( new Integer(BANJO.FILE_RESULTS) );
				FileUtil.writeToFile( outputFileFlags , postProcessingData );
			}
			else {
			    
			    throw new BanjoException( BANJO.ERROR_POSTPROC_INFLUENCESCORES, 
			            "(PostProcessor.composeDotGraph/computeInfluenceScores) " +
			            "Can't process the high score network." );
			}
		}
		
	    // ---------------------------------------
		// Handle any exception that occurs
	    // ---------------------------------------
		catch (final BanjoException e) {
		    
		    errorHandler.handleApplicationException( e );
		}
		catch (Exception e) {
		    
		    errorHandler.handleGeneralException( e );
		}
	}
    
    /**
     * Provides an application entry point to BANJO.
     *
     * @param args The (optional) command line arguments for running a search.
     * 
     */	
	public static void main(String[] args) {
	
		// Note that the args for this method enable us to run our
		// application in a batch-type manner (e.g., when submitting
		// "jobs" to a queue that distributes them among multiple
		// machines in a cluster). For running the application on
		// a single desktop machine, no arguments are necessary:
		// Instead the application would use the default settings file 
		// banjo.txt in the application's directory. For more details,
		// please consult the user guide.
	    Banjo banjo = new Banjo( args );
	}
}
