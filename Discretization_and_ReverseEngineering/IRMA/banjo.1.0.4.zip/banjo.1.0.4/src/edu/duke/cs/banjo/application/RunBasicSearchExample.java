/*
 * Created on Jul 13, 2005
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.application;

import edu.duke.cs.banjo.learner.*;
import edu.duke.cs.banjo.utility.*;
/**
 * 
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * "Hello World" example on how to access the Banjo classes.
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Jul 13, 2005
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class RunBasicSearchExample {

	public static void main(String[] args) {

		SearcherI searcher;
		Settings settings;
		BanjoErrorHandler errorHandler = new BanjoErrorHandler();
		
		try {
		    settings = new Settings( args );
		    searcher = new SearcherGreedy( settings );
		    searcher.executeSearch();
	    }
		catch (final BanjoException e) {
		    
		    errorHandler.handleApplicationException( e );
		}
		catch (Exception e) {
		    
		    errorHandler.handleGeneralException( e );
		}
	}
}
