/*
 * Created on Mar 10, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

import edu.duke.cs.banjo.utility.*;

import java.util.*;
import java.util.Random;

/**
 * 
 * Contains the implementation of the network. 
 *
 * <p><strong>Details:</strong> <br>
 * 
 * - Consists of a collection of objects that describe the state of the network,
 * including "parentMatrices" for various subsets of network nodes, such as the
 * addable and deleteable, mustBePresent and mustBeAbsent, initial and current
 * nodes (parents). <br>
 * - Geared towards performance: frequently trades additional storage and code
 * for execution speed. <br>
 *
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 10, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class BayesNetManager implements BayesNetManagerI {
	
	// Note: The 4 node sets are choosen in a way that they are mutually exclusive
	// which simplifies significantly many of the operations that we want to apply.
	// e.g., currentParents = mustBePresentParents + deleteableParents
	// changeableParents = deleteableParents + addableParents, etc
	
	// Initial, mandatory and disallowed node sets cannot be changed after
	// their initial assignment:
	private final EdgesAsMatrixWithCachedStatistics initialParents;
	private final EdgesAsMatrixWithCachedStatistics mustBePresentParents;
	private final EdgesAsMatrixWithCachedStatistics mustBeAbsentParents;
	
	// We use the various cached parent sets for restarts (e.g., where we don't 
	// use a previously found "good" network)
	private EdgesAsMatrixWithCachedStatistics cachedInitialParents;
	private EdgesAsMatrixWithCachedStatistics cachedAddableParents;
	private EdgesAsMatrixWithCachedStatistics cachedDeleteableParents;
	private EdgesAsMatrixWithCachedStatistics cachedCurrentParents;
	
	// Only deleteable and addable node sets can be manipulated
	// after the initial assignment:
	private EdgesAsMatrixWithCachedStatistics deleteableParents;
	private EdgesAsMatrixWithCachedStatistics addableParents;
	// Derived set of nodes that represents the entire current network structure
	// (Note: for performance reasons, we apply changes to currentParents
	// as we go)
	private EdgesAsMatrixWithCachedStatistics currentParents;
	
	// Cached score values for each of the nodes in the current network structure
	private double[] nodeScores;
	// Cached score values for the nodes affected by a bayesNetChange 
	private double[] changedNodeScores;
	
	// Internal data (actually retrievable from the parentMatrices
	// and observations, but cached for performance
	private final int varCount;
	private final int minMarkovLag;
	private final int maxMarkovLag;
	private final int[] dbnMandatoryIdentityLags;
	private final String strDbnMandatoryIdentityLags;
	private final int observationCount;

	private final int maxParentCountForRestart;
	protected final boolean restartWithRandomNetwork;

	protected Settings processData;
	
	// Used for random restarts
	protected Random rnd = new Random( System.currentTimeMillis() );
	
	// Constructor(s)
	public BayesNetManager( final Settings _processData ) throws Exception {
		
		boolean isCyclic;
		// Need a temporary variable to validate several core "final" variables
		int tmpValidationVar;
		StringTokenizer tokenizer;
		final int tokenCount;
		
		processData = _processData;
		
	    restartWithRandomNetwork = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_RESTARTWITHRANDOMNETWORK ).
		        equalsIgnoreCase( BANJO.UI_RESTARTWITHRANDOMNETWORK_YES );
	    
		if ( BANJO.DEBUG && BANJO.TRACE_BAYESNET ) {
		    
			System.out.println("\nBayesNetManager  --  Settings in constructor:");
			System.out.println( StringUtil.listSettings( 
			        _processData.getValidatedProcessParameters() ));
		}
		
		// Note: All 'settings' have been validated, and can be assumed to be of
		// the correct data type
		varCount = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_VARCOUNT ) );
		
	    observationCount = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_OBSERVATIONCOUNT ) );
				
		minMarkovLag = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_MINMARKOVLAG) );
		
		maxMarkovLag = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_MAXMARKOVLAG) );

		maxParentCountForRestart = Integer.parseInt( 
		        _processData.getValidatedProcessParameter(
		        BANJO.SETTING_MAXPARENTCOUNTFORRESTART ) );
	    				
		// Since the next setting is entirely optional, we handle it a little differently
	    strDbnMandatoryIdentityLags = _processData.getValidatedProcessParameter(
		        BANJO.SETTING_DBNMANDATORYIDENTITYLAGS);

	    // Load the optional list of mandatory parents for a dbn, going to a node 
	    // from the same node in a previous time slice
	    if ( strDbnMandatoryIdentityLags != null && 
	            maxMarkovLag > 0 && strDbnMandatoryIdentityLags.length() > 0 ) {
	        
				tokenizer = 
			        new StringTokenizer( strDbnMandatoryIdentityLags, 
			                BANJO.DEFAULT_LISTDELIMITER );
				
				tokenCount = tokenizer.countTokens();
			    dbnMandatoryIdentityLags = new int[tokenCount];
			    dbnMandatoryIdentityLags[0] = -1;

				for (int i=0; i<tokenCount; i++) {
				    
					try {
					
						tmpValidationVar = Integer.parseInt( tokenizer.nextToken() );
					}		
					catch (Exception e) {
						
					    // If the loaded value is not an integer, tell the user
						throw new BanjoException( e, 
						        BANJO.ERROR_BANJO_DEV,
						        "A 'dbnMandatoryIdentityLags' value is not an integer" +
						        "(" + strDbnMandatoryIdentityLags + ").");
					}
					if ( tmpValidationVar > 0 && 
					        tmpValidationVar >= minMarkovLag && 
					        tmpValidationVar <= maxMarkovLag ) {
					    dbnMandatoryIdentityLags[i] = tmpValidationVar;
					}
					else {
					    
					    // Can't have non-positive identity assigments; can't have 
					    // values outside the chosen min/max Markov lags:
						throw new BanjoException( 
						        BANJO.ERROR_BANJO_DEV,
						        "\n   A 'dbnMandatoryIdentityLags' (= '" + 
						        strDbnMandatoryIdentityLags +
						        "') value is either a non-positive integer," +
						        "\n   or is outside the interval of " +
						        "[minMarkovLag,maxMarkovLag]=[" + 
						        minMarkovLag + "," + maxMarkovLag + "].");					    
					}
				}
	    }
	    else {
	        
		    dbnMandatoryIdentityLags = new int[1];
		    dbnMandatoryIdentityLags[0] = -1;
		    tokenCount = 0;
	    }
		
		// Get the file names for the various parent matrices from the 
	    // initialSettings. If none are specified, we will use default 
	    // matrices (initialized with 0) below.
		String loadDirectory = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_INPUTDIRECTORY );
		String mandatoryNodesFile = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MUSTBEPRESENTEDGESFILE );
		String disallowedNodesFile = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MUSTNOTBEPRESENTEDGESFILE );
		String initialNodesFile = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_INITIALSTRUCTUREFILE );
		
		// Create (empty) matrices for the cached parent sets
		cachedInitialParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		cachedAddableParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		cachedDeleteableParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		cachedCurrentParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		
		// Load and check the set of mandatory parents
		if ( mandatoryNodesFile.length() < 1 ) 
			
			mustBePresentParents = new EdgesAsMatrixWithCachedStatistics(
			        varCount, minMarkovLag, maxMarkovLag);
		else
			
			mustBePresentParents = new EdgesAsMatrixWithCachedStatistics( varCount, 
			        minMarkovLag, maxMarkovLag,
					loadDirectory, mandatoryNodesFile);
		
		// Now that we have the mandatory parents loaded, apply the (optional)
		// assignment of mandatory parents via the dbnMandatoryIdentityLags
		if ( maxMarkovLag > 0 && tokenCount > 0 ) { 
		    
		    for (int i=0; i<tokenCount; i++) { 
		    
		        if ( dbnMandatoryIdentityLags[i] >= minMarkovLag && 
		                dbnMandatoryIdentityLags[i] <= maxMarkovLag ) {
		        	
				    for (int j=0; j<varCount; j++) {
				        
				        // Indicate that a node j is dependent on node j at a previous
				        // time slice, namely dbnMandatoryIdentityLags[i]
					    mustBePresentParents.setEntry(j,j,
					            dbnMandatoryIdentityLags[i]);
				    }
		        }
		    }
			    
		    if (BANJO.DEBUG && BANJO.TRACE_BAYESNETMANAGER ) {
		        
		        System.out.println( "Mandatory matrix with identity for lag " + 
		                dbnMandatoryIdentityLags[0] + ":" );
		        System.out.println( 
		                mustBePresentParents.toStringWithIDandParentCount() );
		    }
		}
				
		isCyclic = mustBePresentParents.isCyclicBFS();
		if ( isCyclic ) { 
		    
			throw new BanjoException(
			        BANJO.ERROR_CYCLEINMANDATORYEDGES, 
			        "\nMandatory edges file '" 
			        + mandatoryNodesFile +
			        "' contains a cycle.");
		}
		
		// Load the set of disallowed parents
		if (disallowedNodesFile.length() < 1 ) {
			
			mustBeAbsentParents = new EdgesAsMatrixWithCachedStatistics(
			        varCount, minMarkovLag, maxMarkovLag);
		}
		else {
			
			mustBeAbsentParents = new EdgesAsMatrixWithCachedStatistics( varCount, 
			        minMarkovLag, maxMarkovLag,
					loadDirectory, disallowedNodesFile);
		}
		
		// This method makes sure that no node is available to be a parent to itself:
		mustBeAbsentParents.omitNodesAsOwnParents();
		mustBeAbsentParents.omitExcludedParents();

		// Sanity-check: the mustBeAbsentParents and mustBePresentParents cannot overlap
		if ( mustBePresentParents.hasOverlap( mustBeAbsentParents ) ) {
		    
			throw new BanjoException(
			        BANJO.ERROR_CYCLEINMANDATORYEDGES, 
			        "\nInconsistent input: The 'must be present' and 'must be absent' edges" + 
			        "cannot overlap. Please correct your data!");
		}
		
		// Now load the initial parent configuration:
		if (initialNodesFile.length() < 1 ) {
			
		    // If no file is specified, we set the initial parents to the empty network
			initialParents = new EdgesAsMatrixWithCachedStatistics(
			        varCount, minMarkovLag, maxMarkovLag);
		}
		else {
			
			initialParents = new EdgesAsMatrixWithCachedStatistics( varCount, 
			        minMarkovLag, maxMarkovLag,
					loadDirectory, initialNodesFile );
			
			// Here we need to make sure that the user supplied file doesn't
			// contain a cycle
			isCyclic = initialParents.isCyclicBFS();
			if ( isCyclic ) { 
			    
				throw new BanjoException(
				        BANJO.ERROR_CYCLEININITIALPARENTS, 
				        "\nInitial parents file '" 
				        + initialNodesFile +
				        "' contains a cycle.");
			}
		}


	    // The initial parents need to include the mandatory parents:
		initialParents.setToCombinedMatrices( 
	            initialParents, mustBePresentParents );
				
		// Create the various parent sets
		deleteableParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		addableParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		currentParents = new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		
		// Now compute the initial parent sets of the bayesnet
		// Note that a "cleaned" version of the initialParents will be cached
		// in the cachedInitialParents container after this call 
		initializeBayesNet( initialParents );
		
		// Now cache the parent sets for later use in some restart schemes
		cachedAddableParents.assignMatrix( addableParents );
		cachedDeleteableParents.assignMatrix( deleteableParents );
		cachedCurrentParents.assignMatrix( currentParents );		
		
		//------------------------------
		// To start working on the Ancestor tracking problem again, start by 
		// uncommenting the next block, and set the flag in the globals to run the 
		// appropriate cycle checker.
		//------------------------------
		
//		// The current nodes are simply the mandatory and the deleteable nodes
//
//		
//	    System.out.println("After computing Current Nodes:");
//	    System.out.println(this.getCurrentNetworkNodes().
//			toStringWithIDandParentCount());
//	    
//	    System.out.println("After computing Ancestor Nodes:");
//	    System.out.println(currentAncestors.toStringWithIDs());
//
//	    currentAncestors.restoreAncestors( this, currentParents );
//
//	    System.out.println("After resetting Ancestor Nodes:");
//	    System.out.println(currentAncestors.toStringWithIDs());

		//*** For debugging/testing: 
		if (BANJO.DEBUG && BANJO.TRACE_BAYESNETMANAGER) {
			
		    System.out.println("After loading Mandatory Edges:");
		    System.out.println(mustBePresentParents.toStringWithIDandParentCount());
			
		    System.out.println("After loading Disallowed Edges:");
		    System.out.println(mustBeAbsentParents.toStringWithIDandParentCount());
			
		    System.out.println("After loading Initial Edges:");
		    System.out.println(initialParents.toStringWithIDandParentCount());
			
		    System.out.println("After computing Deleteable Edges:");
		    System.out.println(deleteableParents.toStringWithIDandParentCount());
			
		    System.out.println("After computing Addable Edges:");
		    System.out.println(addableParents.toStringWithIDandParentCount());
			
		    System.out.println("After computing Current Edges:");
		    System.out.println( 
		            this.getCurrentParents().toStringWithIDandParentCount());
		    
//		    System.out.println("After computing Ancestor Nodes:");
//		    System.out.println(currentAncestors.toStringWithIDs());
			
		    // Part 1: combined matrix needs to be identical to getCurrentParents()
		    EdgesAsMatrixWithCachedStatistics combinedMatrix = 
					new EdgesAsMatrixWithCachedStatistics(varCount,
		            minMarkovLag, maxMarkovLag);
		    EdgesAsMatrixWithCachedStatistics[] combinedMatrixSet = 
					new EdgesAsMatrixWithCachedStatistics[3];
		    combinedMatrixSet[0] = mustBePresentParents;
		    combinedMatrixSet[1] = initialParents;
		    combinedMatrixSet[2] = deleteableParents;
			System.out.println("After computing COMBINED Nodes:");
			combinedMatrix.setToCombinedMatrices( combinedMatrixSet );
			System.out.println( combinedMatrix.toStringWithIDandParentCount());
			// Now check that the getCurrentParents() matrix is identical 
			// with the just computed matrix
			if ( !combinedMatrix.hasIdenticalEntries( this.getCurrentParents() )) {
			    
			    throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			            "Combined matrices don't match currentParents.");
			} else {
			    
			    System.out.println( "Combined matrices match the currentParents." );
			}
			
			// Part 2: this matrix should now produce a matrix with all 1's except
			// for the main diagonal
		    combinedMatrix = new EdgesAsMatrixWithCachedStatistics(varCount,
		            minMarkovLag, maxMarkovLag);
		    combinedMatrixSet = new EdgesAsMatrixWithCachedStatistics[4];
		    combinedMatrixSet[0] = mustBePresentParents;
		    combinedMatrixSet[1] = initialParents;
		    combinedMatrixSet[2] = deleteableParents;
		    combinedMatrixSet[3] = addableParents;
			System.out.println("After computing COMBINED Nodes:");
			combinedMatrix.setToCombinedMatrices( combinedMatrixSet );
			System.out.println( combinedMatrix.toStringWithIDandParentCount());
		}
		
		// Prep the cachedNodeScores
		nodeScores = new double[varCount];
		changedNodeScores = new double[varCount]; 
	}

	public void initializeBayesNet() throws Exception {
	    
		// Start with the standard procedure for creating an initial network,
	    // using the last cached parents as the starting set of parents	
	    addableParents.assignMatrix( cachedAddableParents );
	    deleteableParents.assignMatrix( cachedDeleteableParents );
	    currentParents.assignMatrix( cachedCurrentParents );
		
		// Get ready to apply a random "perturbation" of the edge configuration
		if ( restartWithRandomNetwork ) {
		    
	        BayesNetChangeI bayesNetChange = new BayesNetChange();
			
			int randomNodeID;
			int randomParentID;
			int randomParentLag;
			int randomParentIndex;
			boolean isCyclic;

			int randomParentCount;
			int addableParentCount;
			int currentParentCount;
			int[][] parentList;
					
			// Assign a random number (limited by maxParentCountForRestart) of parents
			// to each node
			for (int nodeID=0; nodeID<varCount; nodeID++) {
					    
			    // See how many parents we can potentially add for nodeID
			    addableParentCount = addableParents.getParentCount( nodeID );
			    // Check how many parents the node already has (from dbnMandatoryLags
			    // or mustBePresent edges)
			    currentParentCount = currentParents.getParentCount( nodeID );
			    // Pick a random number for the number of parents to add, taking
			    // the currentParents and the maxParent limit into account
			    if ( maxParentCountForRestart - currentParentCount > 0 ) {
			    
			        randomParentCount = rnd.nextInt( 
			            maxParentCountForRestart - currentParentCount ) + 1;
			    }
			    else {
			        
			        randomParentCount = 0;
			    }			        
			    
			    if ( randomParentCount > addableParentCount ) {
			        
			        randomParentCount = addableParentCount;
			    }
			    
			    if ( randomParentCount > 0 ) {
			     
				    // Get the list of parents for nodeID (lag defaults to 0)
				    parentList = addableParents.getCurrentParentIDlist( nodeID , 0 );
				    
				    for ( int j=0; j<randomParentCount; j++ ){
				        
				        // Pick a parent node at random from the list
				        // Note that won't repeat the process if we end up with a 
				        // cyclic graph. We try to find a valid parent with some effort, 
				        // though, by tracking which parents have already been used.
				        int i = 1;
				        do {
				            // Pick an index between  0 and addableParentCount-1:
				            randomParentIndex = rnd.nextInt( addableParentCount );
				            i++;
				        } while ( parentList[randomParentIndex][0] == -1 
				                && i < addableParentCount );
				        
				        if ( parentList[randomParentIndex][0] != -1 ) {
				            
				            randomParentID = parentList[randomParentIndex][0];
				            randomParentLag = parentList[randomParentIndex][1];
	
				            // now flag the already selected parent so it won't get
				            // used in the future
				            parentList[randomParentIndex][0] = -1;
			            	                
				            // Now change the network
						    bayesNetChange.updateChange( 
						            nodeID, randomParentID, randomParentLag, 
						            BANJO.CHANGETYPE_ADDITION );
						    
						    this.applyChange( bayesNetChange );
							isCyclic = this.getCurrentParents().isCyclicBFS();
							if ( isCyclic ) this.undoChange( bayesNetChange );
				        }
				    }
			    }
			}
	    }		
	}
	
	// This method is designed to enable restarts with different initial parent data,
	// e.g., when an already found "good" network is to be used for the restart
	public void initializeBayesNet( 
	        final EdgesAsMatrixWithCachedStatistics parentsToAssign ) 
			throws Exception {
		
	    // The initial parents (which we'll cache in cachedInitialParents) need to
	    // include the mustBePresentParents
	    cachedInitialParents.setToCombinedMatrices( 
	            parentsToAssign, mustBePresentParents );
	    // .. but cannot include any mustBeAbsentParents
	    cachedInitialParents.subtractMatrix( mustBeAbsentParents );
	    
	    // By now, the cachedInitialParents is the "cleaned" set of parents
	    	    
	    // The deleteableParents are based on the cachedInitialParents, but cannot
	    // contain any mustBePresentParents
	    deleteableParents.assignMatrix( cachedInitialParents );
	    deleteableParents.subtractMatrix( mustBePresentParents );
			
		// The addableParents are also based on the complement of the
	    // cachedInitialParents, and they cannot contain any mustBeAbsentParents
		addableParents.computeComplementaryMatrix( 
		        cachedInitialParents, mustBeAbsentParents );
		cachedAddableParents.assignMatrix( addableParents );
		
		// The current set of nodes is derived from all deleteable plus the 
	    // mandatory edges
		currentParents.setToCombinedMatrices( 
		        deleteableParents, mustBePresentParents );
	}
		
	// ApplyChange works in concerto with UndoChange:
	// Whenever a BayesNetChange is suggested by the Proposer, ApplyChange provides
	// an updated BayesNet for a) checking for cycles, and b) computing the score
	// in the Evaluator. If the BayesNetChange is not kept, the UndoChange method
	// below will revert the applied change, and restore the network.
	public void applyChange( final BayesNetChangeI bayesNetChange ) 
			throws Exception {
		
	    int currentNodeID = bayesNetChange.getCurrentNodeID();
	    int parentNodeID = bayesNetChange.getParentNodeID();
	    int parentNodeLag = bayesNetChange.getParentNodeLag();
	    			
		double nodeScore;
		try {
			if ( bayesNetChange.getChangeStatus() 
			        != BANJO.CHANGESTATUS_READY ) {
				
				// Since this case should never happen, we throw an exception
			    // if it does
			    throw new BanjoException( 
			            BANJO.ERROR_INVALIDCHANGESTATUS,
			            "(BayesNetManager.applyChange) " +
			            "Can only apply a BayesNetChange with READY status, " +
			            "\nbut encountered status value = '" +
						bayesNetChange.getChangeStatus() + "'.");
			}
				
			// 
			switch ( bayesNetChange.getChangeType() ){
			// NOTE: At this point, the validity of the change will have been checked
			// so we can apply it without further verification
			case BANJO.CHANGETYPE_ADDITION:
				
				addableParents.deleteParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				deleteableParents.addParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				
				// hjs 6/29/04 Update current parents set also 
				// (solves performance issue!)
				currentParents.addParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				break;
				
			case BANJO.CHANGETYPE_DELETION:
				
				addableParents.addParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				deleteableParents.deleteParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				
				// hjs 6/29/04 Update current parents set also 
				// (solves performance issue!)
				currentParents.deleteParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				break;
				
			case BANJO.CHANGETYPE_REVERSAL:
				
				// The lag of the parent node must be 0 (i.e., the same as for the
				// current node)

//				System.out.print( "Reversing " + currentNodeID + " and " + parentNodeID );
//			System.out.print( " -  Addable parents counts '" + addableParents.getParentCount(currentNodeID) 
//			        + "' and '" + addableParents.getParentCount(parentNodeID) + "'" );
//			System.out.println( " -  Deleteable parents counts '" + deleteableParents.getParentCount(currentNodeID) 
//			        + "' and '" + deleteableParents.getParentCount(parentNodeID) + "'" );
//
//			System.out.println( "  Addable parent lists '" + StringUtil.listNodes( addableParents.getCurrentParentIDlist(currentNodeID,0) ) 
//			        + "' and '" + StringUtil.listNodes( addableParents.getCurrentParentIDlist(parentNodeID,0) ) + "'" );
//			System.out.println( "  Deleteable parent lists '" + StringUtil.listNodes( deleteableParents.getCurrentParentIDlist(currentNodeID, 0)) 
//			        + "' and '" + StringUtil.listNodes( deleteableParents.getCurrentParentIDlist(parentNodeID, 0) ) + "'" );
//				
			
				// First do the deletion ..
				addableParents.addParent( currentNodeID, parentNodeID, 0 );
				deleteableParents.deleteParent( currentNodeID, parentNodeID, 0 );
				// hjs 6/29/04
				currentParents.deleteParent( currentNodeID, parentNodeID, 0 );
				
				// .. then the addition
				addableParents.deleteParent( parentNodeID, currentNodeID, 0 );
				deleteableParents.addParent( parentNodeID, currentNodeID, 0 );
				// hjs 6/29/04
				currentParents.addParent( parentNodeID, currentNodeID, 0 );
								
				break;
				
			default:
				
			    // Since this case should never happen, we throw an exception 
			    // if it does
				throw new BanjoException(
				        BANJO.ERROR_INVALIDCHANGETYPE, 
				        "(BayesNetManager.applyChange) " +
				        "Can not continue due to invalid BayesNetChange " +
				        "type.\n(Encountered type value = " + 
						bayesNetChange.getChangeType() + ").");
			}
			
			// Update the change status
			bayesNetChange.setChangeStatus(BANJO.CHANGESTATUS_APPLIED);
		}
		catch (BanjoException e) {
		    
		    throw new BanjoException( e );
		}
		catch (Exception e) {

		    throw new BanjoException( e, 
		            BANJO.ERROR_BANJO_DEV, 
		            "(BayesNetManager.applyChange) " + e.getMessage() );
		}
	}
	
	// UndoChange works in concerto with the ApplyChange method. Whenever a
	// suggested BayesNetChange is rejected by the Decider (or if it results
	// in a cycle), UndoChange reverts the bayesNetManager back to the previous 
	// state.
	public void undoChange(BayesNetChangeI bayesNetChange) throws Exception {
	    
	    try {
	        
			if ( bayesNetChange.getChangeStatus() != 
			    		BANJO.CHANGESTATUS_APPLIED ) {
				
			    throw new BanjoException( 
			            BANJO.ERROR_INVALIDCHANGESTATUS,
		        	"(BayesNetManager.undoChange) " +
		        	"Search stopped due to invalid BayesNetChange " +
		        	"status. (Encountered status = " + 
					bayesNetChange.getChangeStatus() + ").");
			}
			
		    final int currentNodeID = bayesNetChange.getCurrentNodeID();
		    final int parentNodeID = bayesNetChange.getParentNodeID();
		    final int parentNodeLag = bayesNetChange.getParentNodeLag();
	
		    // Set bayesNetChange status back to READY:
		    bayesNetChange.setChangeStatus( BANJO.CHANGESTATUS_READY );
		    
		    switch ( bayesNetChange.getChangeType()){
			case BANJO.CHANGETYPE_ADDITION:
				
			    addableParents.addParent( 
			            currentNodeID, parentNodeID, parentNodeLag );
				deleteableParents.deleteParent(
				        currentNodeID, parentNodeID, parentNodeLag );
				currentParents.deleteParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				break;
				
			case BANJO.CHANGETYPE_DELETION:
				
			    addableParents.deleteParent(
			            currentNodeID, parentNodeID, parentNodeLag );
				deleteableParents.addParent(
			            currentNodeID, parentNodeID, parentNodeLag );
				currentParents.addParent( 
				        currentNodeID, parentNodeID, parentNodeLag );
				break;
				
			case BANJO.CHANGETYPE_REVERSAL:
				
			    // first UNDO the deletion
			    addableParents.deleteParent(
			            currentNodeID, parentNodeID, 0 );
				deleteableParents.addParent(
				        currentNodeID, parentNodeID, 0 );
				currentParents.addParent( 
				        currentNodeID, parentNodeID, 0 );
				// then UNDO the addition
			    addableParents.addParent(
			            parentNodeID, currentNodeID, 0 );
				deleteableParents.deleteParent(
				        parentNodeID, currentNodeID, 0 );
				currentParents.deleteParent( 
				        parentNodeID, currentNodeID, 0 );			
				break;
				
			default:
				
				// Since this case should never happen
				throw new BanjoException(
				        BANJO.ERROR_INVALIDCHANGETYPE, 
				        "(BayesNetManager.undoChange) " +
				        "Search stopeed due to invalid BayesNetChange " +
				        "type.\n(Encountered type = " + 
						bayesNetChange.getChangeType() + ").");
			}
			
			// Update the change status
		    // hjs 12/22/04 Instead of setting the status to 'undone', reset it to
		    // 'ready' (needed for global search, where the apply/undo changes)
			bayesNetChange.setChangeStatus( BANJO.CHANGESTATUS_READY );
		}
		catch (BanjoException e) {
		    
		    throw new BanjoException( e );
		}
		catch (Exception e) {
		    
		    throw new BanjoException( 
		            e, BANJO.ERROR_BANJO_DEV, 
		            "(BayesNetManager.undoChange) " 
		            + e.getMessage() );
		}
	}
	
	/**
	 * @return Returns the currentParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getCurrentParents() {
		return currentParents;
	}
	
	/**
	 * @return Returns the addableParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getAddableParents() {
		return addableParents;
	}

	/**
	 * @return Returns the deleteableParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getDeleteableParents() {
		return deleteableParents;
	}

	/**
	 * @return Returns the mustBeAbsentParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getMustBeAbsentParents() {
		return mustBeAbsentParents;
	}

	/**
	 * @return Returns the mustBePresentParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getMustBePresentParents() {
		return mustBePresentParents;
	}
	
    /**
     * @return Returns the min Markov lag.
     */
    public int getMinMarkovLag() {
        return minMarkovLag;
    }
	/**
	 * @return Returns the max Markov lag.
	 */
	public final int getMaxMarkovLag() {
		return maxMarkovLag;
	}

	/**
	 * @return Returns the variable count.
	 */
	public final int getVarCount() {
		return varCount;
	}
	
	/**
	 * @return Returns the cachedNodeScores.
	 */
	public double[] getNodeScores() {
		return nodeScores;
	}

	/**
	 * @param nodeScores The nodeScores to set.
	 */
	public void setNodeScores(double[] nodeScores) {
		this.nodeScores = nodeScores;
	}
	
	// get an individual node score
	/**
	 * @return Returns the score of the specified node.
	 * @param nodeID The nodeID of the node.
	 */
	public double getNodeScore(int nodeID) {
		return this.nodeScores[nodeID];
	}
	// set an individual node score
	/**
	 * @param nodeID The nodeID of the node.
	 * @param nodeScore The nodeScore of the node.
	 */
	public void setNodeScore(int nodeID, double nodeScore) {
		this.nodeScores[nodeID] = nodeScore;
	}

	// get an individual node score
	/**
	 * @return Returns the changedNodeScore of the specified node.
	 * @param nodeID The nodeID of the node.
	 */
	public double getChangedNodeScore(int nodeID) {
		return this.changedNodeScores[nodeID];
	}
	// set an individual node score
	/**
	 * @param nodeID The nodeID of the node.
	 * @param nodeScore The changedNodeScore of the node.
	 */
	public void setChangedNodeScore(int nodeID, double nodeScore) {
		this.changedNodeScores[nodeID] = nodeScore;
	}		
	
	/**
	 * @return Returns the changedNodeScores.
	 */
	public double[] getChangedNodeScores() {
		return changedNodeScores;
	}

	/**
	 * @param changedNodeScores The changedNodeScores to set.
	 */
	public void setChangedNodeScores(double[] changedNodeScores) {
		this.changedNodeScores = changedNodeScores;
	}

	/**
	 * @return Returns the initialParents.
	 */
	public EdgesAsMatrixWithCachedStatistics getInitialParents() {
		return initialParents;
	}

    /**
     * @param currentParents The currentParents to set.
     */
    public void setCurrentParents(EdgesAsMatrixWithCachedStatistics currentParents) throws Exception {
        //this.currentParents = (EdgesAsMatrixWithCachedStatistics) currentParents;
        this.currentParents.assignMatrix( currentParents );
    }
}
