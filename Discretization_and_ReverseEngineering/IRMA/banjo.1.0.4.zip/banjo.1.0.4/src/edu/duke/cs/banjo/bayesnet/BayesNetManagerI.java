/*
 * Created on Apr 14, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

/**
 * 
 * Documents the interface for the BayesNetManager.
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 14, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public interface BayesNetManagerI {

	public abstract void initializeBayesNet() throws Exception;
	public abstract void initializeBayesNet( 
	        EdgesAsMatrixWithCachedStatistics initialMatrix ) 
			throws Exception;
	
	public abstract void applyChange(
	        BayesNetChangeI bayesNetChange ) throws Exception;
	public abstract void undoChange(
	        BayesNetChangeI bayesNetChange ) throws Exception;
	
	public abstract EdgesAsMatrixWithCachedStatistics getCurrentParents();
	public abstract void setCurrentParents(
	        EdgesAsMatrixWithCachedStatistics currentParents ) 
			throws Exception;
	       
	/**
	 * @return Returns the addableNodes.
	 */
	public abstract EdgesAsMatrixWithCachedStatistics getAddableParents();
	/**
	 * @return Returns the deleteableNodes.
	 */
	public abstract EdgesAsMatrixWithCachedStatistics getDeleteableParents();
	/**
	 * @return Returns the mustBeAbsentParents.
	 */
	public abstract EdgesAsMatrixWithCachedStatistics getMustBeAbsentParents();
	/**
	 * @return Returns the mustBePresentParents.
	 */
	public abstract EdgesAsMatrixWithCachedStatistics getMustBePresentParents();
	/**
	 * @return Returns the nodeScores.
	 */
	public abstract double[] getNodeScores();
	/**
	 * @return Returns the score of the specified node.
	 * @param nodeID The nodeID of the node.
	 */
	public abstract double getNodeScore(int nodeID);
	/**
	 * @param nodeID The nodeID of the node.
	 * @param nodeScore The nodeScore of the node.
	 */
	public abstract void setNodeScore(int nodeID, double nodeScore);
	/**
	 * @return Returns the changedNodeScore of the specified node.
	 * @param nodeID The nodeID of the node.
	 */
	public abstract double getChangedNodeScore(int nodeID);
	/**
	 * @param nodeID The nodeID of the node.
	 * @param nodeScore The changedNodeScore of the node.
	 */
	public abstract void setChangedNodeScore(int nodeID, double nodeScore);
}