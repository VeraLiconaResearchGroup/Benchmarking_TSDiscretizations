/*
 * Created on Apr 13, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

import edu.duke.cs.banjo.utility.*;

/**
 * Stores a basic BayesNet structure (where the use of a BayesNetManager is redundant).
 *
 * <p><strong>Details:</strong> <br>
 * - Used for storing the N-best network structures.  <br>
 * - Similar to the BayesNetManager, but without the overhead of tracking multiple
 * subsets of nodes (parents). <br>
 * - Uses internal knowledge about the EdgesAsMatrix class for performance reasons.
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 13, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class BayesNetStructure implements Comparable, BayesNetStructureI {

	protected EdgesAsMatrix networkStructure;
	protected double networkScore;
	protected long searchLoopIndex;
	
	public BayesNetStructure( BayesNetStructureI bayesNetStructure, 
			double networkScore, long searchLoopIndex 
			) throws Exception {
			    
		// "Clone" the bayesnet structure that is being passed in:	    
		this.networkScore = networkScore;
		this.searchLoopIndex = searchLoopIndex;
		int[][][] tmpMatrix = bayesNetStructure.getNetworkStructure().getMatrix();
		EdgesAsMatrix edgeMatrix = (EdgesAsMatrix) bayesNetStructure.getNetworkStructure();

		this.networkStructure = new EdgesAsMatrix( 
		        edgeMatrix.varCount, edgeMatrix.minMarkovLag, 
		        edgeMatrix.maxMarkovLag );
		
		networkStructure.assignMatrix( bayesNetStructure.getNetworkStructure() );
	}
		
	public BayesNetStructure( EdgesAsMatrix networkStructure, 
			double networkScore, long searchLoopIndex ) throws Exception {
		
		this.networkStructure = (EdgesAsMatrix) networkStructure.clone();
		if ( networkStructure == null ) {
			
			// Cloning failed:
			throw new BanjoException(
			        BANJO.ERROR_BANJO_DEV, 
			        "(BayesNetStructure.setNetworkStructure) Cloning failed.");
		}

		this.networkScore = networkScore;
		this.searchLoopIndex = searchLoopIndex;
	
		if (BANJO.DEBUG && BANJO.TRACE_BAYESNETSTRUCTURE ) {
			System.out.println("BayesNetStructure (EdgeM constr.)  " +
					"-- i=" + searchLoopIndex +
					", Initial highscore: " + this.networkScore );
		}
	}
	
	public void assignBayesNetStructure( EdgesI networkStructure, 
			double networkScore, long searchLoopIndex ) throws Exception {
		
		this.networkStructure = (EdgesAsMatrix) networkStructure.clone();
		if ( networkStructure == null ) {
			
			// Cloning failed:
			throw new BanjoException(
			        BANJO.ERROR_BANJO_DEV, 
			        "(BayesNetStructure.setNetworkStructure) Cloning failed.");
		}

		this.networkScore = networkScore;
		this.searchLoopIndex = searchLoopIndex;
	}
	
	/**
	 * @return Returns the networkStructure.
	 */
	public EdgesI getNetworkStructure() {
		return networkStructure;
	}
	
	public int compareTo( Object otherStructure ){
		
	    // Note: bullet-proofing really needs to be done outside of this method,
	    // e.g., before we attempt to insert an object into our n-best list...
	    // I'm leaving the debug code in here, although it's highly redundant
		
	    if ( BANJO.DEBUG ) {
	        
			// Needs to be an actual object
			assert ( otherStructure != null );
			
			// and needs to be of the same class
			assert ( otherStructure.getClass() == this.getClass() );
	    }

		// At this point we now dare to make our blind jump:
		BayesNetStructure otherBayesNetStructure = (BayesNetStructure) otherStructure;
		
		// Comparison as implemented places top score in first slot in treeset used
		// for storing the ordered collection
		if ( this.networkScore > otherBayesNetStructure.networkScore
		        + BANJO.NUMERICSCORETOLERANCE ) {
		    
			return -1;
		}
		else if ( this.networkScore < otherBayesNetStructure.networkScore
		        - BANJO.NUMERICSCORETOLERANCE ) {
		    
			return 1;
		}
		else {
		    
		    if ( this.networkStructure.hasIdenticalEntries( 
		            	otherBayesNetStructure.networkStructure )) {
		        
		        return 0;
		    }
		    else {
		        
		        // Whether we return +1 or -1 doesn't really matter; it simply 
		        // determines the order in which the 2 different networks with
		        // the same score are stored
		        return 1;
		    }
		}
	}

	// Output in string form, using the Proprietary format
	public String toString() {

		final int varCount = this.networkStructure.varCount;
		final int minMarkovLag = this.networkStructure.minMarkovLag;
		final int maxMarkovLag = this.networkStructure.maxMarkovLag;
	    
		StringBuffer strStructure = new StringBuffer( varCount * varCount );
		StringBuffer strParentList;
		int parentCount;
		final String strBlanks = new String("              ");
				
		strStructure.append( varCount );

		for (int i=0; i<varCount; i++) {
			
			parentCount = 0;
			strParentList = new StringBuffer( varCount );
			
			strStructure.append( "\n" );
			// Format in column (assume we have less than 99 variables
			if ( i < 10 ) strStructure.append( " " );
			//// Change for <999 variables:
			////if ( i < 100 ) strStructure.append( " " );
			////if ( i < 10 ) strStructure.append( " " );
			strStructure.append( i );

			for (int k=0; k<maxMarkovLag+1; k++) {
				for (int j=0; j<varCount; j++) {
								
				    if ( networkStructure.getEntry(i,j,k) == 1 ) {
	
						strParentList.append( " " );
						strParentList.append( j );
						parentCount++;
					}
				}

				if ( maxMarkovLag > 0 ) {
					// Check if we can omit printing empty "sets"
					// (Not ideal output for nodes that have no parents at all)
					//if ( parentCount > 0 ) {
						
						strStructure.append( "   " );
						//strStructure.append( "lag=" );
						strStructure.append( k );
	 					strStructure.append( ":   " );
						strStructure.append( parentCount );
						strStructure.append( strParentList );
						// Column-oriented formating (this will still be "off"
						// for long parent lists, but for short lists it's useful)
						// Of course, this issue will eventually go away anyway
						// when we support other formats
						if ( strParentList.length() < strBlanks.length() ) {
						    strStructure.append( 
						            strBlanks.substring( strParentList.length() ));
						}
						
						// Reset for next lag level
						parentCount = 0;
						strParentList = new StringBuffer( varCount );
					//}
				}
				else {
					
					// Output is simpler when we have no lag
					strStructure.append( " " );
					strStructure.append( parentCount );
					strStructure.append( strParentList );			
				}
			}
		}
		
		return strStructure.toString();
	}
	
	/**
	 * @param networkStructure The networkStructure to set.
	 */
	public void setNetworkStructure(EdgesI networkStructure) 
			throws Exception {
				
		// Need to copy entire object for storing
		
		this.networkStructure = (EdgesAsMatrix) networkStructure.clone();
		if ( networkStructure == null ) {
	
			// Cloning failed:
			//System.out.println("BayesNetStructure  --  Cloning failed.");
			throw new BanjoException(
			        BANJO.ERROR_BANJO_DEV, 
			        "(BayesNetStructure.setNetworkStructure) Cloning failed.");
		}		
	}

	/**
	 * @return Returns the networkScore.
	 */
	public double getNetworkScore() {
		return networkScore;
	}

	/**
	 * @param networkScore	The score (of the stored network) to set.
	 */
	public void setNetworkScore(double networkScore) {
		this.networkScore = networkScore;
	}

    /**
     * @return Returns the searchLoopIndex.
     */
    public long getSearchLoopIndex() {
        return searchLoopIndex;
    }
}
