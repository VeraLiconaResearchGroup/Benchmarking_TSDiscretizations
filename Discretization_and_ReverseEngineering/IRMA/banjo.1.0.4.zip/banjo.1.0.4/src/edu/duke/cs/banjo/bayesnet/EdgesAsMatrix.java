/*
 * Created on Jun 1, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

import edu.duke.cs.banjo.utility.*;
/**
 * Contains the basic adjacency matrix implementation.
 *
 * <p><strong>Details:</strong> <br>
 * 
 *  - <strong>Important:</strong>
 * For performance reasons, several classes (e.g., BayesNetStructure, Hash classes)
 * use internal knowledge about this class; i.e., we are intentionally breaking the 
 * encapsulation of the internal data. We need to do this because it is extremely 
 * inefficient to iterate through loops with "getEntry" or "setEntry" calls. 
 * There are numerous instances of such loops throughout the core objects of 
 * the applications.
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Jun 1, 2004 
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 * 
 */
public class EdgesAsMatrix implements Cloneable, EdgesI {

	// Stores the parent configuration for the variables in a matrix such that
	// - dim 1 refers to the variable's index
	// - dim 2 refers to the parent variable's index
	// - dim 3 refers to the lag (determined by the maxMarkovLag of the 
    //			Markov chain) of the parent
    //
	// Remember that maxMarkovLag 0 means dimension #3 of array/matrix is 1
    
	// hjs 11/29/04 After profiling, decide to break encapsulation and allow public 
    // access: this eliminates a large number of getEntry calls in the proposer class
    public int[][][] matrix;
    	
	protected final int varCount;
	protected final int maxMarkovLag;
	protected final int minMarkovLag;

	public EdgesAsMatrix( final int varCount, 
	        final int minMarkovLag, 
	        final int maxMarkovLag ) {
	    
		// Store the variable count and the maxMarkovLag for easy access
		this.varCount = varCount;
		this.maxMarkovLag = maxMarkovLag;
		this.minMarkovLag = minMarkovLag;
		
		// Create the matrix. Note that we may waste storage by sizing the
		// array dimension for the Markov lag to maxMarkovLag, and not to the 
		// difference between maxMarkovLag and minMarkovLag. However, we gain
		// a vast reduction in complexity (all loops would have to be adjusted by
		// the difference between the min and max order).
		matrix = new int[varCount][varCount][maxMarkovLag+1];
	}
	
	/**
	 * @return Returns the matrix (reference).
	 */
	public int[][][] getMatrix() {
		return matrix;
	}
	/**
	 * @param matrix The matrix to set (reference assignment only).
	 */
	public void setMatrix(final int[][][] matrix) {
		this.matrix = matrix;
	}
	
	// Assign the values to the values of another matrix 
	// Expensive, so avoid if possible. Also: dangerous because
	// the dimensions need to match. Better to use the polymorphic
	// method that follows this one
	/**
	 * @param matrix The matrix to set (assignment of matrix values;
	 * no reference assignment).
	 */
	public void assignMatrix(final int[][][] matrix) {
	    
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
					this.matrix[i][j][k] = matrix[i][j][k];
				}				
			}
		}
	}
	
	public void assignMatrix(final EdgesI edgeMatrix) throws Exception {
		    
		// Create a reference to the edgeMatrix, so we don't
		// have to loop through getEntry calls (performance shortcut)
		int[][][] tmpEdgeMatrix = edgeMatrix.getMatrix();
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					this.matrix[i][j][k] = tmpEdgeMatrix[i][j][k];
				}				
			}
		}
	}

	
	public void assignMatrix(final EdgesAsMatrix edgeMatrix) throws Exception {
		
		// Create a reference to the edgeMatrix, so we don't
		// have to loop through getEntry calls
		int[][][] tmpEdgeMatrix = edgeMatrix.getMatrix();
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					this.matrix[i][j][k] = tmpEdgeMatrix[i][j][k];
				}				
			}
		}
	}
	
	// Access any individual entry in the parent matrix
	public int getEntry(final int varIndex, final int parentVarIndex, final int lag) {
		
	    return matrix[varIndex][parentVarIndex][lag];
	}
	
	// Unrestricted assignment of values in matrix (see EdgesAsMatrixWithCachedStatistics subclass)
	public void setEntry(final int varIndex, final int parentVarIndex, final int lag,
	        final int newValue) throws Exception {
		
	    matrix[varIndex][parentVarIndex][lag] = newValue;
	}

	public boolean hasIdenticalEntries(final EdgesI otherMatrix){
		  
	    // Define a matrix as performance shortcut:
	    int[][][] tmpMatrix = otherMatrix.getMatrix();
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					if ( this.matrix[i][j][k] != tmpMatrix[i][j][k] ) {
					    
						return false;
					}
				}				
			}
		}	
		return true;
	}

	public boolean hasIdenticalEntries(final EdgesAsMatrix otherMatrix){
		  
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					if ( this.matrix[i][j][k] != otherMatrix.matrix[i][j][k] ) {
						return false;
					}
				}				
			}
		}	
		return true;
	}
	
	////////////////////////
	// The next 2 methods are added temporarily: only used in influence score
	// computation (as of 5/10/05)
	////////////////////////
	// Computes the list of parent ID's for the current node "nodeID"
	// "Overload" for DBN's: Note that the second argument is actually redundant,
	// but comes in handy as a visual reminder that we are in the DBN case
	// (the parent lists are only computed for "current" nodes (i.e. the lag is
	// always 0)
	public int[][] getCurrentParentIDlist( final int nodeID, final int lag ) {
		
		int[][] parentIDlist;
		int intParentCount = getParentCount( nodeID );
		// TODO: for performance, may not want to create an object each time
		parentIDlist = new int[intParentCount][2];
		
		int parentIndex = 0;
		
		// Go through the parent nodes for the node with id=nodeID
		for (int i=0; i<varCount && parentIndex < intParentCount; i++) {
			for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
				
				if ( matrix[nodeID][i][k] == 1 ) {
				    
				    // Per convention, [index][0] holds the nodeID
					parentIDlist[parentIndex][0] = i;
					
					// and [index][1] holds the lag
					parentIDlist[parentIndex][1] = k;
					parentIndex++;
				}
			}
		}
		
		return parentIDlist;
	}
	
	protected int getParentCount( final int nodeID ) {
	    
	    int parentCount = 0;
		
		// Count the parent nodes for the node with id=nodeID
		for (int i=0; i<varCount; i++) {
			for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
				
				if ( matrix[nodeID][i][k] == 1 ) {
				    
					parentCount++;
				}
			}
		}
	    
	    return parentCount;
	}
	////////////////////////
	
	public Object clone() {
	    
		// Note: This only does shallow cloning
		try {
		    
			EdgesI cloned = (EdgesI) super.clone();
		    			
			return cloned;
		}
		catch ( Exception e ) {
		    
		    System.out.println(
		            "(EdgesAsMatrix.clone) cloning failed. Returning null object.");
		    
			return null;
		}
	}

    /**
     * @return A custom string representation for a set of edges.
     */
	public String toString() {
		
		StringBuffer tmpStr = new StringBuffer( varCount * varCount );
		
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
					
					tmpStr.append( matrix[i][j][k] );
					
					// Add delimiter between (parent) entries
					tmpStr.append( " " );					
				}
				// Add delimiter between blocks of "markovLags"
				tmpStr.append( "\t" );
			}
			// Add delimiter between variables
			tmpStr.append( "\n" );
		}
		return tmpStr.toString();
	}

	/**
     * @return A special string representation for a set of edges that includes the
     * IDs for the variables.
     */
	public String toStringWithIDs() {
		
		StringBuffer tmpStr = new StringBuffer( varCount * varCount );
		// Add header: (need to make formatting more generic, but ok for quick test 
	    tmpStr.append( "    " ); 
		for (int i=0; i<varCount; i++) {
		    tmpStr.append( i );
		    tmpStr.append( "  " ); 
			if (i<10) tmpStr.append( " " ); }
		tmpStr.append( "\n" );
		for (int i=0; i<varCount; i++) {
		    tmpStr.append( i );
		    tmpStr.append( ": " );
			if (i<10) tmpStr.append( " " );
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
					
				    tmpStr.append( matrix[i][j][k] );
					// Add delimiter between (parent) entries
					tmpStr.append( "   " );					
				}
				// Add delimiter between "maxMarkovLag lines"
				tmpStr.append( "\t" );
			}
			// Add delimiter between variables
			tmpStr.append( "\n" );
		}
		return tmpStr.toString();
	}
	
	/**
     * @return A special string representation for a set of edges in a 
     * simplified (proprietary) format (the same one that we use for
     * input and output of networks).
     */
	public String toStringAsStructure() {
		
		// Output in string form, using the proprietary format
		StringBuffer strStructure = new StringBuffer( varCount * varCount );
		StringBuffer strParentList = new StringBuffer( 2*varCount );
		int parentCount;

		strStructure.append( varCount );
		
		for (int i=0; i<varCount; i++) {
			
			parentCount = 0;
			strParentList = new StringBuffer("");
			for (int j=0; j<varCount; j++) {
			    
				//for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
				
					if ( matrix[i][j][0] == 1 ) {
						strParentList.append( " " );
						strParentList.append( j );
						parentCount++;
					}
				}
				strStructure.append( "  \t  " );
			}
			
			strStructure.append( "\n" );
			strStructure.append( i );
			strStructure.append( " " );
			strStructure.append( parentCount );
			strStructure.append( strParentList );
		}
		 
		return strStructure.toString();
	}
	

	/**
     * @return Another special string representation for a set of edges: This
     * one prints all entries of the matrix.
     */
	public String toStringAsTest() {
		
		// Output in string form, using the Proprietary format
		StringBuffer strStructure = new StringBuffer( varCount * varCount );
		StringBuffer strParentList = new StringBuffer( 2*varCount );
		StringBuffer strFormatted = new StringBuffer( 2*varCount );
		String strTmp = new String();
		int parentCount;

		for (int i=0; i<varCount; i++) {
			
			parentCount = 0;
			strParentList = new StringBuffer( 2*varCount );
			strFormatted = new StringBuffer( 2*varCount );
			
			for (int j=0; j<varCount; j++) {
			    for (int k=0; k<maxMarkovLag+1; k++) {
				
					if ( matrix[i][j][0] == 1 ) {
						strParentList.append( " " );
						strParentList.append( j );
						parentCount++;
					}
			    }
				strStructure.append( "  \t  " );
			}
			
			//strFormatted.append( "   " );
			strFormatted.append( i );
			strFormatted.append( ":" );
			strFormatted.append( parentCount );
			strFormatted.append( strParentList );
			strTmp = strFormatted.toString();
			strTmp = StringUtil.fillSpaces( strTmp, 9 );

			strStructure.append( strTmp );
			strStructure.append( " " );
		}
		 
		return strStructure.toString();
	}
}
