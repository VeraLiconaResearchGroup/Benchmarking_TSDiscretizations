/*
 * Created on Mar 3, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

import edu.duke.cs.banjo.utility.*;

import java.io.*;
import java.util.*;

/**
 * Contains the data structures built around an adjacency matrix-approach for storing 
 * the network structure.
 *
 * <p><strong>Details:</strong> <br>
 * 
 * - Contains a number of "counts" and other auxilliary variables associated 
 * with the adjacency matrix, for efficient access to matrix data required by the 
 * core objects.  <br>
 * - Example:  (3 variables, called 0,1, and 2, of max. Markov lag 1) <br>
 * 0 1 0 &nbsp&nbsp&nbsp	0 0 1	&nbsp&nbsp&nbsp
 * 		- variable 0 has variable 1 as parent of lag 0, 
 * 			and variable 2 as parent of lag 1 <br>
 * 1 0 1 &nbsp&nbsp&nbsp 0 0 0	&nbsp&nbsp&nbsp
 * 		- variable 1 has variables 0 and 2 as parents of lag 0, 
 * 			and no parents of lag 1 <br>
 * 0 0 0 &nbsp&nbsp&nbsp 0 1 0	&nbsp&nbsp&nbsp
 * 		- variable 2 has no parents of lag 0, 
 * 			and variable 1 as parent of lag 1 <br>
 * - Can (optionally) be loaded from structure file.
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 3, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class EdgesAsMatrixWithCachedStatistics extends EdgesAsMatrix 
		implements Cloneable {
		
	// Remember that maxMarkovLag 0 means dimension of array/matrix is 1
	
	// Store the parentCounts for the variables (maintained transparently
	// when parentMatrix is updated); this is simply the number of 1's in
	// the row corresponding to a variable
	private int[] parentCount;
	// Store the number of all parent nodes (again: performance-wise it's
	// better to maintain this value that to recompute it for every loop)
	private int combinedParentCount;
	
	// Store the parentIDs for a node. We need this array as a temporary 
	// storage so we can efficiently compute cycles (and being able to apply
	// a bayesNetChange before it takes effect in the actual network)
	private int[] parentIDs;
	// Additional storage containers for computing cycles
	private int[] ancestorSet;
	private int[] nodesVisited;
	private int[] nodesToVisit;
	
	// Info where cycle was encountered;
	private int cycleAtNode = -1; 
	
	public EdgesAsMatrixWithCachedStatistics(
	        final int varCount, 
	        final int minMarkovLag, 
	        final int maxMarkovLag) {
		
	    // hand off the low level stuff
		super(varCount, minMarkovLag, maxMarkovLag);
						
		// Create the parentCount vector
		parentCount = new int[varCount];

		// Allocate the containers used for computing cycles 
		parentIDs = new int[varCount];
		ancestorSet = new int[varCount];
		nodesVisited = new int[varCount];
		nodesToVisit = new int[varCount];
		
		// Initialize the matrix and the parentCount vector
		initMatrix();
	}
	
	public EdgesAsMatrixWithCachedStatistics( 
	        final int varCount, 
	        final int minMarkovLag, 
	        final int maxMarkovLag, 
			final String directory, 
			final String fileName) throws Exception {
		
		super(varCount, minMarkovLag, maxMarkovLag);

	    loadStructureFile(directory, fileName );
	}
		
	// Initialize the parent matrix to all 0's, indicating "no parent" relationships.
	public void initMatrix() {
		
		for (int i=0; i<varCount; i++) {

		    // Set all parentCounts to 0
			parentCount[i] = 0;
			
			// Set all matrix entries to 0
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
				    
					matrix[i][j][k] = 0; 
				}
			}
		}
		// and set the grand total
		combinedParentCount = 0;
	}
	
	// Initialize the parent matrix to a specified value (typically, to all '1's)
	public void initMatrix( final int valueToInitTo ) {

		combinedParentCount=0;

		// More verbose, but better performance by checking on the value first
		if ( valueToInitTo == 0 ) {
		    
			for (int i=0; i<varCount; i++) {
	
				parentCount[i] = 0;
				
				// Set the matrix entries and adjust the parent counts
				for (int j=0; j<varCount; j++) {
					for (int k=0; k<maxMarkovLag+1; k++) {
					    
						matrix[i][j][k] = valueToInitTo;
					}
				}
			}
		}
		else {
		    
		    for (int i=0; i<varCount; i++) {
			
				parentCount[i] = 0;
				
				// Set the matrix entries and adjust the parent counts
				for (int j=0; j<varCount; j++) {
					for (int k=0; k<maxMarkovLag+1; k++) {
					    
						matrix[i][j][k] = valueToInitTo;
						    
							parentCount[i]++;
							combinedParentCount++;
					}
				}
			}
		}
	}
	
	public void assignMatrix( 
	        final EdgesAsMatrixWithCachedStatistics matrixToAssign ) 
			throws Exception {
			            
		if (this.varCount == matrixToAssign.varCount && 
				this.maxMarkovLag == matrixToAssign.maxMarkovLag) {
			
		    for (int i=0; i<varCount; i++) {

			    // Assign the parentCounts
				parentCount[i] = matrixToAssign.parentCount[i];
				
				// Assign the matrix entries
				for (int j=0; j<varCount; j++) {
					for (int k=0; k<maxMarkovLag+1; k++) {
					    
						matrix[i][j][k] = matrixToAssign.matrix[i][j][k]; 
					}
				}
			}
		    
			// Assign the grand total
			combinedParentCount = matrixToAssign.combinedParentCount;
		}
		else {
		    
			// Flag as internal error - matrix dimensions don't match
		    // (this should never happen..)
			throw new BanjoException(
			        BANJO.ERROR_BANJO_DEV, 
			        "(EdgesAsMatrixWithCachedStatistics.assignMatrix) " +
			        	"Dimensions of matrices don't match!");		
		}
	}	

	public void subtractMatrix( 
	        final EdgesAsMatrixWithCachedStatistics matrixToSubtract ) 
			throws Exception {
        
	    int[][][] tmpMatrix = matrixToSubtract.getMatrix();
	    			
	    for (int i=0; i<varCount; i++) {

		    // Set the parentCounts
			//parentCount[i] = matrixToSubtract.parentCount[i];
	        parentCount[i] = matrixToSubtract.getParentCount(i);
			
			// Set the matrix entries
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
				    
				    if ( tmpMatrix[i][j][k] == 1 ) {
				        
				        if ( matrix[i][j][k] == 1 ) {
				            
				            parentCount[i]--;
				            combinedParentCount--;
				            matrix[i][j][k] = 0;
				        }
					    // "else case": the original matrix keeps its value, and
					    // there is no need to adjust any parent count
				    }
				    // "else case": subtract 0, so no change
				}
			}
		}
	}
	
	// Load an "adjacency matrix" from a file
	// --------------------------------------
	// Example of a dbn structure to load:
    // Note that the "separation characters" need to be blank spaces!
    //
	//20
	// 0   0:   0                 1:   2 0 7          
	// 1   0:   0                 1:   1 1            
	// 2   0:   0                 1:   3 0 1 2        
	// 3   0:   0                 1:   2 2 3   
	// ...
	// 19  0:	0                 1:   1 18

	private void loadStructureFile(
	        final String directory, final String fileName ) 
			throws Exception {
		
		try {
			
			File dataFile = new File(directory, fileName);
			FileReader fileReader = null;
			BufferedReader bufferedReader = null;
			
			if (!dataFile.exists()) {
			    				
				throw new BanjoException( 
				        BANJO.ERROR_MISSING_STRUCTUREFILE, 
				        "\n *** (EdgesAsMatrixWithCachedStatistics.loadFromFile) " +
				        "Cannot find the structure file: '" + fileName + "'" +
				        		" in directory '" + directory + " '." );
			}

			bufferedReader = new BufferedReader(new FileReader(
					directory + "/" + fileName));
					
			int i = 0;
			
			// -------------------------
			// Set up the matrix itself	
			// -------------------------
			
			// First check the loaded data for consistency
			String varCountReadFromFile = bufferedReader.readLine();
			if ( Integer.parseInt( varCountReadFromFile ) != varCount ) {
			    
			    throw new BanjoException( BANJO.ERROR_INCONSISTENTNODES,
			            "The variable count in the input file '" 
			            + directory + "/" + fileName 
			            + "' (= " + varCountReadFromFile + ")" +
			            "\n  does not match the varCount " +
			            "given in the settings file (= " +
			            varCount + ").");
			}
			
			// Need to create the parent array:
			this.parentCount = new int[varCount];
			
			ancestorSet = new int[varCount];
			parentIDs = new int[varCount];
			nodesToVisit = new int[varCount];
			nodesVisited = new int[varCount];
			
			// Now it's on to populating the values:
			initMatrix();
			
			
			if ( maxMarkovLag > 0 ) {
			    
				// Example of a dbn structure to load:
			    //
				//20
				// 0   0:   0                 1:   2 0 7          
				// 1   0:   0                 1:   1 1            
				// 2   0:   0                 1:   3 0 1 2        
				// 3   0:   0                 1:   2 2 3   
				// ...
				// 19  0:	0                 1:   1 18
							
				Integer intParentCount;
				Integer intParentID;
				Integer intMarkovLag;
				//
				String strParentCount;
				String strMarkovLag;
				String strParentID;
				// Only used for testing/debugging:
				String processedChars;
				
				int k;
				int variablesRead = 0;
				char currentChar;
				for (int linesRead=0; linesRead < varCount; linesRead++) {
					
					String line = bufferedReader.readLine();
	//				if ( line == null || variablesRead > varCount ) break;
	//				variablesRead++;
					
					k = 0;
					i++;
								
					// parse data char by char:	
					int j =0;			
				
					// clear any leading blanks
					processedChars = "";
					while( line.charAt(j) == ' ' ) { 
						processedChars += line.charAt(j);
						j++;
					} 
					
					// Skip past the variable index
					processedChars = "";
					while( line.charAt(j) != ' ' ) { 
				
						processedChars += j+ ": " + line.charAt(j);
						j++;
					}
					
					// Now process the different lags based on the min and max
					// Markow orders as entered by the user in the settings file
					for (int lag=0; lag<maxMarkovLag+1; lag++ ) {
					    
						// Skip any blanks between variable index and first Markov lag
						processedChars = "";
						while( line.charAt(j) == ' ' ) { 
							processedChars += line.charAt(j);
							j++;
						} 
						
						// Get the MarkovLag
						strMarkovLag = "";
						while( line.charAt(j) != ':' ) { 
					
						    strMarkovLag += line.charAt(j);
							j++;
						}
						intMarkovLag = new Integer(strMarkovLag);
		
						// skip past the ':'
						j++;
						
						// skip past blanks between first Markov lag and parentCount
						processedChars = "";
						while( line.charAt(j) == ' ' ) { 
							processedChars += line.charAt(j);
							j++;
						} 
						
						// Find the parentCount
						processedChars = "";
					
						strParentCount = "";
						while ( j<line.length() ) {
							if (line.charAt(j) == ' ' ) break;
							strParentCount += line.charAt(j);
							j++;
						}
						intParentCount = new Integer(strParentCount);
						
						// Now set the actual parents for this node:
						// -----------------------------------------
						
						if ( lag >= minMarkovLag ) {
						    
							// Add the list of parents:
							for (int n=1; n<=intParentCount.intValue(); n++) {
			
								/// Skip any blanks before the first parent ID
								while( line.charAt(j) == ' ' ) j++; 
			
								strParentID = "";
								while ( j < line.length() ) {
									if (line.charAt(j) == ' ') break;
									strParentID += line.charAt(j);
									j++;
								}
								intParentID = new Integer( strParentID );
								
								// assign to matrix:
								this.setEntry( i-1, intParentID.intValue(), lag, 1 );
							}
						}				
					}
				}
			}
			else {				    
				
				// Example of a static network structure to load:
			    //
				//20
				// 0   2 0 7          
				// 1   1 1            
				// 2   3 0 1 2        
				// 3   2 2 3 
				// ...
				// 19  1 18         
				//

				Integer parentCnt;
				Integer parent;
				String parentCt;
				String parentID;
				// Only used for testing/debugging:
				String processedChars;
				
				int k;
				int variablesRead = 0;
				char currentChar;
				for (int linesRead=0; linesRead < varCount; linesRead++) {
					
					String line = bufferedReader.readLine();
//					if ( line == null || variablesRead > varCount ) break;
//					variablesRead++;
					
					k = 0;
					i++;
								
					// parse data char by char:	
					int j =0;			
				
					// clear any leading blanks
					processedChars = "";
					while( line.charAt(j) == ' ' ) { 
						processedChars += line.charAt(j);
						j++;
					} 
					
					// Skip past the variable index
					processedChars = "";
					while( line.charAt(j) != ' ' ) { 
				
						processedChars += j+ ": " + line.charAt(j);
						j++;
					} 
	
					// skip past blanks between variable index and parentCount
					processedChars = "";
					while( line.charAt(j) == ' ' ) { 
						processedChars += line.charAt(j);
						j++;
					} 
					
					// Find the parentCount
					processedChars = "";
				
					parentCt = "";
					while ( j<line.length() ) {
						if (line.charAt(j) == ' ' ) break;
						parentCt += line.charAt(j);
						j++;
					}
					parentCnt = new Integer(parentCt);
					
					// Now set the actual parents for this node:
					// -----------------------------------------
					
					// Add the list of parents:
					for (int n=1; n<=parentCnt.intValue(); n++) {
	
						/// Skip any blanks before the first parent ID
						while( line.charAt(j) == ' ' ) j++; 
	
						parentID = "";
						while ( j < line.length() ) {
							if (line.charAt(j) == ' ') break;
							parentID += line.charAt(j);
							j++;
						}
						parent = new Integer(parentID);
						
						// assign to matrix:
						this.setEntry(i-1, parent.intValue(), 0);
					}					
				}
			}
		}
		catch (IOException e) {
			   
			    throw new Exception( e );
			}		
		catch (BanjoException e) {

		    if ( e.getMessage().length() == 0 ) {
				throw new BanjoException( e, 
				        BANJO.ERROR_BANJO_DEV, 
				        "\n  (EdgesAsMatrixWithCachedStatistics.loadFromFile) - " +
				        "BanjoException loading file \n  '" +
				        fileName + "' from directory '" + directory + "'.");
		    }
		    else
		        throw new BanjoException( e );
		}		
		catch (Exception e) {
			   
			throw new BanjoException( e, 
			        BANJO.ERROR_BANJO_DEV, 
			        "\n(EdgesAsMatrixWithCachedStatistics.loadFromFile) - " +
			        "General error loading file \n   '" +
			        fileName + "' from directory '" + directory + "'." );
		}	
	}
	
	// This method can be used in the automatic validation of a series of results 
	// such as the collection of (n-best) networks.
	public void reconstructMatrix( 
	        final String bayesNetStructureString,
	        final int varCount, 
	        final int minMarkovLag, 
	        final int maxMarkovLag ) 
			throws BanjoException {
    
		String checkStructureString = "";
	    try {
	
	        // The lag=0 part is identical to the reconstructMatrixStatic method
		    if ( maxMarkovLag == 0 ) {
		        
		        reconstructMatrixStatic( bayesNetStructureString, 
		                varCount, minMarkovLag, maxMarkovLag );
		    }
		    else {
		        
			    int readVarCount;
			    int currentNodeID;
				int parentNodeID;
			    int parentLag;
			    int markovLag;
			    String strMarkovLag = "";
				int intParentCount;
		
				StringTokenizer strTok = 
			        new StringTokenizer( bayesNetStructureString );
				
				// The first line of data contains the variable count
				readVarCount = Integer.parseInt( strTok.nextToken() );
				
				// Double-check against the parameter for the variable count
				if ( varCount != readVarCount ) {
				    
				    throw new BanjoException( BANJO.ERROR_BANJO_DEV,
				            "(EdgesAsMatrixWithCachedStatistics.reconstructMatrix) " +
				            "Read-in var count" +
				            " doesn't match the internal parameter.");
				}
	
				// Set up the matrix and the parentCounts (need to have values assigned)
				for (int i=0; i<readVarCount; i++ ) {
					for (int j=0; j<readVarCount; j++ ) {
						for (int k=minMarkovLag; k<maxMarkovLag+1; k++ ) {
				
						    matrix[i][j][k] = 0;
							parentCount[i] = 0;
						}
					}
				}
				// and set the grand total
				combinedParentCount = 0;
				
				checkStructureString = "\nChecking Structure: \n" + readVarCount;
				
				// Recall the structure form (example):
				//20
				// 0   0:   0                 1:   2 0 7          
				// 1   0:   0                 1:   1 1            
				// 2   0:   0                 1:   3 0 1 2        
				// 3   0:   0                 1:   2 2 3   
				// ...
				// 19  0:	0                 1:   1 18
				for (int i=0; i<readVarCount; i++ ) {
				    
				    currentNodeID = Integer.parseInt( strTok.nextToken() );
				    checkStructureString += "\n" + currentNodeID + " ";
			    
				    for (int k=0; k<maxMarkovLag+1; k++) {
					    
					    strMarkovLag = strTok.nextToken();
					    // Split off the ":" that is part of the lag (=MarkovLag)
					    strMarkovLag = strMarkovLag.substring( 
					            0, strMarkovLag.length()-1 ); 
					    markovLag = Integer.parseInt( strMarkovLag );
					    checkStructureString += "  " + markovLag + ": ";
					    
					    // Get the parent count for this lag
					    intParentCount = Integer.parseInt( strTok.nextToken() );
					    checkStructureString += intParentCount + " ";
				        
					    for (int j=0; j<intParentCount; j++) {
				        
					        parentNodeID = Integer.parseInt( strTok.nextToken() );
						    checkStructureString += parentNodeID + " ";
						    
						    matrix[currentNodeID][parentNodeID][markovLag] = 1;
						    parentCount[currentNodeID] ++;
							combinedParentCount++;
					    }
				    }   
				}
		    }
		}
		catch (BanjoException e) {
		    
		    throw new BanjoException( e );
		}
		catch (Exception e) {
	
		    System.out.println( "Reconstructed BayesNetStructure:\n" + 
		            checkStructureString );
		    e.printStackTrace();
			throw new BanjoException( e, 
			        BANJO.ERROR_BANJO_DEV, 
			        "(EdgesAsMatrixWithCachedStatistics.reconstructMatrix) -- \n  " +
			        "could not create parent matrix from bayesNetManager structure\n" + 
			        bayesNetStructureString );
		}		
	}

	// For static bayesNets only:
	public void reconstructMatrixStatic( 
	        String bayesNetStructureString, 
	        int varCount, int minMarkovLag, int maxMarkovLag ) 
					throws BanjoException {
	    
		String checkStructureString = "";
	    try {

	        //// Static BN only (lag=0)
		    if ( maxMarkovLag == 0 ) {
			    
			    int readVarCount;
			    int currentNodeID;
				int parentNodeID;
				int intParentCount;
		
		        
				StringTokenizer strTok = 
			        new StringTokenizer( bayesNetStructureString );
				
				readVarCount = Integer.parseInt( strTok.nextToken() );
				
				// Double-check the read-in variable count
				if ( varCount != readVarCount ) {
				    
				    throw new BanjoException( BANJO.ERROR_BANJO_DEV,
				            "(EdgesAsMatrixWithCachedStatistics." +
				            "reconstructMatrixStatic) Read-in var count" +
				            " doesn't match the internal parameter.");
				}
				
				for (int i=0; i<readVarCount; i++ ) {
					for (int j=0; j<readVarCount; j++ ) {
				
					    matrix[i][j][0] = 0;
						parentCount[i] = 0;
					}
				}
				// and set the grand total
				combinedParentCount = 0;
				
				checkStructureString = "\nChecking Structure: \n" + readVarCount;
				
				for (int i=0; i<readVarCount; i++ ) {
				    
				    currentNodeID = Integer.parseInt( strTok.nextToken() );
				    checkStructureString += "\n" + currentNodeID + " ";
				    
				    intParentCount = Integer.parseInt( strTok.nextToken() );
				    checkStructureString += intParentCount + " ";
				    
				    for (int j=0; j<intParentCount; j++) {
				        
				        parentNodeID = Integer.parseInt( strTok.nextToken() );
					    checkStructureString += parentNodeID + " ";
					    
					    matrix[currentNodeID][parentNodeID][0] = 1;
					    parentCount[currentNodeID] ++;
						combinedParentCount++;
				    }   
				}
		    }
		    else {

		        // Developer message only:
		        throw new BanjoException( BANJO.ERROR_BANJO_DEV, 
		                "DEV: (reconstructMatrixStatic) was called for " +
		                "max. Markov lag > 0.");
		    }
		}
		catch (BanjoException e) {
		    
		    throw new BanjoException( e );
		}
		catch (Exception e) {
	
		    System.out.println( "Reconstructed BayesNetStructure:\n" + 
		            checkStructureString );
		    e.printStackTrace();
			throw new BanjoException( e, 
			        BANJO.ERROR_BANJO_DEV, 
			        "(EdgesAsMatrixWithCachedStatistics." +
			        "reconstructMatrixStatic) -- \n  " +
			        "could not create parent matrix from bayesNetManager structure\n" +
			        bayesNetStructureString );
		}		
	}
	
	public void setToCombinedMatrices( 
	        EdgesAsMatrixWithCachedStatistics matrix1, 
	        EdgesAsMatrixWithCachedStatistics matrix2 )
			throws Exception {
        
		int combinedEntry;
		
	    combinedParentCount = 0;
	    int[][][] tmpMatrix1 = matrix1.getMatrix();
	    int[][][] tmpMatrix2 = matrix2.getMatrix();
	    
	    for (int i=0; i<varCount; i++) {

			parentCount[i] = 0;
			
			// Set the matrix entries
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					
					combinedEntry = tmpMatrix1[i][j][k] + 
							tmpMatrix2[i][j][k];
					
					if ( combinedEntry >= 1 ) {

						matrix[i][j][k] = 1;						    
					    parentCount[i]++;
					    combinedParentCount++;
					}
					else {
					    
					    matrix[i][j][k] = 0;
					}
				}
			}
		}
	}
		
	// Utility method:
	// This method is only used for double-checking (within a "trace" run)
	//// Note: hjs 1/27/05: this won't likely run anymore, because the setEntry
	// call will cause an exception (trying to set a value to an equal existing value)
	public void setToCombinedMatrices( 
	        final EdgesAsMatrixWithCachedStatistics[] matricesToCombine ) 
			throws Exception {
		
		int matrixCount = matricesToCombine.length;
		int combinedEntry;
		this.initMatrix();
				
		// then combine the entries (based on our underlying design we know
		// that our matrices are "mutually exclusive", i.e., we don't need
		// to check if both matrices have a 1 in the same position):
		for (int i=0; i<varCount; i++) {			
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					combinedEntry = 0;
					for (int m=0; m < matrixCount; m++) {
						combinedEntry += matricesToCombine[m].getEntry(i,j,k); 
					}
					// 2005/1/12 Note: this call will not work due with the current
					// implementation of setEntry. Will need to rewrite similarly 
					// to code for combining 2 matrices.
					// Simple fix:
					if ( combinedEntry > 0 ) combinedEntry = 1;
					this.setEntry(i,j,k,combinedEntry);
				}}}
		
	}
	
	// Check if a matrix overlaps any entry with another matrix (typically used
	// to verify that the "mustBePresent" and "mustBeAbsent" matrices are
	// properly specified by the user)
	public boolean hasOverlap( final EdgesAsMatrixWithCachedStatistics matrix ){
	    
	    boolean hasOverlap = false;

		int[][][] tmpMatrix = matrix.getMatrix();
		
		for (int i=0; i<varCount; i++) {
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {

				    if ( this.matrix[i][j][k] + tmpMatrix[i][j][k] == 2 ) { 
				        
				        hasOverlap = true;
				        break;
				    }				    
				}
			}
		}
	    return hasOverlap;
	}
	
	// This is a special method that computes a "complementary" adjacency
	// matrix (relative to both supplied arguments)
	public void computeComplementaryMatrix(
	        final EdgesAsMatrixWithCachedStatistics matrix1,
			final EdgesAsMatrixWithCachedStatistics matrix2) 
			throws Exception {
		
		int combinedEntry;
		
		this.combinedParentCount = 0;
		for (int i=0; i<varCount; i++) {
		    
		    // Set all parentCounts to 0
			this.parentCount[i] = 0;

			int[][][] tmpMatrix1 = matrix1.getMatrix();
			int[][][] tmpMatrix2 = matrix2.getMatrix();
		    
			for (int j=0; j<varCount; j++) {
				for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
					
				    // Check the value of:
				    // 1 - matrix1.matrix[i][j][k] - matrix2.matrix[i][j][k]
				    if ( tmpMatrix1[i][j][k] == 1 || 
				            tmpMatrix2[i][j][k] == 1 ) {
					    
					    this.matrix[i][j][k] = 0;
					}
					else {

						this.matrix[i][j][k] = 1;
					    this.parentCount[i]++;
					    this.combinedParentCount++;
					}
				}
			}
		}
	}
		
	// Computes the list of parent ID's for the current node "nodeID"
	// "Overload" for DBN's: Note that the second argument is actually redundant,
	// but comes in handy as a visual reminder that we are in the DBN case
	// (the parent lists are only computed for "current" nodes (i.e. the lag is
	// always 0)
	public int[][] getCurrentParentIDlist( final int nodeID, final int lag ) {
		
		int[][] parentIDlist;
		int intParentCount = parentCount[nodeID];
		// TODO: for performance, may not want to create an object each time
		parentIDlist = new int[intParentCount][2];
		
		int parentIndex = 0;
		
		// Go through the parent nodes for the node with id=nodeID
		for (int i=0; i<varCount && parentIndex < intParentCount; i++) {
			for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
				
				if ( matrix[nodeID][i][k] == 1 ) {
				    
				    // Per convention, [index][0] holds the ID of a node
					parentIDlist[parentIndex][0] = i;
					
					// and [index][1] holds the lag
					parentIDlist[parentIndex][1] = k;
					parentIndex++;
				}
			}
		}
		
		return parentIDlist;
	}
		
	// Get the number of parents for the variable with given index (var ID)
	public int parentCount(final int varIndex) {
		return parentCount[varIndex];
	}
	
	// Query if a variable has another variable as a parent
	public boolean isParent(
	        final int varIndex, 
	        final int parentVarIndex, 
	        final int lag) {
	    
		return (matrix[varIndex][parentVarIndex][lag] == 1);
	}

	// Set any individual entry in the parent matrix to 1
	public void setEntry(
	        final int varIndex, 
			final int parentVarIndex, 
			final int lag) throws Exception {
				
		// need to check if value is already 1 (this should not be
		// the case, but better to be safe)
		if (matrix[varIndex][parentVarIndex][lag] == 0){
		    
			parentCount[varIndex] ++;
			combinedParentCount++;
		}
		else { // else: may want to throw an exception!
						
		    // This should never occur:
		    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
		            "DEV: Parent value of 0 expected, but not found: \n" +
		            "");
		}
		
		// Now make the parent assignment
		matrix[varIndex][parentVarIndex][lag] = 1;
	}

	// Set an individual entry in the parent matrix
	// This is a convenient method when merging sets of parent nodes. 
	public void setEntry(
	        final int varIndex, 
			final int parentVarIndex, 
			final int lag, 
			final int newValue) throws Exception {
		
		// It is the calling routine's task to assure that we only get 0 or 1
		// as values! Otherwise we complain by throwing an Exception
		
		// Update the adjaceny matrix
		int oldValue = matrix[varIndex][parentVarIndex][lag];
		matrix[varIndex][parentVarIndex][lag] = newValue;
		
		// Update the parentCount only when the value changes
		if ( newValue == 1 && oldValue == 0 ) {
		    
			parentCount[varIndex] ++;
			combinedParentCount++;
		}
		else if ( newValue == 0 && oldValue == 1 ) {
			
			parentCount[varIndex] --;
			combinedParentCount--;
		}
		// Note: this case can happen, e.g., in the initializing of a matrix (assigning
		// a 0 value to a value that is already 0), but we assert here that the calling
		// routine takes care of this!!
		else {
			
		    // this should never occur:
		    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
		            "DEV: (EdgesAsMatrixWithCachedStatistics.SetEntry'2) " +
		            "encountered invalid entry: " +
		            "the new value equals the old value in the " +
		            "internal representation.");
		}			
	}
	
	public void addParent(
	        final int varIndex, 
			final int parentVarIndex,
			final int lag ) throws Exception {
		 
	    // Note that we throw an exception if the current value of the matrix indicates
	    // that there is already a parent
		
		if (matrix[varIndex][parentVarIndex][lag] == 0) {
		    
			matrix[varIndex][parentVarIndex][lag] = 1;
			parentCount[varIndex] ++;
			combinedParentCount++;
		}
		else {
			
		    // this should never occur:
		    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
		            "DEV: (EdgesAsMatrixWithCachedStatistics.AddParent) " +
					"Error in adding parent: \n" +
					"Parent id=" + parentVarIndex + ", lag=" + lag +
					" is already a parent of " +
					"id=" + varIndex );
		}
	}
	
	public void deleteParent(
	        final int varIndex, 
			final int parentVarIndex, 
			final int lag) throws Exception {
					    
		if ( matrix[varIndex][parentVarIndex][lag] == 1 ) {
		    
			matrix[varIndex][parentVarIndex][lag] = 0;
			parentCount[varIndex] --;
			combinedParentCount--;
		}
		else {
			
		    // this should never occur:
		    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
		            "DEV: " + "(EdgesAsMatrixWithCachedStatistics.DeleteParent) " +
					"Error in deleting parent: \n" +
					"Node id=" + varIndex + " does not have parent " +
					"id=" + parentVarIndex + ", lag=" + lag );
		}
	}
		
	public void reverseRelation(final int varIndex, final int lagVar, 
			final int parentVarIndex, final int lagParent) throws Exception {

		// Check that the lags are the same:
		// (they have to be in the same time slice for this to make sense)
		
		if ( lagVar != lagParent && ( lagVar != 0 || lagParent != 0 ) ) {
		    
		    throw new BanjoException(
		            BANJO.ERROR_LAGSNOTMATCHING, 
		            "Can only reverse an edge between nodes of lag 0.");
		}
		
		// Remove the parent for the specified node
		if (( matrix[varIndex][parentVarIndex][lagParent] == 0 ) 
			|| ( matrix[parentVarIndex][varIndex][lagVar] == 1 )) {

		    // throw an exception: the data is not consistent with 
			// the requested operation
		    throw new BanjoException(
	            BANJO.ERROR_LAGSNOTMATCHING, "DEVELOPER problem: " +
	            "Encountered inconsitent data when trying to reverse an edge.");
		}
		else {
		    
		    // First remove the <edge from the node to the parent>
			matrix[varIndex][parentVarIndex][lagParent] = 0;
			parentCount[varIndex] --;
			
			// then add the <edge from the parent to the node>
			matrix[parentVarIndex][varIndex][lagVar] = 1;
			parentCount[parentVarIndex] ++;
			
			// Note: of course we don't have to update the grand total in this ase
		}
	}
	
	// Check if a node set represents a cyclic graph via a depth-first search:
	public boolean isCyclicDFS(final BayesNetChangeI bayesNetChange) 
		throws Exception {
		
		boolean cycleFound = false;
		int nodeToCheck = -1;
		int parentNodeToCheck = -1;
		int nodesPushedIndex = 0;
		int nodesPoppedIndex = 0;
		int currentNodeLevel;
		int[] previousNodeLevel = new int[ varCount ];
		int[] lastNodeProcessed = new int[ varCount ];
		boolean[] ancestorSet =  new boolean[ varCount ];
		
		try {
			
			// We always check for a cycle (only) for the node that has an edge added
			// (as described in the bayesNetChange)
			if ( bayesNetChange.getChangeType() == 
			    	BANJO.CHANGETYPE_ADDITION ) {
			    
				nodeToCheck = bayesNetChange.getCurrentNodeID();
				parentNodeToCheck = bayesNetChange.getParentNodeID();
			}
			else if ( bayesNetChange.getChangeType() == 
			    BANJO.CHANGETYPE_REVERSAL ) {
			    
				nodeToCheck = bayesNetChange.getParentNodeID();
				parentNodeToCheck = bayesNetChange.getCurrentNodeID();
			}
			else {
			    
			    // this should never occur:
			    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
			            "DEV: encountered non-addition/non-reversal BayesNetChange " +
			            "in cycle checking.");
			}
			
			int currentEntry;			
			int nodesToVisitCount = 0;
			int nodesVisitedCount = 0;
			
			int nextParentToProcess;
			
			// Indicate that we haven't processed any nodes yet
			for ( int i=0; i<varCount; i++ ) lastNodeProcessed[i] = -1;
			// This sets the starting point to the node that had a parent added
			currentNodeLevel = nodeToCheck;
			ancestorSet[ nodeToCheck ] =  false;
			// Trivial start modification
			lastNodeProcessed[ nodeToCheck ] = varCount; //parentNodeToCheck-1;
			currentNodeLevel = parentNodeToCheck;
			previousNodeLevel[ currentNodeLevel ] = nodeToCheck;
			
			// Check until either a cycle is found or all parents of the nodeToCheckID
			// (and its parents, etc) have been checked
			while ( !ancestorSet[ nodeToCheck ] && 
			        !( currentNodeLevel == nodeToCheck ) ) {

			    // Go to the next potential parent
			    nextParentToProcess = lastNodeProcessed[ currentNodeLevel ];
			    nextParentToProcess++;
		        
			    while ( nextParentToProcess == varCount && 
			            currentNodeLevel != nodeToCheck ) {
			        
			        // We are done with all the parents at the current level, so
			        // go back a level			        
			        currentNodeLevel = previousNodeLevel[ currentNodeLevel ];
				    nextParentToProcess = lastNodeProcessed[ currentNodeLevel ];
				    nextParentToProcess++;
			    }
			    
			    if ( currentNodeLevel != nodeToCheck ) {
			        
				    currentEntry = matrix[ currentNodeLevel  ][ nextParentToProcess ][0];
				    lastNodeProcessed[ currentNodeLevel ] = nextParentToProcess;
				    
				    // If we find a parent at parentNodeToProcess, we
				    // process it right away
				    if ( currentEntry == 1 ) {
				        
				        // Add the found parent to the ancestor set
				        ancestorSet[ nextParentToProcess ] = true;
				        
				        // Point the current stack level to the previous one (the node
				        // that had the parent that we are currently processing)
				        previousNodeLevel[ nextParentToProcess ] = currentNodeLevel;
				        currentNodeLevel = nextParentToProcess;
					    nextParentToProcess = lastNodeProcessed[ currentNodeLevel ];
					    nextParentToProcess++;
					    while ( nextParentToProcess == varCount ) {
					        
					        // Need to go back a level, since we are done with all the
					        // parents at the current level				        
					        currentNodeLevel = previousNodeLevel[ currentNodeLevel ];
						    nextParentToProcess = lastNodeProcessed[ currentNodeLevel ];
						    nextParentToProcess++;
					    }
				    }
			    }
			}
		}
		catch ( OutOfMemoryError e ) {
			
			System.out.print( "(EdgesAsMatrixWithCachedStatistics.isCyclicDFS) " +
					"Out of memory.");
			
			// Also: would need to check in the calling code for this return value
			e.printStackTrace();
		}

		return ancestorSet[ nodeToCheck ];
	} // end isCyclicDFS
	
	// Check if a node set represents a cyclic graph via a breadth-first search:
	public boolean isCyclicBFS(
	        final BayesNetChangeI bayesNetChange) 
			throws Exception {
		
		boolean cycleFound = false;
		final int nodeToCheckID;
		int nextParentNodeToCheckID;
		
		try {
			
			// We always check for a cycle (only) for the node that has an edge added
			// (as described in the bayesNetChange)
			if ( bayesNetChange.getChangeType() 
					== BANJO.CHANGETYPE_ADDITION ) {
			    
				nodeToCheckID = bayesNetChange.getCurrentNodeID();
				nextParentNodeToCheckID = bayesNetChange.getParentNodeID();
			}
			else if ( bayesNetChange.getChangeType() == 
			    BANJO.CHANGETYPE_REVERSAL ) {
			    
				nodeToCheckID = bayesNetChange.getParentNodeID();
				nextParentNodeToCheckID = bayesNetChange.getCurrentNodeID();
			}
			else {
			    
			    // this should never occur:
			    throw new BanjoException(BANJO.ERROR_BANJO_DEV, 
			            "DEV: encountered non-addition/reversal BayesNetChange " +
			            "in cycle checking.");
			}
			
			int currentEntry;
			
			//
			// TODO: Store the ancestor set
			//
			
			int nodesToVisitCount = 0;
			int nodesVisitedCount = 0;
			// Initialize the ancestor set to the parent set
			for (int j=0; j<varCount; j++) {
				
				// Ancestors only care about entries with lag 0
				currentEntry = matrix[nodeToCheckID][j][0];
				ancestorSet[j] = currentEntry;
				nodesToVisit[j] = currentEntry;
				nodesVisited[j] = 0;
			}
							
			nextParentNodeToCheckID = firstParent( nodesToVisit );
					
			// Now visit each parent, and their parents, ...
			while ( !cycleFound && nextParentNodeToCheckID != -1 ) {
				
	
				nodesToVisit[nextParentNodeToCheckID] = 0;
				
				// Process this node if it hasn't been visited yet
				if (nodesVisited[nextParentNodeToCheckID] == 0) {
					
					// Add all parents of this node to the ancestor set
					for (int j=0; j<varCount; j++) {
						
						currentEntry = matrix[nextParentNodeToCheckID][j][0];
						if (nodesVisited[j] == 0 && currentEntry == 1){
							
							// We found a new node that we still need to visit
							nodesToVisit[j] = currentEntry;
							ancestorSet[j] = 1; 
						}
					}
					
					// Mark the node as visited
					nodesVisited[nextParentNodeToCheckID] = 1;
					
					// check if a cycle has been completed
					if (ancestorSet[nodeToCheckID] == 1) {
					    
					    cycleFound = true;
					}
				}
						
				// Move to the next parent
				nextParentNodeToCheckID = firstParent( nodesToVisit );
			}			
		}
		catch (OutOfMemoryError e ) {
			System.out.print( "(EdgesAsMatrixWithCachedStatistics.isCyclicBFS) " +
					"Out of memory.");
			
			// Also: would need to check in the calling code for this return value
			e.printStackTrace();
		}
		
		return cycleFound;
	} // end isCyclicBFS
		
	// Check an entire parentMatrix (e.g., the mandatory parents set)
	public boolean isCyclicBFS() {
		
		// Note that we assume that the dimension of the nodeSetToCheck
		// is based on the same varCount that defines the underlying bayesnet
		//int varCount = this.getVarCount();
		boolean cycleFound = false;
		
		//resetCycleAtNode();  // Replaced for performance
		cycleAtNode = -1;
		
		// Check for each node that it is not contained in a cycle
		int i = 0;
		while (i<varCount && !cycleFound) {
			
			for (int j=0; j<varCount; j++) {
				
				parentIDs[j] = matrix[i][j][0];
			}
			cycleFound = isCyclic(i, parentIDs);
			i++;
		}
		
		return cycleFound;
	}
	
	// hjs 4/19/04 Added bayesNetChange as additional argument for the 
	// CHANGETYPE_REVERSAL case. 
	// Based on the complexity if the code, we'll either want to rewrite the entire
	// "isCyclic" section, or go back to the original apply/undo approach.
	//	
	// hjs 4/20/04 Take the add'l argument back out. Instead, prep this case differently
	//
	// Check if a node set represents a cyclic graph, starting from the node with
	// ID=nodeID, and with a set of parents "parentNodeIDs":
	public boolean isCyclic(
	        final int nodeID, 
	        final int[] parentNodeIDs) {
			
		boolean cycleFound = false;
		
		int parentNodeID;
		int nodeToCheckID;
		int currentEntry;
				
		int nodesToVisitCount = 0;
		int nodesVisitedCount = 0;
		
		// Initialize the ancestor set to the parent set
		for (int j=0; j<varCount; j++) {
			
			// Ancestors only care about entries with lag 0
			currentEntry = parentNodeIDs[j];
			ancestorSet[j] = currentEntry;
			nodesToVisit[j] = currentEntry;
			nodesVisited[j] = 0;
		}
				
		parentNodeID = firstParent( nodesToVisit );
	
		// Now visit each parent, and their parents, ...
		while ( !cycleFound && parentNodeID != -1 ) {
			
			nodesToVisit[parentNodeID] = 0;
			
			// Process this node if it hasn't been visited yet
			if (nodesVisited[parentNodeID] == 0) {
				
				// Add all parents of this node to the ancestor set
				for (int j=0; j<varCount; j++) {
					
					//currentEntry = this.getEntry(parentNodeID, j, 0);
					currentEntry = matrix[parentNodeID][j][0];
					if (nodesVisited[j] == 0 && currentEntry == 1){
												
						nodesToVisit[j] = currentEntry;
						ancestorSet[j] = 1; 
					}
				}
				
				// Mark the node as visited
				nodesVisited[parentNodeID] = 1;
				
				// check if a cycle has been completed
				if (ancestorSet[nodeID] == 1) {
					
					cycleFound = true;
					
					//this.setCycleAtNode(nodeID);  // Replaced for performance
					cycleAtNode = nodeID;
				}
			}
					
			// Move to the next parent
			parentNodeID = firstParent( nodesToVisit );
		}			
			
		return cycleFound;
	}
	
	private int firstParent( final int[] nodesToVisit ){
		// Return the first parent in the list of nodes
		
		int firstParentID=-1;
		int i = 0;
		while (firstParentID == -1 && i < nodesToVisit.length ) {
			if (nodesToVisit[i] == 1) firstParentID = i;
			i++;
		}

		return firstParentID;
	}
	
	public void omitNodesAsOwnParents() {
		
		// Using the fact that a node cannot be a parent to itself,
		// this method sets the (i,i) entries of a matrix to 1 (i.e.,
		// this is used primarily for the mustBeAbsentParents set)
		for (int i=0; i< varCount; i++) {

			matrix[i][i][0] = 1;
		}
	}
	
	public void omitExcludedParents() {
		
		// Based on the selected Markov lag paramters, nodes with lag less
	    // than the minMarkovLag cannot be selected as parents (so we add them
	    // to the mustBeAbsentParents set)
		for (int i=0; i< varCount; i++) {
		    // Note that we only exclude nodes up to lag (minMarkovLag-1)
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<minMarkovLag; k++) {

					matrix[i][j][k] = 1;
				}
			}
		}
	}

	/**
	 * @return Returns the parentCount.
	 */
	public int[] getParentCount() {
		return parentCount;
	}
	
	public int getParentCount(int nodeID) {
		return parentCount[nodeID];
	}
	
	/**
	 * @return Returns the cycleAtNode.
	 */
	public int getCycleAtNode() {
		return cycleAtNode;
	}

	/**
	 * @param cycleAtNode The cycleAtNode to set.
	 */
	public void setCycleAtNode( final int cycleAtNode ) {
		this.cycleAtNode = cycleAtNode;
	}
	
	// This method is not used anymore for performance reasons
	public void resetCycleAtNode() {
		// Use the convention that only node IDs from 0 to varCount
		// are valid values.
		this.cycleAtNode = -1;
	}

	// For testing/tracing only:
	// Print the entire matrix as a string, formatted with various delimiters,
	// and the parentCount at the end.
	// (Can't move this method to superclass, because parentIDs are native to 
	// EdgesAsMatrixWithCachedStatistics)
	public StringBuffer toStringWithIDandParentCount() {
		
		StringBuffer localStringBuffer = new StringBuffer( 
		        BANJO.BUFFERLENGTH_STRUCTURE );
		localStringBuffer.append( "    " );
		// Add header: (need to make formatting more generic, but ok for quick test 
		for (int i=0; i<varCount; i++) {
			
			localStringBuffer.append( i + "  " ); 
			if (i<10) localStringBuffer.append( ' ' ); 
		}
		localStringBuffer.append( '\n' );
		for (int i=0; i<varCount; i++) {
			
			localStringBuffer.append( i );
			localStringBuffer.append( ": " );
			if (i<10) localStringBuffer.append( ' ' );
			
			for (int j=0; j<varCount; j++) {
				for (int k=0; k<maxMarkovLag+1; k++) {
					
					localStringBuffer.append( matrix[i][j][k] );
					// Add delimiter between (parent) entries
					localStringBuffer.append( "   " );					
				}
				
				// Add delimiter between lags
				localStringBuffer.append( '\t' );
			}
			
			// Add delimiter between variables
			localStringBuffer.append( "  , pc=" );
			localStringBuffer.append( parentCount[i] );
			localStringBuffer.append( '\n' );
		}
		return localStringBuffer;
	}
    /**
     * @return Returns the combinedParentCount.
     */
    public int getCombinedParentCount() {
        return combinedParentCount;
    }
}
