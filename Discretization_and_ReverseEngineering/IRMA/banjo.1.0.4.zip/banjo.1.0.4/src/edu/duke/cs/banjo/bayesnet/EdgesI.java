/*
 * Created on Feb 21, 2005
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.bayesnet;

/**
 * Documents the interface for creating an Edges implementation. 
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Feb 21, 2005
 * 
 * @author hjs <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public interface EdgesI {
    
    /**
     * @return Returns the matrix.
     * 
     * Note: this breaks with clean object-oriented design, but it allows
     * us to squeeze a lot of performance from the code. Use this method
     * only where absolutely necessary, since it ties your code to a matrix-
     * based implementation.
     */
    public abstract int[][][] getMatrix();

    public abstract void assignMatrix(EdgesI edgeMatrix) throws Exception;

    // Access an individual entry in the set of edges
    public abstract int getEntry(int varIndex, int parentVarIndex, int lag);

    // Set an individual entry in the set of edges
    public abstract void setEntry(final int varIndex, final int parentVarIndex,
            final int lag, final int newValue) throws Exception;

    public abstract boolean hasIdenticalEntries(EdgesI otherMatrix);

    public abstract Object clone();
}