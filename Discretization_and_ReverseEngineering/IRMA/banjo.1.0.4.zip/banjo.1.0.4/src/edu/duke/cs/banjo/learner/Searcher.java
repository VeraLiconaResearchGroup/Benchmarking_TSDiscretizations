/*
 * Created on Apr 14, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.learner;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.learner.components.*;
import edu.duke.cs.banjo.utility.*;

import java.text.DateFormat;
import java.util.*;

/**
 * Combines common code shared by the different searcher implementations. 
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 14, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public abstract class Searcher implements SearcherI {

	// --------------------------------------------------------------------
	// Common functionality that every derived Searcher subclass will share
	// --------------------------------------------------------------------
	
	// Core "conceptual" (high-level) objects used in every search
    protected ProposerI proposer;
    protected EvaluatorI evaluator;
    protected DeciderI decider;				
    protected CycleCheckerI cycleChecker;

    protected final int varCount;
    protected final int minMarkovLag;
    protected final int maxMarkovLag;

	// Every Searcher will need to keep track of the total number
	// of graphs visited:
	protected long networksVisitedGlobalCounter;
	protected long networksVisitedInnerLoopCounter;
	protected long maxNetworksVisitedInInnerLoop;
	protected final double unreachableScore = BANJO.BANJO_UNREACHABLEBDESCORE;
	
	// Variables related to the main search loop (didn't make them final
	// in case a subclass wants to take a more dynamic approach to their management)
	protected long maxSearchLoops;
	protected long maxRestarts;
	protected long restartCount;

	// Tracking the numbers where the restarts take place (not of general interest
	// so generally it isn't displayed)
	protected StringBuffer restartsAtCounts;	
		
	// Objects that won't change once they've been created, and that are
	// used by every subclass:
	// Containers for the search process related data
	protected Settings processData;
	
	// "Global" statistics collector for use in searcher subclasses
	protected final RecorderI searcherStatistics;
	
	// String container for collecting info about the process
	protected StringBuffer searcherStats;
	
	// Core objects that provide the underpinning of the search
	// (Note: these objects will generally change over the course of the search)
	protected BayesNetManagerI bayesNetManager;
	protected BayesNetChangeI suggestedBayesNetChange;
	protected double currentBestScoreSinceRestart;
	protected BayesNetStructureI highScoreStructureSinceRestart;
	
	// Objects and variables used to maintain the constantly sorted set 
	// of high scoring networks ("n-best" networks)
	protected TreeSet highScoreStructureSet;
	protected long nBestCount;
	protected final long nBestMax;
	protected double nBestThresholdScore;
	
	// Maintain a list of bayesNetChange objects used for search strategies
	// based on proposers that generate more than a single change at the time
	// (Typically, a search that considers all possible single moves per time
	// step, etc)
	List suggestedChangeList;
	
	// Utility variables for displaying feedback at selected intervals
	protected int percentLevel;
	// Mirror for time
	protected boolean displayFeedbackByTime;
	protected long feedbackTimeDelta; // contains time in milliseconds
	protected double nextFeedbackTime;	// Write out intermediate results to file 
										//(e.g., the best network so far)
	protected final boolean trackIntermediateResults;
	protected final long reportTimeDelta; // contains time in milliseconds
	protected double nextReportTime;
	protected final int numberOfProgressReports;
	protected final long writeToFileInterval;
	
	// Utility variables for tracking the elapsed time
	protected long maxSearchTime;
	protected long startTime;	
	protected long elapsedTime;
	protected long intermediateTime;
	protected DateFormat timeFormat;

	// private variables, declared here so we don't have to allocate
	// their memory in a frequent loop
    private long estimatedTime;
    private int numberOfDecimals = BANJO.OPTION_NUMBEROFDECIMALSINTIMEDISPLAY;
    private int percentPaddingLength = BANJO.PERCENTPADDINGLENGTH;
    private int timePaddingLength = BANJO.TIMEPADDINGLENGTH;
    private int loopPaddingLength;

	// Utility string for reuse, especially in "completion feedback"
	protected StringBuffer messageToDisplay = 
	    new StringBuffer(BANJO.BUFFERLENGTH_SMALL );

	String newLinePlusPrefix = "\n" + BANJO.FEEDBACKDASH + " ";
	String linePostfix = " " + BANJO.FEEDBACKDASH;
	String prefix = BANJO.FEEDBACKDASH;
	int lineLength = BANJO.FEEDBACKLINELENGTH;
    
	protected final boolean restartWithRandomNetwork;
	
	protected abstract class SearchExecuter {
		
		protected abstract void executeSearch() throws Exception;
		protected abstract int sizeOfListOfChanges();
	}

	protected abstract class SearchTerminator {
		
	    long estimatedTime;
	    int numberOfDecimals = BANJO.OPTION_NUMBEROFDECIMALSINTIMEDISPLAY;
		int percentPaddingLength = BANJO.PERCENTPADDINGLENGTH;
		int loopPaddingLength = (( new Long( maxSearchLoops ) ).toString() ).length();
		int timePaddingLength = BANJO.TIMEPADDINGLENGTH;
		int restartPaddingLength = (( new Long( maxRestarts ) ).toString() ).length();
	    double displayPercent;
	    
		protected abstract boolean checkTerminationCondition() throws Exception;
		protected abstract void generateFeedback() throws Exception;
	}

	/**
	 * Constructor for instantiating the objects shared between searcher
	 * implementations.
	 * 
	 * @param processData The special container for the initial, validated, and
	 * dynamically updated settings.
	 */
	public Searcher( Settings processData ) throws BanjoException {
		
		String strStatisticsChoice;
		String strSettingChoice;
		String tmpString;
		// Used for temporary assignement of values destined for variables
		// that are declared as "final" 
		long tmpLong;
		int tmpInt;

		// We want to link our internal processData container to the one that is
	    // being passed in to have convenient access to the dynamic process data
	    // from within various methods (mainly for the Searcher subclasses).
	    this.processData = processData;
	    
		// Start the timer for the prep time
		startTime = System.currentTimeMillis();
	
		networksVisitedGlobalCounter = 1;
		restartCount = 0;
		restartsAtCounts = new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		restartsAtCounts.append( 0 );
		
	    restartWithRandomNetwork = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_RESTARTWITHRANDOMNETWORK ).
		        equalsIgnoreCase( BANJO.UI_RESTARTWITHRANDOMNETWORK_YES );
	    
//		timeFormat = DateFormat.getTimeInstance(DateFormat.MEDIUM);
		timeFormat = DateFormat.getDateTimeInstance( DateFormat.SHORT, 
		        DateFormat.MEDIUM );
				
		searcherStats = new StringBuffer( 
				BANJO.BUFFERLENGTH_STAT_INTERNAL );

		// Record the type of searcher	
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ));
		
		searcherStats.append( StringUtil.formatRightLeftJustified(
		        newLinePlusPrefix, BANJO.APPLICATION_NAME, 
		        BANJO.APPLICATION_NAME_LONG + linePostfix, 
		        null, lineLength ) );

		String HeaderInfo = "Release " + 
			BANJO.APPLICATION_VERSIONNUMBER;
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, HeaderInfo, 
		        BANJO.APPLICATION_VERSIONDATE + linePostfix, 
		        null, lineLength ) );

		HeaderInfo = "Licensed from Duke University";
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, HeaderInfo, 
		        linePostfix, 
		        null, lineLength ) );

		HeaderInfo = "Copyright (c) 2005 by Alexander J. Hartemink";
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, HeaderInfo, 
		        linePostfix, 
		        null, lineLength ) );

		HeaderInfo = "All rights reserved";
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, HeaderInfo, 
		        linePostfix, 
		        null, lineLength ) );

		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ));

		// Add the project-related information:
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_PROJECT );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Project:", strSettingChoice, null, lineLength ) );
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_USER );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "User:", strSettingChoice, null, lineLength ) );
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_DATASET );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Data set:", strSettingChoice, null, lineLength ) );
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_NOTES );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Notes:", strSettingChoice, null, lineLength ) );
		
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ));
		
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, 
		        "Searcher:", StringUtil.getClassName(this), null, lineLength ) );
		
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ));

		// ------------------------------------
		// Add feedback about some user choices
		// ------------------------------------

		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Settings file:", 
		        processData.getValidatedProcessParameter( 
					BANJO.VALIDATED_SETTINGSFILEWITHPATH ), null, lineLength ) );
		// 
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_INPUTDIRECTORY );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Input directory:", 
		        strSettingChoice, null, lineLength ) );
		// 
		// We need to get the value here, although we won't display it until later
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MAXMARKOVLAG );
		maxMarkovLag = Integer.parseInt(strSettingChoice);
		StringBuffer maxMarkov = StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Max. Markov lag:", 
		        strSettingChoice, null, lineLength );
		//
		String observationsFile = processData.getValidatedProcessParameter(
		        BANJO.SETTING_OBSERVATIONSFILE );
	    StringTokenizer tokenizer;
	    int tokenCount;
		tokenizer = new StringTokenizer( observationsFile , 
		        BANJO.DEFAULT_LISTDELIMITER );
		tokenCount = tokenizer.countTokens();
		if ( observationsFile.indexOf( "*" ) < 0 ) {
		    
			if ( tokenCount > 1 ) {		    
				
				searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Observations files:", 
				        tokenizer.nextToken(), null, lineLength ) );
				for ( int obsFiles=1; obsFiles < tokenCount; obsFiles++ ) {
				    searcherStats.append( StringUtil.formatRightLeftJustified( 
					        newLinePlusPrefix, "", 
					        tokenizer.nextToken(), null, lineLength ) );
				}
				
				//
//				strSettingChoice = processData.getValidatedProcessParameter( 
//				        BANJO.SETTING_RELATEDOBSERVATIONSFILES );
//				searcherStats.append( StringUtil.formatRightLeftJustified( 
//				        prefix, "  Are observations 'related across files':", 
//				        strSettingChoice, lineLength ) );
			}
			else {
			    
				searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Observations file:", 
				        observationsFile, null, lineLength ) );
			}
		}
		else {
		    
		    if ( tokenCount > 1 ) {	
		        
				searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Observations files (wildcard spec.):", 
				        tokenizer.nextToken(), null, lineLength ) );
				for ( int obsFiles=1; obsFiles < tokenCount; obsFiles++ ) {
				    searcherStats.append( StringUtil.formatRightLeftJustified( 
					        newLinePlusPrefix, "", 
					        tokenizer.nextToken(), 
					        BANJO.DEFAULT_LISTDELIMITER, lineLength ) );
				}
		    }
		    else {
		        
		        searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Observations files (wildcard spec.):", 
				        observationsFile, null, lineLength ) );
		    }
	        
	        String filesFromWildcardSpec = processData.getValidatedProcessParameter( 
			        BANJO.DATA_WILDCARDOBSERVATIONSFILES );
	        
		    StringTokenizer wildcardTokenizer;
		    int wildcardTokenCount;
		    wildcardTokenizer = new StringTokenizer( filesFromWildcardSpec , 
		            BANJO.DEFAULT_LISTDELIMITER );
		    wildcardTokenCount = wildcardTokenizer.countTokens();
		    searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "  Files used:", 
			        wildcardTokenizer.nextToken(), 
			        BANJO.DEFAULT_LISTDELIMITER, lineLength ) );
		    
		    while ( wildcardTokenizer.hasMoreTokens() ) {
			    searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "", wildcardTokenizer.nextToken(), 
				        null, lineLength ) );
			}
		    
		    // List omitted files, if there are any
		    String filesOmittedFromWildcardSpec = 
		        processData.getValidatedProcessParameter( 
			        BANJO.DATA_OMITTEDWILDCARDOBSERVATIONSFILES );
	        
		    if ( filesOmittedFromWildcardSpec != null && 
		            !filesOmittedFromWildcardSpec.equals("") ) {
		        
			    wildcardTokenizer = new StringTokenizer( 
			            filesOmittedFromWildcardSpec, BANJO.DEFAULT_LISTDELIMITER );
			    wildcardTokenCount = wildcardTokenizer.countTokens();
			        
			    searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "  Files omitted:", 
				        wildcardTokenizer.nextToken(), null, lineLength ) );
			    
			    while ( wildcardTokenizer.hasMoreTokens() ) {
				    searcherStats.append( StringUtil.formatRightLeftJustified( 
					        newLinePlusPrefix, "", 
					        wildcardTokenizer.nextToken(), null, lineLength ) );
				}
		    }
		    
			// Display for wild card spec, independent of actual files found
		    // (Actually: value cannot be 'yes'!!)
//			strSettingChoice = processData.getValidatedProcessParameter( 
//			        BANJO.SETTING_RELATEDOBSERVATIONSFILES );
//			searcherStats.append( StringUtil.formatRightLeftJustified( 
//			        newLinePlusPrefix, "  Are observations 'related across files':",
//			        strSettingChoice, null, lineLength ) );
		}
		// 
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_OUTPUTDIRECTORY );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Output directory:", 
		        strSettingChoice, null, lineLength ) );
		// 
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_REPORTFILE );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Report file:", 
		        strSettingChoice, null, lineLength ) );
		// 
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_VARCOUNT );
		varCount = Integer.parseInt(strSettingChoice);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Variable count:", 
		        strSettingChoice, null, lineLength ) );
		//
		if ( maxMarkovLag > 0 ) {
		    
			strSettingChoice = processData.getValidatedProcessParameter( 
			        BANJO.DATA_OBSERVEDOBSERVATIONROWCOUNT );
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Number of observations:", 
			        strSettingChoice, null, lineLength ) );
		}
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.DATA_OBSERVEDOBSERVATIONCOUNT );
		if ( maxMarkovLag > 0 ) {
		    
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, 
			        "'Effective' number of observations with DBN:", 
			        strSettingChoice, null, lineLength ) );
		}
		else {
		    
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Number of observations:", 
			        strSettingChoice, null, lineLength ) );
		}

	    // Discretization:
		strSettingChoice = 
	        processData.getValidatedProcessParameter( 
	                BANJO.SETTING_DISCRETIZATIONPOLICY );
		if ( strSettingChoice != null && strSettingChoice.length() > 0 &&
		        !( strSettingChoice.equals( BANJO.BANJO_NOVALUESUPPLIED_STRING ) ) ) {
		    
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Discretization policy:", 
			        strSettingChoice, null, lineLength ) );
			
			strSettingChoice = 
		        processData.getValidatedProcessParameter( 
		                BANJO.SETTING_DISCRETIZATIONEXCEPTIONS );
			
			if ( strSettingChoice.equals( BANJO.BANJO_NOVALUESUPPLIED_STRING ) ) {
			    
			    // We may even decide not to display this when no value was supplied?
			    searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Discretization exceptions:", 
				        "none", null, lineLength ) );
			}
			else if ( strSettingChoice != null && strSettingChoice.length() > 0 ) {
			    
				searcherStats.append( StringUtil.formatRightLeftJustified( 
				        newLinePlusPrefix, "Discretization exceptions:", 
				        strSettingChoice, 
				        BANJO.DEFAULT_LISTDELIMITER, lineLength ) );
			}
		}
		
		// Post-processing options:
		strSettingChoice = 
	        processData.getValidatedProcessParameter( 
	                BANJO.SETTING_INFLUENCESCORES );
		if ( strSettingChoice != null && strSettingChoice.length() > 0 &&
		        !( strSettingChoice.equals( BANJO.BANJO_NOVALUESUPPLIED_STRING ) ) ) {
		    
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Compute Influence scores:", 
			        strSettingChoice, null, lineLength ) );
		}
		strSettingChoice = 
	        processData.getValidatedProcessParameter( 
	                BANJO.SETTING_DOTOUTPUT );
		if ( strSettingChoice != null && strSettingChoice.length() > 0 &&
		        !( strSettingChoice.equals( BANJO.BANJO_NOVALUESUPPLIED_STRING ) ) ) {
		    
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Create dot output:", 
			        strSettingChoice, null, lineLength ) );
		}
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MINMARKOVLAG );
		minMarkovLag = Integer.parseInt(strSettingChoice);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Min. Markov lag:", 
		        strSettingChoice, null, lineLength ) );
		//
		searcherStats.append( maxMarkov );
		//
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_DBNMANDATORYIDENTITYLAGS );
		if ( strSettingChoice == null ) {
		
		    strSettingChoice = "(none)";
		}
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "DBN mandatory lag(s):", 
		        strSettingChoice, null, lineLength ) );
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_EQUIVALENTSAMPLESIZE );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Equiv. sample size:", 
		        strSettingChoice, null, lineLength ) );
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MAXPARENTCOUNT );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Max. parent count:", 
		        strSettingChoice, null, lineLength ) );
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_INITIALSTRUCTUREFILE );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Initial structure file:", 
		        strSettingChoice, null, lineLength ) );
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MUSTBEPRESENTEDGESFILE );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "'Must be present' edges file:", 
		        strSettingChoice, null, lineLength ) );
		//
		strSettingChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MUSTNOTBEPRESENTEDGESFILE );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "'Must not be present' edges file:", 
		        strSettingChoice, null, lineLength ) );
		//
	    
	    long tmpMaxRestarts = Long.parseLong(
		    processData.getValidatedProcessParameter( BANJO.SETTING_MAXRESTARTS ));
	    long tmpMaxTime = Long.parseLong(
		    processData.getValidatedProcessParameter( BANJO.SETTING_MAXSEARCHTIME ));
	    long tmpProposedNetworks = Long.parseLong(
		    processData.getValidatedProcessParameter( 
		            BANJO.SETTING_MAXPROPOSEDNETWORKS ));
		    
		if ( tmpMaxRestarts == BANJO.BANJO_NOVALUESUPPLIED_NUMBER && 
		        tmpMaxTime == BANJO.BANJO_NOVALUESUPPLIED_NUMBER && 
		        tmpProposedNetworks == BANJO.BANJO_NOVALUESUPPLIED_NUMBER ) {
		 
		    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
		            "To run a Banjo search, you need to supply at least one of " +
		            "the settings" +
		            "\n'" + BANJO.SETTING_MAXRESTARTS +
		            "', '" + BANJO.SETTING_MAXSEARCHTIME +
		            "', or '" + BANJO.SETTING_MAXPROPOSEDNETWORKS +
		            "'.");
		}
	    	

		// Set the number for the intermediate progress reports
		// (display follows later, but need the number)
		int intProgressReports = Integer.parseInt( 
		        processData.getValidatedProcessParameter( 
		        BANJO.SETTING_NUMBEROFPROGRESSREPORTS ) );
		if ( intProgressReports < 0 ) { intProgressReports = 0; }
		numberOfProgressReports = intProgressReports;
		
		try {
		    
		    maxRestarts = Long.parseLong( 
			        processData.getValidatedProcessParameter(
			                BANJO.SETTING_MAXRESTARTS ) );
			
			// Remember that we allow for the max. search loops to be unspecified
		    // as long as a valid search time is specified:
			if ( maxSearchLoops < 0 && maxSearchTime < 0 ) { 
		        
		        throw new BanjoException( 
		                BANJO.ERROR_INVALID_MAXRESTARTS,
		                "The '" + BANJO.SETTING_MAXRESTARTS + 
		                "' parameter must be specified " +
		                "\nwhen no search time and iteration limits are specified." );
		    }
			
			// Assign the utility variables for the "percent completed" 
			// feedback display
			percentLevel = 1;
		}
		// catch the case where maxSearchLoops is not a number
		catch (Exception e) {
			
			// Remember that we allow for the max. search loops to be unspecified
		    // as long as a valid search time is specified:
			if ( maxSearchTime < 0 && maxSearchLoops < 0 ) { 
	        
		        throw new BanjoException( e, 
		                BANJO.ERROR_MISSING_MAXRESTARTS );
		    }
		    else {
		        
		        // Indicate that no search loop limit is specified 
		        maxRestarts = -1;
		    }
		}
		// Note: we allow the max search loops to be negative, as indicator that it is
		// not used as stop criterion for the main search loop
		if ( maxRestarts < 0 ) {
		    
		    strSettingChoice = BANJO.BANJO_NOVALUE_INDISPLAY;
		} else {
		    
		    strSettingChoice = Long.toString( maxRestarts );
		}
		
		String tmpStrMaxRestarts = strSettingChoice;
		    
		
		if ( maxRestarts >= 0 ) {
		    
		    maxSearchTime = -1;
		    maxSearchLoops = -1;
		    
		    // Set-up time-based reporting
		    feedbackTimeDelta = BANJO.DEFAULT_FEEDBACKINTERVAL;
			nextFeedbackTime = feedbackTimeDelta;
			
			displayFeedbackByTime = true;
		}
		else {
		    
			// Get the max. search time (already converted to milleseconds)
			maxSearchTime = Long.parseLong( processData.getValidatedProcessParameter( 
			        BANJO.SETTING_MAXSEARCHTIME ));
		    if ( maxSearchTime < 0 ) { 
	
		        // Indicate that we need to skip any reporting based on search time:
		        displayFeedbackByTime = false;
		        strSettingChoice = BANJO.BANJO_NOVALUE_INDISPLAY; 
		    }
		    else {
		        
		        strSettingChoice = StringUtil.formatElapsedTime( 
				        maxSearchTime, 
				        BANJO.OPTION_NUMBEROFDECIMALSINTIMEDISPLAY,
				        BANJO.OPTION_TIMEFORMAT_MIXED ).toString(); 

		        if ( numberOfProgressReports > 0 ) {

					feedbackTimeDelta = Math.round( 
					        maxSearchTime / numberOfProgressReports );
		        }
		        else {
		            
		            feedbackTimeDelta = BANJO.DEFAULT_FEEDBACKINTERVAL;
		        }
		        
				nextFeedbackTime = feedbackTimeDelta;
				displayFeedbackByTime = true;
		    }
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Max. time:", 
			        strSettingChoice, null, lineLength ) );
	
			
			// Get search iteration parameters, and do some basic validation
			try {
			    
				maxSearchLoops = Long.parseLong( 
				        processData.getValidatedProcessParameter(
				                BANJO.SETTING_MAXPROPOSEDNETWORKS ) );
				
				// Remember that we allow for the max. search loops to be unspecified
			    // as long as a valid search time is specified:
				if ( maxSearchLoops < 0 && maxSearchTime < 0 ) { 
			        
			        throw new BanjoException( 
			                BANJO.ERROR_INVALID_MAXSEARCHLOOPS,
			                "The '" + BANJO.SETTING_MAXPROPOSEDNETWORKS + 
			                "' parameter must be specified (as greater or equal to 0) " +
			                "when no valid search time is specified." );
			    }
				
				// Assign the utility variables for the "percent completed" 
				// feedback display
				percentLevel = 1;
			}
			// catch the case where maxSearchLoops is not a number
			catch (Exception e) {
				
				// Remember that we allow for the max. search loops to be unspecified
			    // as long as a valid search time is specified:
				if ( maxSearchTime < 0 ) { 
		        
			        throw new BanjoException( e, 
			                BANJO.ERROR_MISSING_MAXSEARCHLOOPS );
			    }
			    else {
			        
			        // Indicate that no search loop limit is specified 
			        maxSearchLoops = BANJO.BANJO_NOVALUESUPPLIED_NUMBER;
			    }
			}
			// Note: we allow the max search loops to be negative, as indicator that it is
			// not used as stop criterion for the main search loop
			if ( maxSearchLoops < 0 ) {
			    
			    strSettingChoice = BANJO.BANJO_NOVALUE_INDISPLAY;
			} else {
			    
			    strSettingChoice = Long.toString( maxSearchLoops );
			}
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Max. proposed networks:", strSettingChoice, null, lineLength ) );
		}
		
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Max. restarts:", tmpStrMaxRestarts, null, lineLength ) );
		
		// ---
		try {
			maxNetworksVisitedInInnerLoop = Long.parseLong( 
			        processData.getValidatedProcessParameter( 
			        BANJO.SETTING_MINNETWORKSBEFORECHECKING ) );
		}
		catch (Exception e) {
			
			// maxNetworksVisitedInInnerLoop is not a number or missing
			throw new BanjoException( e, 
			        BANJO.ERROR_MISSING_INNERSEARCHLOOPS );
		}
		// Inner search loops can't be larger than max search loops
		if ( ( maxSearchLoops >= 0 && maxNetworksVisitedInInnerLoop > maxSearchLoops )
		        || maxNetworksVisitedInInnerLoop < 0 ) {
			maxNetworksVisitedInInnerLoop = 0;
		}
		strSettingChoice = Long.toString( maxNetworksVisitedInInnerLoop );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Min. networks before checking:", 
		        strSettingChoice, null, lineLength ) );	    
		// ---
		try {
		    tmpLong = Long.parseLong( processData.getValidatedProcessParameter(
			        BANJO.SETTING_NBEST ) );
		}
		catch (Exception e) {
			
			// There's only a NumberFormatException to catch; fix it:
		    tmpLong = 1;
		}
		// Make sure we store at least the high score
		if (tmpLong < 1) {
		    tmpLong = 1;
		}
		nBestMax = tmpLong; 
		strSettingChoice = Long.toString( nBestMax );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Number of best networks tracked:", 
		        strSettingChoice, null, lineLength ) );
		nBestCount = 1;
		

		// Set the number for the intermediate progress reports: display
		strSettingChoice = Integer.toString( numberOfProgressReports );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Number of progress reports:", 
		        strSettingChoice, null, lineLength ) );
		
		// Set the interval for saving intermediate results to file
		tmpLong = Long.parseLong( 
		        processData.getValidatedProcessParameter( 
		        BANJO.SETTING_WRITETOFILEINTERVAL ) );
		if ( tmpLong <= 0 ) { 
		    
		    writeToFileInterval = 0; 
			trackIntermediateResults = false;
			// Default to a reasonable number:
			reportTimeDelta = BANJO.DEFAULT_REPORTTOFILEINTERVAL;
			nextReportTime = reportTimeDelta;
			
			strSettingChoice = BANJO.BANJO_NOVALUE_INDISPLAY;
		}
		else {
		    
		    // writeToFileInterval is in minutes, so need to adjust
		    writeToFileInterval = tmpLong * 60 * 1000;
			trackIntermediateResults = true;
			reportTimeDelta = writeToFileInterval;
			nextReportTime = reportTimeDelta;
			
			// Format the display string
			strSettingChoice = StringUtil.formatElapsedTime( 
			        writeToFileInterval, 
			        BANJO.OPTION_NUMBEROFDECIMALSINTIMEDISPLAY,
			        BANJO.OPTION_TIMEFORMAT_MIXED ).toString(); 
		}
		
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Write to file interval:", 
		        strSettingChoice, null, lineLength ) );
		
		// Note: Every searcher that uses the nBestThresholdScore needs
		// to set the nBestThresholdScore (generally to the initial network score)
		nBestThresholdScore = 0;
		
		// Set the user-selected statistics collector
		strStatisticsChoice = processData.getValidatedProcessParameter( 
		        BANJO.SETTING_STATISTICSCHOICE );	
		strSettingChoice = "";
		if ( strStatisticsChoice == BANJO.UI_RECORDER_STANDARD ) { 
			
			this.searcherStatistics = new RecorderStandard( processData );
		}
		else {
				
			// Default case:
			this.searcherStatistics = new RecorderStandard( 
			        processData );
			strSettingChoice = "  defaulted to ";
		}
		strSettingChoice = strSettingChoice + 
				StringUtil.getClassName( searcherStatistics );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Statistics:", strSettingChoice, null, lineLength ) );
	}
	
	/**
	 * Utility method for computing the status of the search with respect to the elapsed
	 * time and number of visited networks; Used to provide feedback to the user.
	 *
	 */
	protected void displaySearchCompletionStatus() throws Exception {
	    		
		loopPaddingLength = (( new Long( maxSearchLoops ) ).toString() ).length();
	    
	    // Deal with time checking first, since this will likely be the preferred stop
	    // criterion for most users
	    if ( displayFeedbackByTime ) {
		    
		    long elapsedTime = getElapsedTime();
		    
		    // Convention: we use only the display criteria for the "counter" that occurs
		    // first (time or loop count). Note that our main search loops exits as soon as
		    // one of the criteria is observed.
		    	
			if (  elapsedTime >= nextFeedbackTime ) {
			    
			    double displayPercent;
			    
			    // The next 2 lines simply format the output to show some extra decimals
			    displayPercent = Math.round( 1000 * elapsedTime / maxSearchTime );
			    displayPercent /= 10;
			    if ( displayPercent > 100 ) displayPercent = 100;
			    		    
			    messageToDisplay.append( "Search " + 
			            StringUtil.fillSpacesLeft( 
			                    ( new Double( displayPercent).toString() ), 
			                    percentPaddingLength ) +
			    		"% completed." );
			    
			    messageToDisplay.append( " Elapsed time: " );
			    messageToDisplay.append( StringUtil.fillSpacesLeft(
			            ( StringUtil.formatElapsedTime( 
			            elapsedTime, numberOfDecimals,
			            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
			            timePaddingLength ) );
			    messageToDisplay.append( "." );
			    
			    messageToDisplay.append( " Time remaining: " );
			    messageToDisplay.append( StringUtil.fillSpacesLeft(
			            ( StringUtil.formatElapsedTime( 
			            maxSearchTime - elapsedTime, numberOfDecimals,
			            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
			            timePaddingLength ) );
			    messageToDisplay.append( "." );
			    
			    messageToDisplay.append( " Networks examined: " );
			    messageToDisplay.append(  StringUtil.fillSpacesLeft( 
			            ( new Long( this.networksVisitedGlobalCounter ) ).toString(), 
			            loopPaddingLength ) );
			    messageToDisplay.append( "." );
			    
			    nextFeedbackTime += feedbackTimeDelta;
			}    		
	    }
	    else {
			if ( networksVisitedGlobalCounter*BANJO.DEFAULT_NUMBEROFPROGRESSREPORTS 
			        >= maxSearchLoops*percentLevel && 
			        maxSearchLoops > 0 ) {

			    double displayPercent;
			    
			    // The next 2 lines simply format the output to show some extra decimal(s)
			    displayPercent = Math.round( 1000*networksVisitedGlobalCounter/maxSearchLoops );
			    displayPercent /= 10;
			    if ( displayPercent > 100 ) displayPercent = 100;
			    
			    messageToDisplay.append( "Search " + 
			            StringUtil.fillSpacesLeft( 
			                    ( new Double( displayPercent).toString() ), 
			                    percentPaddingLength ) +
			    		"% completed." );
			    
			    messageToDisplay.append( " Networks examined: " );
			    messageToDisplay.append(  StringUtil.fillSpacesLeft( 
			            ( new Long( this.networksVisitedGlobalCounter ) ).toString(), 
			            loopPaddingLength ) );
			    
			    messageToDisplay.append( " Elapsed time: " );
			    messageToDisplay.append( StringUtil.fillSpacesLeft(
			            ( StringUtil.formatElapsedTime( 
			            elapsedTime, numberOfDecimals,
			            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
			            timePaddingLength ) );
			    messageToDisplay.append( "." );

			    percentLevel++;
			}
		}
	    
		if ( messageToDisplay.length() > 1 ) {
		 
		    searcherStatistics.recordSpecifiedData( messageToDisplay );
			messageToDisplay = new StringBuffer(BANJO.BUFFERLENGTH_SMALL );
		}
	}

	
	protected void finalCleanup() throws Exception {

	    processData.setDynamicProcessParameter( 
	            BANJO.DATA_TOTALTIMEFORSEARCH,
	            Long.toString( elapsedTime ) );
	    
	    processData.setDynamicProcessParameter( 
	            BANJO.DATA_PROPOSEDNETWORKS,
	            Long.toString( networksVisitedGlobalCounter ) );
	    
	    // Store the networks with the highest scores in processData
	    // for convenient post-processing
	    processData.setHighScoreStructureSet( highScoreStructureSet );

	    // Record the final data
		searcherStatistics.recordFinalData(this);
		
		// collect any statistics from core internal objects
		//searcherStatistics.recordSpecifiedData( new StringBuffer( "\n" ) );
		searcherStatistics.recordSpecifiedData(
				this.provideCollectedStatistics() );
		
		if ( BANJO.CONFIG_DISPLAYSTATISTICS ) {
			    
			searcherStatistics.recordSpecifiedData(
					proposer.provideCollectedStatistics() );
			searcherStatistics.recordSpecifiedData(
			        cycleChecker.provideCollectedStatistics() );
			searcherStatistics.recordSpecifiedData(
					evaluator.provideCollectedStatistics() );
			searcherStatistics.recordSpecifiedData(
					decider.provideCollectedStatistics() );
		}
		
		// Display the elapsed time (again) - for dev convenience
		if ( BANJO.DEBUG && BANJO.DEV_TMP && elapsedTime > 0 ) {
		    
		    // tack on the known data about the "job"
			searcherStatistics.recordSpecifiedData(
			        StringUtil.getJobSignature( 
			                processData ) );

			int decimalFactor = 100;
			StringBuffer displayElapsedTime = 
			    new StringBuffer( BANJO.BUFFERLENGTH_SMALL );
			displayElapsedTime.append( "\n  Elapsed time:  ");
			displayElapsedTime.append( 
			        StringUtil.formatElapsedTime( 
			                elapsedTime, 1, BANJO.OPTION_TIMEFORMAT_MIXED ) );
			double mnpm = Math.round( this.networksVisitedGlobalCounter * decimalFactor * 60 / 
				( elapsedTime * 1000 ) );
			mnpm = mnpm / decimalFactor;
			displayElapsedTime.append( "\n  Search Rate:   ");
			displayElapsedTime.append( mnpm );
			displayElapsedTime.append( " mnpm");
			        
			searcherStatistics.recordSpecifiedData( displayElapsedTime );
		}
	}
	
	/**
	 * @return Returns the networksVisitedGlobalCounter.
	 */
	public long getNetworksVisitedGlobalCounter() {
		
		return networksVisitedGlobalCounter;
	}	
	/**
	 * @return Returns the searcherStatistics.
	 */
	public RecorderI getSearcherStatistics() {
		return searcherStatistics;
	}
	
	/**
	 * @return Returns the bayesNetManager.
	 */
	public Object getBayesNetManager() {
		return bayesNetManager;
	}
	/**
	 * @return Returns the currentBestScoreSinceRestart.
	 */
	public double getHighScore() {

		Iterator highScoreSetIterator = getHighScoreStructureSet().iterator();
		BayesNetStructureI highScoreNetwork = null;
		if ( highScoreSetIterator.hasNext() ) {
		    highScoreNetwork = ( BayesNetStructureI ) highScoreSetIterator.next();
		}
		
		return highScoreNetwork.getNetworkScore();
	}
	/**
	 * @return Returns the highScoreStructureSinceRestart.
	 */
	public Object getHighScoreStructure() {
		
		Iterator highScoreSetIterator = getHighScoreStructureSet().iterator();
		BayesNetStructureI highScoreNetwork = null;
		if ( highScoreSetIterator.hasNext() ) {
		    highScoreNetwork = ( BayesNetStructureI ) highScoreSetIterator.next();
		}

		return highScoreNetwork;
}
	/**
	 * @return Returns the highScoreStructureSet.
	 */
	public Collection getHighScoreStructureSet() {
		return highScoreStructureSet;
	}
	
	/**
	 * @return Returns the elapsedTime that the search has been running.
	 */
	protected long getElapsedTime() {

		long elapsedTime = System.currentTimeMillis() - startTime;
		return elapsedTime;
	}
	
	protected StringBuffer listScores() {
	    
	    // Provides a list of the N-best scoring networks. Note that even though the
	    // collection of networks (the highScoreStructureSet) is a set of objects with
	    // a BayesNetStructureI contract, we channel access to the set via our special
	    // wrapper HighScoreContainer class, which gives us access to the special
	    // formatting of the string representation of the network as defined within
	    // the individual BayesNetStructure implementations. 
	    
	    StringBuffer statisticsBuffer = new StringBuffer(
	    		BANJO.BUFFERLENGTH_STAT );
	    
		Iterator highScoreSetIterator = getHighScoreStructureSet().iterator();
		int size = getHighScoreStructureSet().size();
		BayesNetStructureI nextNetwork;
		int i = 0;
		while ( highScoreSetIterator.hasNext() ) {
			
			i++;
			nextNetwork = (BayesNetStructureI) highScoreSetIterator.next();
			
			// Record the score and the loop
			if ( size > 1 ) {
			    
				statisticsBuffer.append( "\n\nNetwork #" );
				statisticsBuffer.append( i );
				statisticsBuffer.append( ", score: " );
			}
			else {

				statisticsBuffer.append( "\n\nNetwork score: " );
			}
			statisticsBuffer.append( StringUtil.displayWithFixedDecimals(
			        nextNetwork.getNetworkScore(), 
			        BANJO.DIGITSINSCOREDISPLAY ) );
			statisticsBuffer.append( ", first found at iteration " );
			statisticsBuffer.append( nextNetwork.getSearchLoopIndex() );
			
			// Add the network structure as a specially formatted string
			statisticsBuffer.append( "\n" );
			statisticsBuffer.append( nextNetwork.toString() );
		}
		
		return statisticsBuffer;
	}

	/**
     * (Optional) Lets user verify the selected search parameters before running
     * a search.
     * 
     * @return Returns the boolean value of the user's choice.
     */
	protected boolean askToVerifySettings() throws Exception {
	
	    // When the 'askToVerifySettings' value in the settings file is set to 'yes'
	    // we post a quick check to the user with the main option that are selected.
	    // The user can then decide whether to run the search or to stop and change
	    // some parameters.
	    
		String askToVerifySettings;
		String strMaxParentCount;
		String strMinMarkovLag;
		String strMaxMarkovLag;
		
		strMaxParentCount = processData.getValidatedProcessParameter("maxParentCount");
		strMinMarkovLag = processData.getValidatedProcessParameter("minMarkovLag");
		strMaxMarkovLag = processData.getValidatedProcessParameter("maxMarkovLag");

		
		// hjs 7/16/04
		// Add optional feedback to user before running the main loop
		askToVerifySettings = processData.getValidatedProcessParameter(
		        BANJO.SETTING_ASKTOVERIFYSETTINGS );

		if ( askToVerifySettings.equalsIgnoreCase( 
		        BANJO.UI_ASKTOVERIFYSETTINGS_YES ) ) {
			int intInputChar;
			
			// Note: the settings will have printed at this time (unless the config option
			// has been changed)
			System.out.print( "\n*** " );
			System.out.print(
			        "\n*** You have provided the above parameters for your search. " );
			System.out.print( "\n*** " );
			
			System.out.print(searcherStats);
			System.out.print("\n*** \n*** To confirm and start executing the search, " +
					"press <Enter>. " +
					"Any other key will stop the search. " +
					"\n*** Note: set the askToVerifySettings parameter to 'no' " +
					"if you don't want this confirmation.\n*** \n");
			
			// then process the user input to decide whether to execute
			if ( (intInputChar = System.in.read() ) != 10 ) {
				// Enter = 10
				// 'y' is 121
				//System.out.print(intInputChar);
				
				System.out.print( "\nExecution stopped per your request.\n" );
				return false;
			}
			else {

				System.out.print("\n\nStarting the search execution.\n\n");
			}
		}
		
	    return true;
	}
	
	// --------------------------------------------------------------------
	// Abstract functionality that any derived Searcher needs to provide
	// --------------------------------------------------------------------
	
    /**
     * Executes the search based on the particular search algorithm.
     */
	public abstract void executeSearch() throws Exception;
	
	/**
     * @return Returns the statistics about the particular searcher implementation.
     */
	// Override this method if necessary
	public StringBuffer provideCollectedStatistics() throws Exception {
			    
	    int lineLength = BANJO.FEEDBACKLINELENGTH;
		String prefix = "\n";
		
		StringBuffer searcherStats = 
			new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength ) ); 

		StringBuffer nBestStr = new StringBuffer( BANJO.BUFFERLENGTH_SMALL );
		nBestStr.append( newLinePlusPrefix + "Best " );
		if ( getHighScoreStructureSet().size() == 1 ) {
		    nBestStr.append( "Structure" );
		}
		else {
		    nBestStr.append( getHighScoreStructureSet().size() );
			nBestStr.append( " Structures" );
		}
		searcherStats.append( nBestStr );
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ) ); 
		
		// Now add all the n-best networks
		searcherStats.append( listScores() );
		
		// Add the statistics
		if ( BANJO.CONFIG_DISPLAYSTATISTICS ) {

			searcherStats.append( "\n\n" + BANJO.FEEDBACKDASHEDLINE.
				        substring( 0, lineLength ) ); 
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Search Statistics", 
			        "", null, lineLength ) );
			searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength )+ "\n" ); 
			
			searcherStats.append( "\nStatistics collected in searcher '" + 
			        StringUtil.getClassName(this) + "':" );
			searcherStats.append( " \n");
			searcherStats.append( "  Search completed at ");
			searcherStats.append( timeFormat.format(new Date()) );
			
			searcherStats.append( "\n" );
			searcherStats.append( "  Number of networks examined: ");
			searcherStats.append( getNetworksVisitedGlobalCounter());
			
			searcherStats.append( "\n" );
			searcherStats.append( "  Total time used: ");
			searcherStats.append( StringUtil.formatElapsedTime(
			        Long.parseLong( processData.getDynamicProcessParameter(
			        BANJO.DATA_TOTALTIMEFORSEARCH )), 2, 
			        BANJO.OPTION_TIMEFORMAT_MIXED ));
			
			searcherStats.append( "\n" );
			searcherStats.append( "  High score: ");
			BayesNetStructureI highScoreNetwork = 
			    (BayesNetStructureI) this.getHighScoreStructure();
			searcherStats.append( StringUtil.displayWithFixedDecimals(
			        highScoreNetwork.getNetworkScore(), 
			        BANJO.DIGITSINSCOREDISPLAY ) );
			searcherStats.append( ", first found at iteration ");
			searcherStats.append( highScoreNetwork.getSearchLoopIndex() );
					
			// Note: the sum of the computed and the cached scores will be equal
			// to the sum of additions + deletions + 2*reversal - 
			// (number of [re]starts)*(number of variables) 
	
			searcherStats.append( "\n  Number of restarts: " );
			searcherStats.append( restartCount );
			if ( BANJO.CONFIG_DISPLAYITERATIONRESTARTS ) {
				
				searcherStats.append( "\n  at iterations " );
				searcherStats.append( restartsAtCounts );
			}
		}
		
		return searcherStats;
	}
}
