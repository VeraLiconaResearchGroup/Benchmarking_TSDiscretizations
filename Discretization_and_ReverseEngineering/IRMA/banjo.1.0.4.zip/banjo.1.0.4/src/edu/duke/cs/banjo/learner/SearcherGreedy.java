/*
 * Created on May 17, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.learner;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.learner.components.*;
import edu.duke.cs.banjo.utility.*;

import java.util.*;

/**
 * Implements a greedy search.
 *
 * <p><strong>Details:</strong> <br>
 * - Compatible with "random local move" and "all local moves" proposers. 
 * <br>
 * - Requires that the user specifies several parameters that are greedy-specific and
 *   not used by other searchers (in addition to the standard set of parameters).
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on May 17, 2004
 * 
 * 8/25/200 hjs 1.0.1
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class SearcherGreedy extends Searcher {
	
	// Data that is unique to this Searcher implementation
    protected SearchExecuter searchExecuter;
    protected SearchTerminator searchTerminator;
    
    // Adjustment variable related to restarts. Keeps are feedback
    // numbers nice and "round"
    int innerLoopStart;
	
	// Variables related to the restart of the current bayesnet
	protected long networksVisitedSinceHighScore;
	protected long networksVisitedSinceRestart;
	protected long minNetworksVisitedSinceHighScore;
	protected long minNetworksVisitedBeforeRestart;
	protected long maxNetworksVisitedBeforeRestart;
	
	protected class GlobalSearchExecuter extends SearchExecuter {

		protected void executeSearch() throws Exception {
		    
			BayesNetChange bestChangeInInnerLoop = new BayesNetChange();
			double bestScoreInInnerLoop = unreachableScore;
			double bayesNetScore;
			int validChangesFound = 0;
			boolean isValidChange;
			
			// Execute the outer loop until the stop criteria is met								    
			do {
				
				// Execute the core search loop a specified (namely:
				// maxNetworksVisitedInInnerLoop number) of times
				for ( long networksVisitedInnerLoopCounter=0; 
					networksVisitedInnerLoopCounter<maxNetworksVisitedInInnerLoop; ) {
													
					// hjs 11/24/04 Separated Cycle-checking from proposer class
					isValidChange = false;
					bayesNetScore = unreachableScore;
					bestScoreInInnerLoop = unreachableScore;
											
					// Get the list of changes from the proposer
					suggestedChangeList = 
					    proposer.suggestBayesNetChanges( bayesNetManager );
					
					// Process each BayesNetChange in the list
					Iterator changeListIterator = suggestedChangeList.iterator();
					
					validChangesFound = 0;
					
					while ( changeListIterator.hasNext() ) {
						
						networksVisitedGlobalCounter++;
						networksVisitedSinceHighScore++;
						networksVisitedSinceRestart++;
						networksVisitedInnerLoopCounter++;
												
						suggestedBayesNetChange = 
							(BayesNetChangeI) changeListIterator.next();
						
						if ( suggestedBayesNetChange.getChangeStatus() == 
						    BANJO.CHANGESTATUS_READY ) {
						    
							// Note that the change will be "applied" to the underlying 
							// BayesNet structure in the cycleChecker. If we encounter a
							// cycle, the cycleChecker will undo the change immediately.
							isValidChange = cycleChecker.isChangeValid( bayesNetManager, 
									suggestedBayesNetChange );
						}
						else {

						    // Proposer was not able to come up with a valid change
						    isValidChange = false;
						}
						
						if ( isValidChange ) {
							
							// Since the (valid) change is already applied (to the 
							// bayesNetManager), we can compute the score without 
						    // add'l prep
							bayesNetScore = evaluator.updateNetworkScore(
							        bayesNetManager, suggestedBayesNetChange);								    

							// Store away if we encounter a new "best score" 
							// within this round
							    
							if ( bayesNetScore > bestScoreInInnerLoop 
									|| bestScoreInInnerLoop == unreachableScore ) {
																    
								bestScoreInInnerLoop = bayesNetScore;
								bestChangeInInnerLoop.updateChange( 
										suggestedBayesNetChange );
							}

							// We need to undo the current change, so we can check 
							// the next change
						    bayesNetManager.undoChange( suggestedBayesNetChange );
						    evaluator.adjustNodeScoresForUndo( 
						            suggestedBayesNetChange );
						    
						    validChangesFound++;
						}						
					}

					// Check on the (success of the) proposed changes
					if ( validChangesFound > 0 && bayesNetScore == unreachableScore ) {
					    
					    // This error really should not happen if the problem is set up
					    // correctly. 
					    throw new BanjoException( 
					            BANJO.ERROR_COULDNOTFINDVALIDCHANGE, 
					            "(" + StringUtil.getClassName( this ) + 
					            ".executeSearch) " + 
					            "The global search component could not find " +
					            "a single valid change.\n" +
					            "Please check if your problem settings are feasible."
					            );
					}
					else if ( validChangesFound == 0 ) {
					    
					    // In this case the greedy search exhausted its possibilities.
					    // We indicate that a restart is in order.
					    networksVisitedInnerLoopCounter = maxNetworksVisitedInInnerLoop;
					    networksVisitedSinceRestart = maxNetworksVisitedBeforeRestart;					    
					}
					else {
					    
					    // When a valid change has been found, we proceed by applying
					    // the best change from the proposed set of changes

						// This is a crucial step when we process a lists of changes
						// (because the cached scores stored in the evaluator get out of
						// sync otherwise, see the above "adjustNodeScoresForUndo")
						bestChangeInInnerLoop.setChangeStatus( 
								BANJO.CHANGESTATUS_READY );
						bayesNetManager.applyChange( bestChangeInInnerLoop );
						bayesNetScore = evaluator.updateNetworkScore(
						        bayesNetManager, bestChangeInInnerLoop );			
						
						// Call the decider whether to keep the change (new highscore),
						// or to ignore it
						if ( decider.isChangeAccepted( bestScoreInInnerLoop, 
								bestChangeInInnerLoop )) {
									
							updateHighScoreStructureData( bestScoreInInnerLoop );
						}					
						else {
						    
						    // The current network is not kept: Prepare for the next step
						    // by reverting the structure and the cached node scores back
						    // to the previous network
						    bayesNetManager.undoChange( bestChangeInInnerLoop );
						    evaluator.adjustNodeScoresForUndo( bestChangeInInnerLoop );
						}
						
						// Clear the change
						bestChangeInInnerLoop.resetChange();
					}
					
					// For the global search, need to take all the networks into account
					// that were checked in the exhaustive part
				} // done with inner loop

				searchTerminator.generateFeedback();
			}	
			while ( searchTerminator.checkTerminationCondition() );
			
			finalCleanup();
		}

		protected int sizeOfListOfChanges() {
		    
		    // bound on number of ("single step") local moves
		    return BANJO.CHANGETYPE_COUNT * varCount * varCount;
		}
	}
	
	protected class LocalSearchExecuter extends SearchExecuter {
		
		protected void executeSearch() throws Exception {
		    
			double bayesNetScore;
			boolean isValidChange;
			int attemptedTries;

			innerLoopStart = 1;
			
			// Execute an outer loop until the user-specified stop criteria is met	
			do {
				
			    networksVisitedInnerLoopCounter = innerLoopStart;
			    innerLoopStart = 0;
			    
				// Execute the core search loop a specified (namely:
				// maxNetworksVisitedInInnerLoop) number of times
				while ( networksVisitedInnerLoopCounter < 
				        maxNetworksVisitedInInnerLoop ) {
													
					// hjs 11/24/04 Separated Cycle-checking from proposer class
					isValidChange = false;
					bayesNetScore = unreachableScore;
					
					while ( !isValidChange && 
					        networksVisitedInnerLoopCounter 
					        < maxNetworksVisitedInInnerLoop ) {
						
						// Get the list of changes from the proposer
						suggestedBayesNetChange = proposer.suggestBayesNetChange( 
						        bayesNetManager );
						
						networksVisitedGlobalCounter++;
						networksVisitedSinceHighScore++;
						networksVisitedSinceRestart++;
						networksVisitedInnerLoopCounter++;
						
						if ( suggestedBayesNetChange.getChangeStatus() == 
						    BANJO.CHANGESTATUS_READY ) {
						    
							// Note that the change will be "applied" to the underlying 
							// BayesNet structure in the cycleChecker. If we encounter a
							// cycle, the cycleChecker will undo the change immediately.
							isValidChange = cycleChecker.isChangeValid( bayesNetManager, 
									suggestedBayesNetChange );
						}					
					}
					
					if ( isValidChange ) {
						
						// Since any (valid) change is already applied (to the 
						// bayesNetManager), we can compute the score without add'l prep
						bayesNetScore = evaluator.updateNetworkScore(
						        bayesNetManager, suggestedBayesNetChange);

					    // Call the decider whether to keep the change (new highscore),
						// or to ignore it
						if ( decider.isChangeAccepted( 
						        bayesNetScore, suggestedBayesNetChange )) {
									
							updateHighScoreStructureData( bayesNetScore );
						}					
						else {
						    
						    // The current network is not kept: Prepare for the next step by
						    // reverting the structure and the cached node scores back to
						    // the previous network
						    bayesNetManager.undoChange( suggestedBayesNetChange );
						    evaluator.adjustNodeScoresForUndo( suggestedBayesNetChange );
						}
					}
				} // done with inner loop
				
				searchTerminator.generateFeedback();
			}	
			while ( searchTerminator.checkTerminationCondition() );

			finalCleanup();
		}

		protected int sizeOfListOfChanges() {
		    
		    // 1 local move
		    return 1;
		}
	}
	
	protected class fixedNumberOfRestartsTerminator extends SearchTerminator {
		
		protected boolean checkTerminationCondition() throws Exception {

		    // hjs 8/23/05 Change the logic slightly to enable test runs with 0 restarts
	        if ( ( networksVisitedSinceRestart >= minNetworksVisitedBeforeRestart &&
					networksVisitedSinceHighScore >= minNetworksVisitedSinceHighScore ) ||
					networksVisitedSinceRestart >= maxNetworksVisitedBeforeRestart ) {
    			
				if ( restartCount >= maxRestarts ) {

					elapsedTime = System.currentTimeMillis() - startTime;
			        return false;
			    }
				restartCount++;
			
			  	// First: restart the network
			    bayesNetManager.initializeBayesNet();
				restartsAtCounts.append( ", " + networksVisitedGlobalCounter );
				
				// Second: reset the score
				currentBestScoreSinceRestart = 
				    evaluator.computeInitialNetworkScore(bayesNetManager);
				
				// Third: reset the current high score (the working copy; 
				//		the global copy is tracked in the high-score-set)
				highScoreStructureSinceRestart = new BayesNetStructure( 
				        bayesNetManager.getCurrentParents(), 
						currentBestScoreSinceRestart, 
						networksVisitedGlobalCounter );
				
				// Fourth: Reset the decider
				decider.setCurrentScore( currentBestScoreSinceRestart );
				
				// Finally: reset the counter
				networksVisitedSinceRestart = 0;
			}	
			return true;
		}
	
		protected void generateFeedback() throws Exception {
		    
		    elapsedTime = getElapsedTime();
  	    
		    if ( trackIntermediateResults ) { 
		    
		        if ( elapsedTime >= nextReportTime ) {
			        
			      	// Write intermediate result to file:
			        StringBuffer bestScoresSoFar = new StringBuffer(
			                BANJO.BUFFERLENGTH_STAT_INTERNAL );
			        bestScoresSoFar.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength ) ); 

			        bestScoresSoFar.append( StringUtil.formatRightLeftJustified( 
				            newLinePlusPrefix, " Intermediate report", 
					        "Best scores so far", null, lineLength ) );
				    
			        bestScoresSoFar.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength ) );
			        bestScoresSoFar.append( listScores() );
			        bestScoresSoFar.append( "\n" );
			        
				    searcherStatistics.recordSpecifiedData( 
				            bestScoresSoFar );
				    
				    nextReportTime += reportTimeDelta;
			    }
		    }
		    
			// Deal with time checking first, since this will likely be the preferred stop
			// criterion for most users
			if ( displayFeedbackByTime ) {
			    
			    // Convention: we use only the display criteria for the "counter" that occurs
			    // first (time or loop count). Note that our main search loops exits as soon as
			    // one of the criteria is observed.
			    	
				if ( elapsedTime >= nextFeedbackTime ) {
				     
				    messageToDisplay.append( " Elapsed time: " );
				    messageToDisplay.append( StringUtil.fillSpacesLeft(
				            ( StringUtil.formatElapsedTime( 
				            elapsedTime, numberOfDecimals,
				            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
				            timePaddingLength ) );
				    messageToDisplay.append( ", with " );

				    messageToDisplay.append( StringUtil.fillSpacesLeft( 
				            ( new Long( restartCount )).toString(), restartPaddingLength ) );
				    messageToDisplay.append( " of " );
				    messageToDisplay.append( maxRestarts );
					messageToDisplay.append( " restarts completed." );
				    
				    messageToDisplay.append( " Networks examined: " );
				    messageToDisplay.append(  StringUtil.fillSpacesLeft( 
				            ( new Long( networksVisitedGlobalCounter ) ).toString(), 
				            loopPaddingLength ) );
				    messageToDisplay.append( "." );
				    
				    nextFeedbackTime += feedbackTimeDelta;
				}    		
			}
			
			if ( messageToDisplay.length() > 1 ) {
			 
			    searcherStatistics.recordSpecifiedData( messageToDisplay );
				messageToDisplay = new StringBuffer(BANJO.BUFFERLENGTH_SMALL );
			}
		}
	}
	
	protected class timeAndIterationTerminator extends SearchTerminator {
		   
		protected boolean checkTerminationCondition() throws Exception {
		    
			boolean timeRemaining = true;
			boolean searchLoopsRemaining = true;
			
			// Check if finished
			
			// ------------------
			// Restart the search:
			// ------------------
			// Logic for restarting: "Always visit at least minNetworksVisitedBeforeRestart
			// networks after a restart, AND at least minNetworksVisitedSinceHighScore after
			// the last highScore was found"  OR
			// "Visit at most maxNetworksVisitedBeforeRestart after a restart"
			if ( ( networksVisitedSinceRestart >= minNetworksVisitedBeforeRestart &&
					networksVisitedSinceHighScore >= minNetworksVisitedSinceHighScore ) ||
					networksVisitedSinceRestart >= maxNetworksVisitedBeforeRestart )
					 {
			
			  	// - First restart the network
			    bayesNetManager.initializeBayesNet();
			    			
				restartCount++;
				restartsAtCounts.append( ", " + networksVisitedGlobalCounter );
				
				//- Second the score
				currentBestScoreSinceRestart = 
				    evaluator.computeInitialNetworkScore(bayesNetManager);
				
				//- Third the current high score (the working copy; the global copy is
				//   		tracked in the high-score-set)
				highScoreStructureSinceRestart = new BayesNetStructure( 
				        bayesNetManager.getCurrentParents(), 
						currentBestScoreSinceRestart, 
						networksVisitedGlobalCounter );
				
				//- Fourth: Reset the decider
				decider.setCurrentScore( currentBestScoreSinceRestart );
				
				//- Finally, reset the counter
				networksVisitedSinceRestart = 0;
			}
					
			elapsedTime = System.currentTimeMillis() - startTime;

			// Check if we reached the time or max search loop limit
			if ( maxSearchTime > 0 && maxSearchTime <= elapsedTime ) {
			    
			    timeRemaining = false;
			}
			if ( ( maxSearchLoops >= 0 && maxSearchLoops <= networksVisitedGlobalCounter)
				|| maxNetworksVisitedInInnerLoop == 0 ) {
			    
			    searchLoopsRemaining = false;
			}
			
			return ( timeRemaining && searchLoopsRemaining );
		}
	
		protected void generateFeedback() throws Exception {
		    
		    elapsedTime = getElapsedTime();
	  	    
		    if ( trackIntermediateResults ) { 
		        
			    if ( elapsedTime >= nextReportTime ) {
			        
			      	// Write intermediate result to file:
			        StringBuffer bestScoresSoFar = new StringBuffer(
			                BANJO.BUFFERLENGTH_STAT_INTERNAL );
			        bestScoresSoFar.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength ) ); 

			        bestScoresSoFar.append( StringUtil.formatRightLeftJustified( 
				            newLinePlusPrefix, " Intermediate report", 
					        "Best scores so far", null, lineLength ) );
				    
			        bestScoresSoFar.append( BANJO.FEEDBACKDASHEDLINE.
					        substring( 0, lineLength ) );
			        bestScoresSoFar.append( listScores() );
			        bestScoresSoFar.append( "\n" );
			        
				    searcherStatistics.recordSpecifiedData( 
				            bestScoresSoFar );
				    
				    nextReportTime += reportTimeDelta;
			    }
		    }

			// Deal with time checking first, since this will likely be the preferred stop
			// criterion for most users
			if ( displayFeedbackByTime ) {
			    			    
			    // Convention: we use only the display criteria for the "counter" that occurs
			    // first (time or loop count). Note that our main search loops exits as soon as
			    // one of the criteria is observed.
			    	
				if (  elapsedTime >= nextFeedbackTime ) {
				    
				    // The next 2 lines simply format the output to show some extra decimals
				    displayPercent = Math.round( 1000 * elapsedTime / maxSearchTime );
				    displayPercent /= 10;
				    if ( displayPercent > 100 ) displayPercent = 100;
				    		    
				    messageToDisplay.append( "Search " + 
				            StringUtil.fillSpacesLeft( 
				                    ( new Double( displayPercent).toString() ), 
				                    percentPaddingLength ) +
				    		"% completed." );
				    
				    messageToDisplay.append( " Elapsed time: " );
				    messageToDisplay.append( StringUtil.fillSpacesLeft(
				            ( StringUtil.formatElapsedTime( 
				            elapsedTime, numberOfDecimals,
				            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
				            timePaddingLength ) );
				    messageToDisplay.append( "." );
				    
				    messageToDisplay.append( " Time remaining: " );
				    messageToDisplay.append( StringUtil.fillSpacesLeft(
				            ( StringUtil.formatElapsedTime( 
				            maxSearchTime - elapsedTime, numberOfDecimals,
				            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
				            timePaddingLength ) );
				    messageToDisplay.append( "." );
				    
				    messageToDisplay.append( " Networks examined: " );
				    messageToDisplay.append(  StringUtil.fillSpacesLeft( 
				            ( new Long( networksVisitedGlobalCounter ) ).toString(), 
				            loopPaddingLength ) );
				    messageToDisplay.append( "." );
				    
				    nextFeedbackTime += feedbackTimeDelta;
				}    		
			}
			else {
			    
				if ( networksVisitedGlobalCounter*numberOfProgressReports 
				        >= maxSearchLoops*percentLevel && 
				        maxSearchLoops > 0 ) {
							    
				    // The next 2 lines simply format the output to show some extra decimal(s)
				    displayPercent = Math.round( 1000*networksVisitedGlobalCounter/maxSearchLoops );
				    displayPercent /= 10;
				    if ( displayPercent > 100 ) displayPercent = 100;
				    
				    messageToDisplay.append( "Search " + 
				            StringUtil.fillSpacesLeft( 
				                    ( new Double( displayPercent).toString() ), 
				                    percentPaddingLength ) +
				    		"% completed." );
				    
				    messageToDisplay.append( " Networks examined: " );
				    messageToDisplay.append(  StringUtil.fillSpacesLeft( 
				            ( new Long( networksVisitedGlobalCounter ) ).toString(), 
				            loopPaddingLength ) );
				    
				    messageToDisplay.append( ". Elapsed time: " );
				    messageToDisplay.append( StringUtil.fillSpacesLeft(
				            ( StringUtil.formatElapsedTime( 
				            elapsedTime, numberOfDecimals,
				            BANJO.OPTION_TIMEFORMAT_MIXED )).toString(), 
				            timePaddingLength ) );
				    messageToDisplay.append( "." );
			
				    percentLevel++;
				}
			}
			
			if ( messageToDisplay.length() > 1 ) {
			 
			    searcherStatistics.recordSpecifiedData( messageToDisplay );
				messageToDisplay = new StringBuffer(BANJO.BUFFERLENGTH_SMALL );
			}
		}
	}
	
	public SearcherGreedy( Settings processData ) throws Exception {
				
		super( processData );

		int statisticsChoice;
		String strSettingChoice;
		String newLinePlusPrefix = "\n" + BANJO.FEEDBACKDASH + " ";
		int lineLength = BANJO.FEEDBACKLINELENGTH;
		
		networksVisitedSinceHighScore = 0;
		networksVisitedSinceRestart = 0;
		
		//----------------------------------------------
		// Create the core objects needed for the search
		//----------------------------------------------
		this.bayesNetManager = new BayesNetManager( processData );

		// Decide on the stopping criterion
		if ( maxRestarts >= 0 ) {
		    
		    searchTerminator = new fixedNumberOfRestartsTerminator();
		}
		else {
		    
		    searchTerminator = new timeAndIterationTerminator();
		}

		// Set up which Proposer-Evaluator-Decider combo we want to use based on user 
		// input (i.e., via initialSettings file). We apply rules to ensure that only 
		// acceptable combinations are selected by the user, and apply appropriate 
		// defaults where necessary.
		// Can't use string in switch, so use integer mapping to global constants:	
		strSettingChoice = "";
		if ( processData.getValidatedProcessParameter( 
		        BANJO.SETTING_PROPOSERCHOICE )
		        .equalsIgnoreCase( BANJO.UI_PROP_RANDOMLOCALMOVE )) { 
			
			this.proposer = new ProposerRandomLocalMove(
			        bayesNetManager, processData );
			searchExecuter = new LocalSearchExecuter();
		}
		else if ( processData.getValidatedProcessParameter( 
		        BANJO.SETTING_PROPOSERCHOICE )
		        .equalsIgnoreCase( BANJO.UI_PROP_ALLLOCALMOVES )) { 
			
			this.proposer = new ProposerAllLocalMoves(
			        bayesNetManager, processData );
			searchExecuter = new GlobalSearchExecuter();
		}
		else {
			
			// Default case: 
			this.proposer = new ProposerRandomLocalMove( 
			        bayesNetManager, processData );
			searchExecuter = new LocalSearchExecuter();
			
			strSettingChoice = " defaulted to ";
		}
		strSettingChoice = strSettingChoice + StringUtil.getClassName(proposer);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Proposer:", strSettingChoice, null, lineLength ) );
		
		// Evaluator for DBN	
		strSettingChoice = "";
		if ( processData.getValidatedProcessParameter( 
	        	BANJO.SETTING_EVALUATORCHOICE )
		        .equalsIgnoreCase( BANJO.UI_EVAL_BDE )) { 
			
			this.evaluator = new EvaluatorBDe( bayesNetManager, processData );
		}
		else {
			
			// Default case: DBN Evaluator handles static BN as special case
			this.evaluator = new EvaluatorBDe( bayesNetManager, processData );
			
			strSettingChoice = " defaulted to ";
		}
		strSettingChoice = strSettingChoice + StringUtil.getClassName(evaluator);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Evaluator:", strSettingChoice, null, lineLength ) );
		
		// Cycle-checker	
		strSettingChoice = "";
		if ( BANJO.CONFIG_DFS_CYCLECHECKING ) {
		    
		    cycleChecker = new CycleCheckerDFS( bayesNetManager, processData );
		}
		else {
		    
		    cycleChecker = new CycleCheckerBFS( bayesNetManager, processData );
			
			strSettingChoice = " defaulted to ";
		}
		strSettingChoice = strSettingChoice + StringUtil.getClassName(cycleChecker);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Cycle checker:", strSettingChoice, null, lineLength ) );
	        
	    // Compute the initial score for our Bayesnet
		currentBestScoreSinceRestart = 
		    evaluator.computeInitialNetworkScore(bayesNetManager);
		nBestThresholdScore = currentBestScoreSinceRestart;
		
		strSettingChoice = "";
		if ( processData.getValidatedProcessParameter( 
		        BANJO.SETTING_DECIDERCHOICE )
		        .equalsIgnoreCase( BANJO.UI_DEC_GREEDY )) {
			
			this.decider = new DeciderGreedy( bayesNetManager,
			        processData, currentBestScoreSinceRestart );
		}
		else {
			// Default case:
				
			this.decider = new DeciderGreedy( bayesNetManager,
			        processData, currentBestScoreSinceRestart );
			
			strSettingChoice = " defaulted to ";
		}
		strSettingChoice = strSettingChoice + StringUtil.getClassName(decider);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Decider:", strSettingChoice, null, lineLength ) );
		
		// Load the settings specific to this searcher
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ) ); 
		try {
			minNetworksVisitedSinceHighScore = Long.parseLong( 
			        processData.getValidatedProcessParameter( 
			        BANJO.SETTING_MINPROPOSEDNETWORKSAFTERHIGHSCORE ) );
		}
		catch (Exception e) {
			
			// There's only a NumberFormatException to catch; fix it:
			minNetworksVisitedSinceHighScore = 0;
		}
		// 
		if (minNetworksVisitedSinceHighScore < 0) {
			minNetworksVisitedSinceHighScore = 
				BANJO.DEFAULT_MINPROPOSEDNETWORKSHIGHSCORE;
		}
		strSettingChoice = Long.toString( minNetworksVisitedSinceHighScore );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Min. proposed networks after high score:", 
		        strSettingChoice, null, lineLength ) );
		// ---
		try {
			minNetworksVisitedBeforeRestart = Long.parseLong( 
			        processData.getValidatedProcessParameter( 
			        BANJO.SETTING_MINPROPOSEDNETWORKSBEFORERESTART ) );
		}
		catch (Exception e) {
			
			// There's only a NumberFormatException to catch; fix it:
			minNetworksVisitedBeforeRestart = 0;
			
			// Should we tell the user?
			// TODO?
		}
		// Can't restart within inner loop anyway
		if ( minNetworksVisitedBeforeRestart < maxNetworksVisitedInInnerLoop ) {
			minNetworksVisitedBeforeRestart = maxNetworksVisitedInInnerLoop;
		}
		strSettingChoice = Long.toString( minNetworksVisitedBeforeRestart );
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Min. proposed networks before restart:", 
		        strSettingChoice, null, lineLength ) );
		// ---
		try {
			maxNetworksVisitedBeforeRestart = Long.parseLong( 
			        processData.getValidatedProcessParameter(
			        BANJO.SETTING_MAXPROPOSEDNETWORKSBEFORERESTART ) );
		}
		catch (Exception e) {
			
			// There's only a NumberFormatException to catch; fix it:
			maxNetworksVisitedBeforeRestart = 0;
		}
		// 
		if ( maxNetworksVisitedBeforeRestart <= minNetworksVisitedBeforeRestart ) {
			maxNetworksVisitedBeforeRestart = minNetworksVisitedBeforeRestart + 1;
		}
		strSettingChoice = Long.toString( maxNetworksVisitedBeforeRestart);
		searcherStats.append( StringUtil.formatRightLeftJustified( 
		        newLinePlusPrefix, "Max. proposed networks before restart:", 
		        strSettingChoice, null, lineLength ) );
		// TODO: Do we want to compare minNetworksVisitedSinceHighScore with
		// minNetworksVisitedBeforeRestart?
		
		// Restart method
		if ( processData.getValidatedProcessParameter( 
	            BANJO.SETTING_RESTARTWITHRANDOMNETWORK).equalsIgnoreCase( 
	                BANJO.UI_RESTARTWITHRANDOMNETWORK_YES )) {

			strSettingChoice = "use random network";
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Restart method:", 
			        strSettingChoice, null, lineLength ) );
			
			strSettingChoice = processData.getValidatedProcessParameter( 
			        BANJO.SETTING_MAXPARENTCOUNTFORRESTART );
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "  with max. parent count:",
			        strSettingChoice, null, lineLength ) );
	    }
	    else {

			strSettingChoice = "use initial network";
			searcherStats.append( StringUtil.formatRightLeftJustified( 
			        newLinePlusPrefix, "Restart method:", 
			        strSettingChoice, null, lineLength ) );
	    }		
		
		// Set the initial network as the current best score:
		highScoreStructureSinceRestart = new BayesNetStructure( 
		        bayesNetManager.getCurrentParents(), 
				currentBestScoreSinceRestart, 0 );
		
				
		highScoreStructureSet = new TreeSet();
		
	    highScoreStructureSet.add( new BayesNetStructure( 
	            highScoreStructureSinceRestart,
	            currentBestScoreSinceRestart, 
                networksVisitedGlobalCounter ));

		// Set up the container for the list of changes
		suggestedChangeList = new ArrayList( searchExecuter.sizeOfListOfChanges() );
		// 
		searcherStats.append( BANJO.FEEDBACKDASHEDLINE.
		        substring( 0, lineLength ));
		
		searcherStatistics.recordSpecifiedData( searcherStats );
		
		// Reset the string buffer
		searcherStats = new StringBuffer( BANJO.BUFFERLENGTH_STAT_INTERNAL );
	}
	
	public void executeSearch() throws Exception {
		
		// Feedback of selected settings to the user, with option to stop the search
		if ( !askToVerifySettings() ) {
		    
		    return;
		}
		
		// Compute the time it took for preparation of the search
		elapsedTime = System.currentTimeMillis() - startTime;
		processData.setDynamicProcessParameter ( 
		        BANJO.DATA_TOTALTIMEFORPREP, Long.toString( elapsedTime ) );
		
		// Record the initial data
		searcherStatistics.recordInitialData(this);

		// (Re)start the timer for the actual search 
		startTime = System.currentTimeMillis();

		// Execute the actual search code (which varies between global and local
		// search strategies)
		searchExecuter.executeSearch();
	}	
			
	protected void updateHighScoreStructureData( double bayesNetScore ) 
		throws Exception {			
		
		// If we actually have a new high score, "record" the related counter
		if ( bayesNetScore > currentBestScoreSinceRestart ) {
			networksVisitedSinceHighScore = 0;
		}
		// Even though the naming may seem off, we need to update the 
		// "currentHighScoreStructure"
		currentBestScoreSinceRestart = bayesNetScore;
		highScoreStructureSinceRestart.assignBayesNetStructure(
				bayesNetManager.getCurrentParents(), 
				currentBestScoreSinceRestart,
				networksVisitedGlobalCounter );					
		
		// Note: Since the annealer accepts scores that are below the 
		// currentBest, we need to modify the condition for acceptance 
		// into the set of nBest scores
		if ( nBestCount < nBestMax ) {
			
			// The nBest container is not yet filled up
		    highScoreStructureSet.add( new BayesNetStructure( 
		            highScoreStructureSinceRestart,
		            currentBestScoreSinceRestart, 
	                networksVisitedGlobalCounter ));
		    
			// update the count of tracked highscores
			nBestCount = highScoreStructureSet.size();
			
			// Update the threshold score
			BayesNetStructureI bns = (BayesNetStructureI) highScoreStructureSet.last();
			nBestThresholdScore = bns.getNetworkScore();
		}
		else if ( bayesNetScore > nBestThresholdScore ) {
		    
			// Once the N-best container is filled up with N entries, we only 
		    // proceed with updating the n-Best container when we encounter 
		    // a "better" score (defined here as ">=")

		    int sizeBefore = highScoreStructureSet.size();

			// Add the new network to the nBest set
		    highScoreStructureSet.add( new BayesNetStructure( 
		            highScoreStructureSinceRestart,
		            bayesNetScore, 
	                networksVisitedGlobalCounter ));

		    int sizeAfter = highScoreStructureSet.size();

		    // If both sizes are the same, then the network to be added
		    // is already stored. Otherwise, we need to remove the now
		    // lowest scoring network
		    if ( sizeBefore < sizeAfter ) {
		        
		        // Remove the network with the lowest score from the n-best
		        // set of networks
				highScoreStructureSet.remove( highScoreStructureSet.last());
		    }
		    
			// Finally, we need to update the new threshold score:
			BayesNetStructureI bns = (BayesNetStructureI) highScoreStructureSet.last();
			nBestThresholdScore = bns.getNetworkScore();
		}
	}
	
	public void updateProcessData( Settings processData ) {}
}