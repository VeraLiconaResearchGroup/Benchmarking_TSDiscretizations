/*
 * Created on Apr 13, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.learner.components;

import java.util.HashMap;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.utility.*;


/**
 * Combines common code shared by the different evaluator implementations. 
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 13, 2004
 * 
 * 9/6/2005		hjs 1.0.3 	Defect in constructor: Make use of caching 
 * 							arrays conditional, so they are only created
 * 							when needed
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public abstract class Evaluator implements EvaluatorI {
	
	// Cache frequently used values 
	protected final int varCount;
	protected final int minMarkovLag;
	protected final int maxMarkovLag;
	protected final int observationCount;  
	
	// Only one observations data set should be tied to this EvaluatorBDeStatic object:
	protected final Observations observations;
	
	// Container for caching individual node scores
	protected NodeScoreCacheItemI currentNodeScoreHashItem;
	protected NodeScoreCacheItemI retrievedNodeScoreHashItem;
	protected HashMap nodeScoreHashMap;
		
	// Special "fast-access" cache for nodes with low parent count
	protected double[] fastNodeScoreCacheFor0parents;
	protected double[][] fastNodeScoreCacheFor1parent;
	protected double[][][] fastNodeScoreCacheFor2parents;

	// Container for feedback strings
	protected StringBuffer feedbackBuffer;   
    
	// Score of the LAST network structures visited
	protected double cachedNetworkScore = 0;
	
	// Array for caching the scores for the individual nodes.
	protected double cachedNodeScores[];
	// When a change gets rejected in the searcher, we need to be able to
	// properly roll back
	protected double cachedCurrentNodePreviousScore;
	protected double cachedParentNodePreviousScore;
	protected double cachedNetworkPreviousScore;
	
	// Basic statistics: how many changes of each type do we consider
	protected long computedScoreTracker=0;
	// Track the scores that are being fetched from one of the cache mechanisms
	// (indexed by the number of parents that the node had)
	protected long[] fetchedCachedScoreTracker;
	protected long[] placedInCacheScoreTracker;
	protected long crossCheckCachedScoreTracker = 0;
	protected int highestParentCountEncountered = 0;
	
	// Access to the global settings (static and dynamic)
	Settings processData;
	
	/**
	 * Used in the log-gamma computation. Declared here for
	 * optimized performance.
	 */
	static double b[] = new double[19];
	
	
	public Evaluator( BayesNetManagerI _initialBayesNet, Settings _processData ) 
		throws Exception {
	    
	    this.processData = _processData;

		varCount = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_VARCOUNT ));
		minMarkovLag = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_MINMARKOVLAG ));
		maxMarkovLag = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_MAXMARKOVLAG ));
		observationCount = Integer.parseInt( _processData.getValidatedProcessParameter(
		        BANJO.SETTING_OBSERVATIONCOUNT ));

		// Get access to the observations associated with the bayes net.
		// Make observations truly "final", by seperating it from the reference
		// to the processData's copy
		observations = new Observations( processData.getObservations() );
		
		// Since the value counts have changed after we created the local 
		// observations matrix, we need to recompute them here:
		observations.computeMaxValueCounts();
		
		// Create the array for holding the score for each node.
		cachedNodeScores = new double[varCount];
		
		// Create an object used for caching the individual node scores
		// and the network scores
		currentNodeScoreHashItem = new NodeScoreCacheItem();
		
		// Create the hash tables
		nodeScoreHashMap = new HashMap( BANJO.INITIALHASHSIZE );
		
		if ( BANJO.DEV_USECACHE ) {

			// Create the array for the fast nodeScore cache (Note that the last value of the 
			// second index will be used for "0 parents" case)
			// Note also that we could save space by using (maxMarkovLag-minMarkovLag+1)
			// instead of (maxMarkovLag+1) as a factor for several dimensions below
			
		    // 9/6/2005 hjs 1.0.3 Only create the large caching arrays when they are needed
		    switch (BANJO.DEV_MAXLEVELFORFASTCACHE)
		    {
		    case 0:
		        
				fastNodeScoreCacheFor0parents = new double[varCount];
				break;

		    case 1:
		        
				fastNodeScoreCacheFor0parents = new double[varCount];
				fastNodeScoreCacheFor1parent = 
				    new double[varCount][varCount * ( maxMarkovLag+1 )];
				break;

		    case 2:
		        
				fastNodeScoreCacheFor0parents = new double[varCount];
				fastNodeScoreCacheFor1parent = 
				    new double[varCount][varCount * ( maxMarkovLag+1 )];
				fastNodeScoreCacheFor2parents = new double[varCount]
				        [varCount * ( maxMarkovLag+1 )][varCount * ( maxMarkovLag+1 )];
				break;
				
			default:
			    
			    throw new BanjoException( BANJO.ERROR_INVALID_EVALUATOR,
			            "Currently the fast cache can only handle up to 2 parents." );
		    }
		}
				
		// Set up the tracking for the caching mechanism
		String tmpParentCount = _processData.getValidatedProcessParameter( 
		        BANJO.SETTING_MAXPARENTCOUNT );
		int maxTrackingSize = Integer.parseInt( 
	            _processData.getValidatedProcessParameter( 
	                    BANJO.SETTING_MAXPARENTCOUNT ) ) + 1;
		//-- 8/29/2005 hjs 1.0.1
		if ( maxTrackingSize < BANJO.DEV_MAXLEVELFORFASTCACHE + 1 ) {
		    
		    maxTrackingSize = BANJO.DEV_MAXLEVELFORFASTCACHE + 1;
		}
		//--
	    fetchedCachedScoreTracker = new long[ maxTrackingSize ];
	    placedInCacheScoreTracker = new long[ maxTrackingSize ];
	    for ( int i = 0; i < maxTrackingSize; i++ ) {
	        
	        fetchedCachedScoreTracker[i] = 0;
	        placedInCacheScoreTracker[i] = 0;
	    }
	    
	    // simple optimization: assign values once:
		b[1]  = -0.0761141616704358;  b[2]  = 0.0084323249659328;
		b[3]  = -0.0010794937263286;  b[4]  = 0.0001490074800369;
		b[5]  = -0.0000215123998886;  b[6]  = 0.0000031979329861;
		b[7]  = -0.0000004851693012;  b[8]  = 0.0000000747148782;
		b[9]  = -0.0000000116382967;  b[10] = 0.0000000018294004;
		b[11] = -0.0000000002896918;  b[12] = 0.0000000000461570;
		b[13] = -0.0000000000073928;  b[14] = 0.0000000000011894;
		b[15] = -0.0000000000001921;  b[16] = 0.0000000000000311;
		b[17] = -0.0000000000000051;  b[18] = 0.0000000000000008;
	}
	
	// Wrapper around logGamma from a numerical library,
	// or for using a lookup table
	protected double logGamma(final double arg) {
		
		return loggamma(arg);
	}
	
	/* 
	 * The loggamma function implementation as used below is from
	 * Hang T. Lau's "A Numerical Library in Java for Scientists and Engineers"
	 * Chapman & Hall/CRC, 2004, which is a Java translation of the NUMAL 
	 * procedures originally developed at the Mathematical Centre, Amsterdam.
	 */
	protected static double loggamma(double x)
	// Basic optimization applied (considering that we call this function over and over)
	{
		int i;
		double r,x2,y,f,u0,u1,u,z;

		if (x > 13.0) {
			r=1.0;
			while (x <= 22.0) {
				r /= x;
				x += 1.0;
			}
			x2 = -1.0/(x*x);
			r=Math.log(r);
			return Math.log(x)*(x-0.5)-x+r+0.918938533204672+
	           (((0.595238095238095e-3*x2+0.793650793650794e-3)*x2+
	           0.277777777777778e-2)*x2+0.833333333333333e-1)/x;
		} else {
			f=1.0;
			u0=u1=0.0;
			if (x < 1.0) {
				f=1.0/x;
				x += 1.0;
			} else
				while (x > 2.0) {
					x -= 1.0;
					f *= x;
				}
			f=Math.log(f);
			y=x+x-3.0;
			z=y+y;
			for (i=18; i>=1; i--) {
				u=u0;
				u0=z*u0+b[i]-u1;
				u1=u;
			}
			return (u0*y+0.491415393029387-u1)*(x-1.0)*(x-2.0)+f;
		}
	}

	// Original, non-optimized code
	private static double loggamma_orig(double x)
	{
		int i;
		double r,x2,y,f,u0,u1,u,z;
		double b[] = new double[19];

		if (x > 13.0) {
			r=1.0;
			while (x <= 22.0) {
				r /= x;
				x += 1.0;
			}
			x2 = -1.0/(x*x);
			r=Math.log(r);
			return Math.log(x)*(x-0.5)-x+r+0.918938533204672+
	           (((0.595238095238095e-3*x2+0.793650793650794e-3)*x2+
	           0.277777777777778e-2)*x2+0.833333333333333e-1)/x;
		} else {
			f=1.0;
			u0=u1=0.0;
			b[1]  = -0.0761141616704358;  b[2]  = 0.0084323249659328;
			b[3]  = -0.0010794937263286;  b[4]  = 0.0001490074800369;
			b[5]  = -0.0000215123998886;  b[6]  = 0.0000031979329861;
			b[7]  = -0.0000004851693012;  b[8]  = 0.0000000747148782;
			b[9]  = -0.0000000116382967;  b[10] = 0.0000000018294004;
			b[11] = -0.0000000002896918;  b[12] = 0.0000000000461570;
			b[13] = -0.0000000000073928;  b[14] = 0.0000000000011894;
			b[15] = -0.0000000000001921;  b[16] = 0.0000000000000311;
			b[17] = -0.0000000000000051;  b[18] = 0.0000000000000008;
			if (x < 1.0) {
				f=1.0/x;
				x += 1.0;
			} else
				while (x > 2.0) {
					x -= 1.0;
					f *= x;
				}
			f=Math.log(f);
			y=x+x-3.0;
			z=y+y;
			for (i=18; i>=1; i--) {
				u=u0;
				u0=z*u0+b[i]-u1;
				u1=u;
			}
			return (u0*y+0.491415393029387-u1)*(x-1.0)*(x-2.0)+f;
		}
	}

		/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.learner.EvaluatorI#computeInitialNetworkScore(
	 * 		edu.duke.cs.banjo.bayesnet.BayesNet)
	 */
	abstract public double computeInitialNetworkScore(
	        BayesNetManagerI currentBayesNetManager) throws Exception;

	/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.learner.EvaluatorI#updateNetworkScore(
	 * 		edu.duke.cs.banjo.bayesnet.BayesNet, edu.duke.cs.banjo.bayesnet.BayesNetChange)
	 */
	abstract public double updateNetworkScore(
		BayesNetManagerI currentBayesNetManager,
		BayesNetChangeI currentBayesNetChange) throws Exception;

	/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.learner.EvaluatorI#adjustNodeScoresForUndo(
	 * 		edu.duke.cs.banjo.bayesnet.BayesNetChange)
	 */
    abstract public void adjustNodeScoresForUndo( 
            BayesNetChangeI suggestedBayesNetChange ) throws Exception;
	
    // Placeholder for future use
	public void updateProcessData( Settings processData ) throws Exception {};

	// Override this method to provide whatever statistics needs
	// to be collected in a particular evaluator
	public StringBuffer provideCollectedStatistics() throws Exception { 
		
		StringBuffer stats = 
			new StringBuffer(BANJO.BUFFERLENGTH_STAT );

		stats.append(	"\nStatistics collected in evaluator '");
		stats.append( StringUtil.getClassName(this) );
		stats.append( "':" );
		
		// Note: the sum of the computed and the cached scores will be equal
		// to the sum of additions + deletions + 2*reversal - 
		// (number of [re]starts)*(number of variables) 
		
		stats.append( "\n  Scores computed:          " );
		stats.append( computedScoreTracker );
		
		int maxParentCount = Integer.parseInt( 
	            processData.getValidatedProcessParameter( 
	                    BANJO.SETTING_MAXPARENTCOUNT ) );
		
		
			
		if ( !BANJO.DEV_USECACHE ) {
		    
		    stats.append( "     (Cache disabled)" );
		}
		else {
		    
			stats.append( "\n  Scores (cache)            " );
			stats.append( StringUtil.fillSpaces( "placed" , 15 ) );
			stats.append( StringUtil.fillSpaces( "fetched" , 15 ) );
		    for ( int i=0; i<= maxParentCount; i++ ) {

			    stats.append( "\n      with " );
			    stats.append( i );
			    stats.append( " parents:       " );
			    stats.append( StringUtil.fillSpaces( 
				           Long.toString( placedInCacheScoreTracker[i] ), 15 ) );
			    stats.append( StringUtil.fillSpaces( 
				           Long.toString( fetchedCachedScoreTracker[i] ), 15 ) );
			}
		}

		return stats;
	};
}
