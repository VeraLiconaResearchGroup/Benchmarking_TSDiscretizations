/*
 * Created on Dec 20, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.learner.components;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.utility.BANJO;
import edu.duke.cs.banjo.utility.BanjoException;
import edu.duke.cs.banjo.utility.Settings;

import java.util.*;

/**
 * Proposes a list of all BayesNetChanges that can be applied in a single step (using
 * addition, deletion, or reversal of a single edge), based on the current network 
 * configuration.
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Dec 20, 2004
 * 
 * 8/25/200 hjs 1.0.1: Add conditions to check proposed changes against maxParentCount
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class ProposerAllLocalMoves extends Proposer {
	
	protected final int bayesNetChangeSelectLimit;
		
	// Constructor, using the base class constructor
	public ProposerAllLocalMoves(BayesNetManagerI initialBayesNet, 
			Settings processData) throws Exception {
		
		super(initialBayesNet, processData);
		
		// set the limit for the number of attempts to select a bayesNetChange
		bayesNetChangeSelectLimit = BANJO.LIMITFORTRIES;
		
		// Create the list for holding all possible changes for the step
		changeList = new ArrayList();
	}
	
	public List suggestBayesNetChanges(
	        final BayesNetManagerI bayesNetManager ) throws Exception {
		
		// Clear the list of BayesNetChanges
		changeList.clear();
		
		int[][] parentIDlist;
		
		// Collect all possible additions from the addableEdges
		EdgesAsMatrixWithCachedStatistics addableParents = 
		    bayesNetManager.getAddableParents();
		
		// Collect all possible deletions from the deleteableEdges
		EdgesAsMatrixWithCachedStatistics deleteableParents = 
		    bayesNetManager.getDeleteableParents();
		
		// Used for checking against the parent count limit 
		EdgesAsMatrixWithCachedStatistics currentParents = 
		    bayesNetManager.getCurrentParents();
		
		int typeCount;
				
		// For each node, get its parentIDlist, then add a bayesNetChange 
		// for each addable parent
		for (int i=0; i< varCount; i++) {
		    
			// hjs 8/23/05
			// Only add parents if we don't bump against the parentCount limit
			// for variable i
		    if ( currentParents.getParentCount( i ) < this.maxParentCount ) {
		        
		        parentIDlist = addableParents.getCurrentParentIDlist(i, 0);
						   
				for ( int j=0; j<parentIDlist.length; j++ ) {
				
					changeList.add( new BayesNetChange( i,  
					        parentIDlist[j][0], parentIDlist[j][1],
							BANJO.CHANGETYPE_ADDITION ) );
				}
			}
		}
		typeCount = changeList.size();
		proposedChangeTypeTracker[BANJO.CHANGETYPE_ADDITION] += typeCount;

		// For each node, get its parentIDlist, then add a bayesNetChange 
		// for each deleteable parent
		for (int i=0; i< varCount; i++) {
		
			parentIDlist = deleteableParents.getCurrentParentIDlist(i, 0);
			
			for ( int j=0; j<parentIDlist.length; j++ ) {
			
				changeList.add( new BayesNetChange( i,  
				        parentIDlist[j][0], parentIDlist[j][1], 
						BANJO.CHANGETYPE_DELETION ) );
			}
		}
		
		typeCount = changeList.size() - typeCount;		
		proposedChangeTypeTracker[BANJO.CHANGETYPE_DELETION] += typeCount;
		
		// Only consider reversals for nodes of lag 0
		// Note: at the present the following code is more restrictive by
		// disallowing reversal for the entire class of networks with any lag>0...
		if ( maxMarkovLag == 0 ) {

			// Collect all possible reversals from the deleteableEdges
		    EdgesAsMatrixWithCachedStatistics reversableParents = deleteableParents;
			EdgesAsMatrixWithCachedStatistics mustBeAbsentParentMatrix = 
			    bayesNetManager.getMustBeAbsentParents();
			
			typeCount = changeList.size();
	
			// For each node, get its parentIDlist, then add a bayesNetChange 
			// for each reversal
			for (int i=0; i< varCount; i++) {
			        
			    parentIDlist = reversableParents.getCurrentParentIDlist(i, 0);
				    
				for ( int j=0; j<parentIDlist.length; j++ ) {
					
					// hjs 8/23/05
					// Only add parents if we don't bump against the parentCount limit
					// for the considered parent, i.e., parentIDlist[j][0]
				    if ( currentParents.getParentCount( parentIDlist[j][0] ) 
				            < this.maxParentCount ) {
					    
					    // Make sure that reversal doesn't conflict with mustBeAbsent edges
				        // (i.e., i can be a parent of j!)
					    if ( mustBeAbsentParentMatrix.
				                matrix[j][i][0] == 0 ) { 
	
							changeList.add( new BayesNetChange( i,  
							        parentIDlist[j][0], parentIDlist[j][1],
									BANJO.CHANGETYPE_REVERSAL ) );
					    }
					}
				}
			}
	
			typeCount = changeList.size() - typeCount;	
			proposedChangeTypeTracker[BANJO.CHANGETYPE_REVERSAL] += typeCount;
		}
		
		return changeList;
	}
	
	public BayesNetChangeI suggestBayesNetChange(
	        final BayesNetManagerI bayesNetManager ) throws Exception {
		
		// This global proposer cannot be used to supply a single bayesNetChange only
		throw new BanjoException( 
				BANJO.ERROR_COULDNOTSUGGESTSINGLESCHANGE,
				"(ProposerAllLocalMoves.suggestBayesNetChange) is not available." );
	}
}
