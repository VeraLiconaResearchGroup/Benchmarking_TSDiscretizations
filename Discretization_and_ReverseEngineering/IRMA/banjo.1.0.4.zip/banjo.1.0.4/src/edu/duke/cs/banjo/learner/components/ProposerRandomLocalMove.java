/*
 * Created on Sep 17, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.learner.components;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.utility.BANJO;
import edu.duke.cs.banjo.utility.BanjoException;
import edu.duke.cs.banjo.utility.Settings;
import edu.duke.cs.banjo.utility.StringUtil;

import java.util.*;

/**
 * Proposes a single potential BayesNetChange based on the current network 
 * configuration.
 * 
 * <p><strong>Details:</strong> <br>
 * Computes a single bayesNetChange by randomly selecting <br>
 * - first the changeType (add/delete/reverse) <br>
 * - second a node <br>
 * Note that the change is subject to the restrictions imposed by
 * mandatory, disallowed edges, etc.
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Sep 17, 2004 <br>
 * (hjs) 12/20/04 Added a wrapper for supplying a list of changes, so this class
 * can be used within a global search (but conceivably also for future "hybrid" 
 * proposers)
 * 
 * 8/26/200 hjs 1.0.1: Add conditions to check proposed changes against maxParentCount
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class ProposerRandomLocalMove extends Proposer {
	
	protected final int bayesNetChangeSelectLimit;
		
	// Constructor, using the base class constructor
	public ProposerRandomLocalMove(BayesNetManagerI initialBayesNet, 
			Settings processData) throws Exception {
		
		super(initialBayesNet, processData);
		
		// set the limit for the number of attempts to select a bayesNetChange
		bayesNetChangeSelectLimit = BANJO.LIMITFORTRIES;
		
		// Create the list for holding the single change
		changeList = new ArrayList( 1 );
	}
	
	// hjs 12/20/04 Wrapper function for searchers that request a list of changes
	// instead of a single bayesNetChange
	public List suggestBayesNetChanges(
	        final BayesNetManagerI bayesNetManager ) throws Exception {

		// Note: this method enables us to use this proposer within
		// a searcher that uses the changeList instead of a single change
		
		// Clear the list of BayesNetChanges
		changeList.clear();
		
		// This picks a single change based on a random choice method
		changeList.add( new BayesNetChange( 
				suggestBayesNetChange(bayesNetManager)) );
		
		return changeList;
	}

	
	// ---------------------------------------------------------
	// Implement the core method for computing the next change
	// for the given BayesNet
	// ---------------------------------------------------------
	public BayesNetChangeI suggestBayesNetChange(
	        final BayesNetManagerI bayesNetManager ) throws Exception {
		
		int randomChangeType = -1;
		int potentialParentsCount;
		int proposedParentsCount = -1;
		// 
		int combinedParentCount;
		int[] parentCountArray;
		int proposedParentIndex;
		
		int currentNodeID = -1;
		int parentNodeID = -1;
		int parentNodeLag = -1;
		
		int parentNodeIndex;
		boolean validBayesNetChange;
		int changeSelectCounter;
		int nodeSelectCounter;
		int runningIndex;

		EdgesAsMatrixWithCachedStatistics potentialParentMatrix;
		EdgesAsMatrixWithCachedStatistics mustBeAbsentParentMatrix;
		// Note: to squeeze the final bit of performance out of the code, we could
		// use internal knowledge about the parentMatrix/edgeMatrix implementations
		// so that we would not have to make as many getEntry() calls
		// (may be worth to break encapsulation in this case) -
		// DONE; Implemented for testing, 11/29/04; Empirical performance increase 
		// is in 3-5% range (relative to the "11/29/04" state of the application)
				
		// Clear the previous bayesNetChange
		bayesNetChange.resetChange();
		
		// Loop for computing a (potential) bayesNetChange
		validBayesNetChange = false;
		changeSelectCounter = 0;
		while (!validBayesNetChange && changeSelectCounter < bayesNetChangeSelectLimit) {
					
			do {
			
				// Pick a changeType at random
				randomChangeType = rnd.nextInt( changeTypeCount ) + 1;

				// 8/29/2005 hjs 1.0.1 Error in proposing reversals traced to 
				// missing resets:
				currentNodeID = -1;
				parentNodeID = -1;
				
				// reset the number of proposed parent nodes
				potentialParentsCount = 0;
				proposedParentsCount = 0;

				// reset the counter for the number of nodes we tried to select
				nodeSelectCounter = 0;
				
				
				if ( randomChangeType == BANJO.CHANGETYPE_REVERSAL ) {
					
					// Get the count of the reversable edges (via the deleteable parents)
				    // for all nodes combined (Note: only lag 0 edges can be used)
					potentialParentMatrix = bayesNetManager.getDeleteableParents();
					mustBeAbsentParentMatrix = bayesNetManager.getMustBeAbsentParents();
					parentCountArray = potentialParentMatrix.getParentCount();
					combinedParentCount = potentialParentMatrix.getCombinedParentCount();
					
					// Note that combinedParentCount is relatively small (<< varCount)
					// so it's not easy to get a good bound for parents with lag 0
					if ( combinedParentCount != 0 ) {
						
						// We now have all parents for which an edge can be reversed.
						// We select one at random by picking its index in the list
						// (Note: the parent list contains parents of all possible lags,
						// but we can only use the ones with lag 0)
						parentNodeIndex = rnd.nextInt(combinedParentCount);
						
						// Then find the parentNodeID that corresponds to the chosen index
						// Remember that the lag for the node and the prospective parent 
						// both have to be 0.
						// Initialize to "invalid" index value
						runningIndex = -1;
						// Because reversals are only possible for lag 0
						final int MarkovLag = 0; 
						// Go through the parents to find the (i=parentNodeIndex)-th one
						for (int i=0; i<varCount; i++) {
					        for (int j=0; j<varCount; j++) {

								if ( potentialParentMatrix.matrix
								        [i][j][MarkovLag] == 1 ) {
								    
							        runningIndex++;
								}
								
							    if ( runningIndex == parentNodeIndex ) { 
							    	
							        // Need to validate the potential reversal:
							        // It's possible that the reversed edge is 
							        // excluded via the mustNotBePresentEdges
							        //-- 8/29/2005 hjs 1.0.1
							        //-- Add condition on maxParentCount 
							        if ( mustBeAbsentParentMatrix.
							                	matrix[j][i][MarkovLag] == 0 && 
							             bayesNetManager.getCurrentParents().getParentCount( j ) < 
							                	this.maxParentCount ) {
							        
	    							    // Set the node and parent data
							        	currentNodeID = i;
	    								parentNodeID = j;
	    								parentNodeLag = MarkovLag;
							        }
							        
    								// Indicate "done" (with or without success)
    								j = varCount;
    								i = varCount;
    							}
							}
						}
						
						if ( parentNodeID != -1 ) {
						
							// Update the proposed parent count for the PARENT
							proposedParentsCount = bayesNetManager.
								getCurrentParents().getParentCount(parentNodeID) + 1;
						}
					}
				} // end of REVERSAL case
				else {
				    // addition and deletion are partially combined
					
					if ( randomChangeType == BANJO.CHANGETYPE_ADDITION ) {
						
						// Get the count of the addable parents for all nodes combined
						potentialParentMatrix = bayesNetManager.getAddableParents();
						combinedParentCount = potentialParentMatrix.
								getCombinedParentCount();
						parentCountArray = potentialParentMatrix.getParentCount();
						
					} else if ( randomChangeType == BANJO.CHANGETYPE_DELETION ){
						
						// Get the count of the deleteable parents for all nodes combined
						potentialParentMatrix = bayesNetManager.getDeleteableParents();
						combinedParentCount = potentialParentMatrix.
								getCombinedParentCount();
						parentCountArray = potentialParentMatrix.getParentCount();
						
					} else {
						
						// Internal error - we should never end up in this case!
						throw new BanjoException(
						       BANJO.ERROR_INVALIDCHANGETYPE, 
						       " (" + StringUtil.getClassName(this) + 
						       ".suggestBayesNetchange) \nInvalid bayesNetChange type. " );
					}
					
					// The 'add' and 'delete' cases can be handled together from here on
					if ( combinedParentCount != 0 ) {
						 
					    // First select an index for the new parent
						proposedParentIndex = rnd.nextInt( combinedParentCount ) + 1;
						
						// and find the associated nodeID
						currentNodeID = 0;
						while ( proposedParentIndex > parentCountArray[currentNodeID] ) {
							
							proposedParentIndex -= parentCountArray[currentNodeID];
							currentNodeID++;
						}
						
						nodeSelectCounter++;
		
						// Now get the parent count for the selected node
						potentialParentsCount = parentCountArray[currentNodeID];					
					    
						// Pick a parent from the available parents (pick the position of
						// the parent, based on the number of parents)
						parentNodeIndex = proposedParentIndex; 
							//rnd.nextInt(potentialParentsCount) + 1;
						
						// Then find the parentNodeID that corresponds to the chosen 
						// index (Since we already subtracted the "offsets" due to 
						// other nodeIDs we only have to go through the values   
						// associated with the currentNodeID) 
						runningIndex = 0;
						for (int j=0; j<varCount; j++) {
						    for (int k=minMarkovLag; k<maxMarkovLag+1; k++) {
						        
								if ( potentialParentMatrix.matrix[currentNodeID][j][k]
								           == 1 ) {
								    
								    runningIndex++;
								}
								
								if ( runningIndex == parentNodeIndex ) {
								    
								    // Set the parent data
									parentNodeID = j;
									parentNodeLag = k;
									
									// Indicate "done"
									j = varCount;
									k = maxMarkovLag;
								}
						    }
						}
						
						proposedParentsCount = bayesNetManager.
							getCurrentParents().getParentCount(currentNodeID);
						if ( randomChangeType == BANJO.CHANGETYPE_ADDITION )
							proposedParentsCount++;
					}
				} // end - add+delete case				
			}
			while ( proposedParentsCount == 0 || 
						proposedParentsCount > maxParentCount );
			
			if ( proposedParentsCount > 0 ) {

				// Track the (proposed) change:
				proposedChangeTypeTracker[randomChangeType]++;

				this.bayesNetChange.updateChange(
				        currentNodeID, parentNodeID, parentNodeLag, randomChangeType);
				bayesNetChange.setChangeStatus(
				        BANJO.CHANGESTATUS_READY);
			
				validBayesNetChange = true;
			}
			else {
			    			
				bayesNetChange.setChangeStatus(
				        BANJO.CHANGESTATUS_NONE );
			}
	
			changeSelectCounter++;
		} // end of main "while" loop
				
		// TODO?
		// Do we want to check whether the change is valid internally (this would be
		// a good place) or externally?		
		// It may actually make sense to apply BOTH the validity-check and the actual
		// "application" of the change within this function - will need to place it inside
		// a loop that can examine all possible changes within the current context. Then 
		// we would return null if we can't find a valid BNchange, and the "outside" loop
		// would be in charge to "restart" the process. (May want the outside process to
		// assign the "current node" before calling the proposer, so that we won't use
		// the same currentNode twice within the proposer).

		// Redundant: Handled ok via the bayesNetChange's values
//		if ( changeSelectCounter >= bayesNetChangeSelectLimit ) {
//		    
//		    // Ouch! We should never end up in this scenario, but it is conceivable
//		    // for a pathological network config.?
//		    // If we do end up here, I think we should stop the search 
//			// and let the user know
////		    throw new BanjoException(
////		            BANJO.ERROR_COULDNOTFINDVALIDCHANGE, 
////		            BANJO.ERRORMSG_COULDNOTFINDVALIDCHANGE );
//		}
					
		return this.bayesNetChange;
	}
}
