/*
 * Created on May 10, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */

package edu.duke.cs.banjo.learner.components;

import edu.duke.cs.banjo.bayesnet.*;
import edu.duke.cs.banjo.learner.*;
import edu.duke.cs.banjo.utility.*;

import java.text.DateFormat;
import java.util.*;

/**
 * Combines the common code shared by the different statistics implementations.
 *
 * <p><strong>Details:</strong> <br>
 * 
 * <p><strong>Change History:</strong> <br>
 * Created May 10, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */

public abstract class Recorder implements RecorderI {

	// Internal data (statistics) collection buffer
	protected StringBuffer statisticsBuffer;
	
	// Individual tracking strings
	protected StringBuffer resultBuffer;
	protected StringBuffer summaryBuffer;
	protected StringBuffer traceBuffer;
	
	// Indicators (using collections) for printing to file(s)
	protected Collection outputFileFlags = new HashSet(
	        BANJO.MAXOUTPUTFILES );
	protected Collection outputResultsOnly = new HashSet(
	        BANJO.MAXOUTPUTFILES );
	protected Collection outputTraceOnly = new HashSet(
	        BANJO.MAXOUTPUTFILES );
	protected Collection outputSummaryOnly = new HashSet(
	        BANJO.MAXOUTPUTFILES );
	protected Collection outputToAllFiles = new HashSet(
	        BANJO.MAXOUTPUTFILES );
	
	protected final Settings processData;
	protected DateFormat timeFormat;
	
	private static final String strHeader = new String(" -- ");	

	public Recorder( Settings processData ) {

		// Keep a link to the settings around
		this.processData = processData;

//		timeFormat = DateFormat.getTimeInstance(DateFormat.MEDIUM);
		timeFormat = DateFormat.getDateTimeInstance( DateFormat.SHORT, 
		        DateFormat.MEDIUM );
		
		statisticsBuffer = new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		resultBuffer = new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		summaryBuffer = new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		traceBuffer = new StringBuffer( BANJO.BUFFERLENGTH_STAT );

		// Set up the collections used for printing the results	
		outputResultsOnly.add( new Integer(BANJO.FILE_RESULTS) );
		outputSummaryOnly.add( new Integer(BANJO.FILE_SUMMARY) );
		outputTraceOnly.add( new Integer(BANJO.FILE_TRACE) );
		//
		outputToAllFiles.add( new Integer(BANJO.FILE_RESULTS) );
		outputToAllFiles.add( new Integer(BANJO.FILE_SUMMARY) );
		outputToAllFiles.add( new Integer(BANJO.FILE_TRACE) );		
	}
	
	// may want to keep the timing at which we write to disk internal to this class
	protected void commitData( final Collection outputFileFlags, 
	        final StringBuffer textToCommit ) throws Exception {
		
	    try {
	        	        
			FileUtil.writeToFile( outputFileFlags , textToCommit );
	    }
		catch (BanjoException e) {
		    
		    // Only for now:
		    System.out.println("Recorder.commitData  -- BanjoException: " 
					+ e.toString());

			throw new BanjoException( e );
		}
		catch (Exception e) {
		    
		    // Only for now:
		    System.out.println("Recorder.commitData  -- Exception: " 
					+ e.toString());

			throw new Exception( e );
		}
	}	
	
	public void recordInitialData(SearcherI searcher) throws Exception {
		
	    try {
			
	        if ( BANJO.CONFIG_CREATEDATAREPORT ) {

				statisticsBuffer.append( 
				        processData.getDynamicProcessParameter( 
				                BANJO.DATA_DISCRETIZATIONREPORT ));
				statisticsBuffer.append( "\n" );
	        }
	        
			if (BANJO.DEBUG) statisticsBuffer.append( strHeader );
			statisticsBuffer.append( "Starting search at " );
			statisticsBuffer.append( timeFormat.format(new Date()) );
			statisticsBuffer.append( "\n" );

			if (BANJO.DEBUG) statisticsBuffer.append( strHeader );
			statisticsBuffer.append( "Prep. time used: ");
			statisticsBuffer.append( StringUtil.formatElapsedTime(
			        Long.parseLong( processData.getDynamicProcessParameter(
			        BANJO.DATA_TOTALTIMEFORPREP )), 1, 
			        BANJO.OPTION_TIMEFORMAT_MIXED ));
			statisticsBuffer.append( "\n" );
			
			if ( BANJO.DEBUG  && BANJO.TRACE_NODESCORES ) {
			    			    
			    double[] nodeScores = ((BayesNetManager) 
			            ( (Searcher) searcher).getBayesNetManager())
					.getNodeScores();
			    int varCount = Integer.parseInt( 
				        processData.getValidatedProcessParameter(
				        BANJO.SETTING_VARCOUNT ));
				for (int j=0; j<varCount; j++) {
				    
					statisticsBuffer.append( "StatNormal  --  BN Score for node " );
					statisticsBuffer.append( j );
					statisticsBuffer.append( ": " );
					statisticsBuffer.append( nodeScores[j] );
					statisticsBuffer.append( "\n" );
				}
			}
			statisticsBuffer.append( "\n" );
						
			commitData( outputResultsOnly , statisticsBuffer );
			//commitData( outputToAllFiles , statisticsBuffer );
			
			// Now clear the text buffer that was written to file
			statisticsBuffer = new StringBuffer(BANJO.BUFFERLENGTH_STAT);
	    }
		catch (BanjoException e) {
		    
			throw new BanjoException(e);
		}
		catch (Exception e) {
		    
			System.out.println("Recorder.recordInitialData  -- Exception: " 
					+ e.toString());
			throw new BanjoException( e, BANJO.ERROR_RECORDERINTERNAL,
			        "(Recorder.recordInitialData) " + "Error in composing the string" +
			        		"for the initial data reporting." );
		}
	}
	
	/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.data.RecorderI
	 * 		#recordFinalData(edu.duke.cs.banjo.learner.SearcherI)
	 */
	public void recordFinalData(SearcherI searcher) throws Exception {
								
	};
	
	/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.data.RecorderI
	 * 		#recordRecurringData(edu.duke.cs.banjo.learner.SearcherI)
	 */
	public abstract void recordRecurringData(SearcherI searcher) throws Exception;
	/* (non-Javadoc)
	 * @see edu.duke.cs.banjo.data.RecorderI
	 * 		#recordSpecifiedData(java.lang.String)
	 */
	public abstract void recordSpecifiedData(StringBuffer dataToRecord) throws Exception;
}
