/*
 * Created on Mar 1, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;


/**
 * Defines all constants (numeric, string, etc) used by Banjo.
 *
 * <p><strong>Details:</strong> <br>
 * - By declaring all used constants in one place, any changing of values is greatly
 * simplified. <br>
 * - Contains sections for Developer options (e.g., debugging flags for subsections
 * of the code), Exception handling, User input (settings defined in the settings file),
 * and values used internally by the application (e.g., acceptable values for a 
 * BayesNetChange, default values for certain search parameters, etc).
 *  
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 1, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public final class BANJO {
	
	// Remember to recompile all classes that reference this class when you
	// change a static final value (especially the DEBUG/TRACE flags when 
	// switching to production mode)
	
    //-------------------------
    // Banjo version identification:
    //-------------------------
	public static final String APPLICATION_NAME = "Banjo";
	public static final String APPLICATION_NAME_LONG = "Bayesian Network Inference " +
			"with Java Objects";
	public static final String APPLICATION_VERSIONNUMBER = "1.0.4";
	public static final String APPLICATION_VERSIONDATE = "16 Sep 2005";
	public static final String APPLICATION_VERSIONDESCRIPTION = "Public Release 1";
	
    //-------------------------
    // DEVELOPMENT constants:
    //-------------------------
	
	//-------------------------
	// Part I: 		(Internal Development) Settings
	//-------------------------
	// It is sometimes useful to turn the score caching mechanism off
	// during development. For deployment, always set this flag to true,
	// and set the main DEBUG flag to false, then recompile the project.
	// Note that all the code for the score cache is in the Evaluator class
	// default value: true
	public static final boolean DEV_USECACHE = true;
	
	// Constant for setting fast cache access level (max. value CANNOT exceed 2)
	// To disable, set to -1; default value: 2
	public static final int DEV_MAXLEVELFORFASTCACHE = 2;
	
	// This constants can turn the "regular" cache (for parent counts > 2) on and off
	// default value: true
	public static final boolean DEV_USEGENERALCACHE = true;

	//-------------------------
	// Part II: 	Control application behaviour before folding into 
	// 				general release
	//-------------------------
	// For now, several special output sections are included in each search report.
	// To change the default behaviour, change the values of the constants:
	//
//	public static final boolean CONFIG_CREATEDATAREPORT = false;
//	public static final boolean CONFIG_COMPUTEINFLUENCESCORES = false;
//	public static final boolean CONFIG_CREATEDOTOUTPUT = false;
//	public static final boolean CONFIG_DISPLAYSTATISTICS = false;
	// default values: true
	public static final boolean CONFIG_CREATEDATAREPORT = true;
	public static final boolean CONFIG_COMPUTEINFLUENCESCORES = true;
	public static final boolean CONFIG_CREATEDOTOUTPUT = true;
	public static final boolean CONFIG_DISPLAYSTATISTICS = true;
	//
	// If you absolutely don't care about any command line output,
	// then set this flag to false:
	public static final boolean CONFIG_ECHOOUTPUTTOCMDLINE = true;
	//
	// For displaying at what iterations the restarts took place:
	public static final boolean CONFIG_DISPLAYITERATIONRESTARTS = false;

	// Flag for switching between a basic breadth-first and depth-first
	// algorithm. The basic DFS algorithm is generally faster than the 
	// BFS one, so we use it as default; there is usually little need to
	// change this setting, which is the main reason that it is not an
	// option available via the settings file.
	// (We expect a further improvement with an algorithm based on Oded Shmueli, 
	// "Dynamic Cycle Detection", Information Processing Letters 17, 1983)
	public static final boolean CONFIG_DFS_CYCLECHECKING = true;
	
	// Display of data "map" in discretization report
	// default value: false
	public static final boolean CONFIG_DISPLAYMAPPEDVALUES = false;
	
	//-------------------------
	// Part III: 	Debug and Development Feedback flags
	//-------------------------
	// Main "Global" debug flag: turn off for release
	// default in user mode (vs developer mode): false
	public static final boolean DEBUG = false;
	
	// Indicator whether to print out the stack trace when an error
	// is encountered; Note that this may be useful to when a user needs
	// to provide info about a problem that he ran into
	public static final boolean DEV_PRINTSTACKTRACE = true;
	public static final boolean DEV_TMP = false;
	
	// Individual (secondary) debug flags (always used as a dual
	// condition with DEBUG, so that we only need to turn off DEBUG
	// when we are ready to deploy)
	public static final boolean TRACE_BAYESNETMANAGER = false;
	public static final boolean TRACE_CMDLINE = false;
	public static final boolean TRACE_BAYESNET = false;
	public static final boolean TRACE_EVAL = false;
	public static final boolean TRACE_BDEPRECOMPUTE = false;
	public static final boolean TRACE_EVALPARENTCOUNT = false;
	public static final boolean TRACE_BAYESNETSTRUCTURE = false;
	public static final boolean TRACE_FILEUTIL = false;
	public static final boolean TRACE_STATISTICS = false;
	public static final boolean TRACE_PROPOSER = false;
	public static final boolean TRACE_NODESCORES = false;
	public static final boolean TRACE_DISCRETIZATION = false;
	// This is more than a debug trace: it displays the loop indexes for all restarts
	// (useful for algorithm tuning)
	public static final boolean TRACE_RESTART = false;
	
	
	//--------------------------
	// Internal constants
	//--------------------------
	
	//--------------------------
	// Part I:	Tuning constants
	//--------------------------

	// Max. number of values that a node can assume
	public static final int CONFIG_MAXVALUECOUNT = 5;
	// Use only values 0 or 1:
	public static final int CONFIG_DISCRETIZATIONSTARTINDEX = 0;
	
	//--------------------------
	// Part II: Values set as a convention
	//--------------------------
	
	// Type values of a BayesNetChange
	public static final int CHANGETYPE_NONE = 0;
	public static final int CHANGETYPE_ADDITION = 1;
	public static final int CHANGETYPE_DELETION = 2;
	public static final int CHANGETYPE_REVERSAL = 3;
	// Some proposers make use of the count value:
	// This count matches the highest value of the changeType values,
	// so we CANNOT skip a (changeType) value in the above list!
	public static final int CHANGETYPE_COUNT = CHANGETYPE_REVERSAL;
	
	// Status values of a BayesNetChange
	public static final int CHANGESTATUS_NONE = 0;
	public static final int CHANGESTATUS_READY = 1;
	public static final int CHANGESTATUS_APPLIED = 2;
	public static final int CHANGESTATUS_UNDONE = 3;
	
	// Values for setting the logging preferences
	public static final int LOGGING_REGULAR = 1;
	public static final int LOGGING_MINIMAL = 2;
	public static final int LOGGING_VERBOSE = 3;
	
	// Values to indicate the logging files
	public static final int FILE_RESULTS = 1;
	public static final int FILE_SUMMARY = 2;
	public static final int FILE_TRACE = 3;
	
	
	// Comment character in data file
	public static final String DEFAULT_COMMENTCHARACTER = "#";
	// Various delimiters
	public static final String DEFAULT_LISTDELIMITER = ",";
	public static final String DEFAULT_ITEMDELIMITER = ":";
	// for observations
	public static final String OBSERVATIONSDELIMITER = "\t";
	// for exceptions (in discretization handling)
	public static final String EXCEPTIONSDELIMITER = ",";
	public static final String EXCEPTIONITEMDELIMITER = ":";
	
	//
	public static final int FEEDBACKLINELENGTH = 78;
	public static final String FEEDBACKDASH = "-";
	public static final String FEEDBACKSLASH = "|";
	public static final String FEEDBACKDASHEDLINE = 
	    "\n----------------------------------------------------" + 
		"----------------------------------------------------";
	public static final int PERCENTPADDINGLENGTH = 5;
	public static final int TIMEPADDINGLENGTH = 8;
		
	// Assign a value for a missing entry (regular values are from 
	// 0 to CONFIG_MAXVALUECOUNT-1; If user specifies the max. value
	// count, it has to be lower than the default value.
	public static final int MISSINGENTRYVALUE = CONFIG_MAXVALUECOUNT;
	
	// Limit on the number of parents per node, on restart only
	public static final int MAXPARENTCOUNTFORRESTART = 5;
	// Validated as int > 0 and < maxParentCount; defaults when invalid:
	public static final int DEFAULT_MAXPARENTCOUNTFORRESTART = 3;
	
	// Output files used: summary, results, and trace
	public static final int MAXOUTPUTFILES = 3;
	// Constant used in generating hash codes
	public static final int HASHGENERATORFACTOR = 37;
	// Constant for setting initial size of secondary cache
	public static final int INITIALHASHSIZE = 100000;
	// Tolerance for testing numerical equality of 2 scores
	public static final double NUMERICSCORETOLERANCE = 0.0000005;
	public static final int DIGITSINSCOREDISPLAY = 7;
	public static final int DIGITSININFLUENCESCOREDISPLAY = 4;
	
	// Limit on number of tries to get a valid bayesNetChange
	public static final int LIMITFORTRIES = 1000;
	public static final int LIMITFORGLOBALGREEDYSEARCHTRIES = 1;

	// Initial initialSettings for internal string buffers
	public static final int BUFFERLENGTH_STAT = 10000;
	public static final int BUFFERLENGTH_STAT_INTERNAL = 2000;
	public static final int BUFFERLENGTH_STRUCTURE = 1000;
	public static final int BUFFERLENGTH_STRUCTURE_LARGE = 30000;
	public static final int BUFFERLENGTH_SMALL = 100;
	
	public static final int OPTION_TIMEFORMAT_DEFAULT = 1;
	public static final int OPTION_TIMEFORMAT_IN_H = 2;
	public static final int OPTION_TIMEFORMAT_IN_M = 3;
	public static final int OPTION_TIMEFORMAT_IN_S = 4;
	public static final int OPTION_TIMEFORMAT_IN_MS = 5;
	public static final int OPTION_TIMEFORMAT_MIXED = 6;
	
	// Determines how many decimals are displayed for the elapsed time
	public static final int OPTION_NUMBEROFDECIMALSINTIMEDISPLAY = 2;
	
	// Testing-related data
	public static final double TEST_SCORETOLERANCE = 0.0000005;
	
	// Score value used internally in evaluator (feasible BDe scores
	// are never positive)
	public static final double BANJO_UNREACHABLEBDESCORE = 1.0;
	
	// Initial starting numbers used for finding max and mins
	public static final double BANJO_LARGEINITIALVALUEFORMINIMUM = 100000000.0;
	public static final double BANJO_SMALLINITIALVALUEFORMAXIMUM = -100000000.0;
	
	// Default value for the number of fixed restarts
	public static final long DEFAULT_FIXEDRESTARTS = 100;
	
	// Automatic saves are triggered based on these interval settings:
	// ---------------------------------------------------------------
	public static final String SETTING_NUMBEROFINTERMEDIATESAVES = 
	    "numberOfIntermediateSaves";
	public static final int DEFAULT_NUMBEROFINTERMEDIATESAVES = 0;
	//
	public static final String SETTING_WRITETOFILEINTERVAL = 
	    "writeToFileInterval";
	public static final int DEFAULT_REPORTTOFILEINTERVAL = 300;
	//
	// Display a feedback message every 100/(perc. interval) percent
	// Note: for anything larger than 100, the formatted output may
	// need to get adjusted.
	public static final String SETTING_NUMBEROFPROGRESSREPORTS = 
	    "numberOfIntermediateProgressReports";
	public static final int DEFAULT_NUMBEROFPROGRESSREPORTS = 10;
	// Default time interval:  5 minutes (assuming long runs of 24 hours or more)
	// (number is in milliseconds)
	// Note: for dev purpose, set to 5 seconds
	public static final String SETTING_PROGRESSREPORTINTERVAL = 
	    "progressReportInterval";
	//
	public static final int DEFAULT_FEEDBACKINTERVAL = 300000; 
	// after testing set to 5*60*1000 
	
	// String constansts used for time display
	public static final String DEFAULT_TIME_HOURS = "h";
	public static final String DEFAULT_TIME_MINUTES = "m";
	public static final String DEFAULT_TIME_SECONDS = "s";
	public static final String DEFAULT_TIME_MILLISECS = "ms";

	public static final int DEFAULT_DISPLAY_IN_HOUR = 5;
	public static final int DEFAULT_DISPLAY_IN_MINUTES = 2;
	public static final int DEFAULT_DISPLAY_IN_SECONDS = 30;
	
	//----------------------------------
	// String constants - Default values
	//----------------------------------
	// Note: We use VALIDATED_ to indicate that the properties have been set
	// only after they have been validated.
	// settings file: contains the various initialSettings for running a search,
	// such as selecting between different methods, input and output file names, etc.
	public static final String VALIDATED_SETTINGSFILENAME = "settingsFile";
	public static final String DEFAULT_SETTINGSFILENAME = "banjo.txt";
	//
	public static final String VALIDATED_SETTINGSDIRECTORY = "settingsDirectory";
	// Stores the name and the absolute path to the input file (after it has been
	// located and validated, hence the name)
	public static final String VALIDATED_SETTINGSFILEWITHPATH = 
	    "settingsFileWithPath"; 
	
	// Optional Parameters for placing the command input file; when they are not
	// specified, or are not valid, the location of the application is used instead.
	public static final String DEFAULT_LOADDIRECTORY = "input";
	public static final String DEFAULT_RESULTDIRECTORY = "output";
	// Default names of output files:
	public static final String DEFAULT_RESULTSFILE = "results.txt";
	public static final String DEFAULT_SUMMARYFILE = "summary.txt";
	public static final String DEFAULT_ERRORFILE = "error.txt";
	public static final String DEFAULT_TRACEFILE = "trace.txt";
	
	// Default for interactive feedback within (some) searchers
	public static final String SETTING_ASKTOVERIFYSETTINGS = 
	    "askToVerifySettings";
	// Compared to UI_ASKTOVERIFYSETTINGS_YES; all other values treated as
	// equal to "no"
	public static final String UI_ASKTOVERIFYSETTINGS_YES = "yes";
	
	// References to data that changes during the search
	public static final String DATA_CURRENTTEMPERATURE = "currentTemperature";
	public static final String DATA_ELAPSEDTIME = "elapsedTime";
	// Data that is being collected during the search
	public static final String DATA_TOTALTIMEFORPREP = "totalTimeForPrep";
	public static final String DATA_TOTALTIMEFORSEARCH = "totalTimeForSearch";
	public static final String DATA_DISCRETIZATIONREPORT = "dataReport";
	// Data that is updated in the searcher via the updateProcessData method
	public static final String DATA_NETWORKSVISITEDGLOBALCOUNTER = 
	    "networksVisitedGlobalCounter";
	public static final String DATA_GLOBALHIGHSCORE = "globalHighScore";
	public static final String DATA_GLOBALHIGHSCORESTRUCTURE = 
	    "globalHighScoreStructure";
	
	
	//--------------------------------
	// Strings - Names for user input parameters
	//
	// NOTE: these strings define the Banjo application's interface to the
	// outside world via the settings file. So any change in the values of
	// the strings will invalidate previous versions of the settings file, and
	// should thus be approached with great caution!!
	//--------------------------------
	public static final String SETTING_SEARCHERCHOICE = "searcherChoice";
	public static final String SETTING_PROPOSERCHOICE = "proposerChoice";
	public static final String SETTING_EVALUATORCHOICE = "evaluatorChoice";
	public static final String SETTING_DECIDERCHOICE = "deciderChoice";
	public static final String SETTING_STATISTICSCHOICE = "statisticsChoice";
	
	public static final String SETTING_INPUTDIRECTORY = "inputDirectory";
	public static final String SETTING_OUTPUTDIRECTORY = "outputDirectory";
	public static final String SETTING_ERRORDIRECTORY = "errorDirectory";
	public static final String SETTING_REPORTFILE = "reportFile";
	public static final String SETTING_TRACKINGFILE = "trackingFile";
	public static final String SETTING_SUMMARYFILE = "summaryFile";
	public static final String SETTING_ERRORFILE = "errorFile";
	public static final String SETTING_OBSERVATIONSFILE = "observationsFile";
	public static final String SETTING_RELATEDOBSERVATIONSFILES = 
	    "relatedObservationsFiles";
	public static final String UI_RELATEDOBSERVATIONSFILES_YES = 
	    "yes";
	public static final String UI_RELATEDOBSERVATIONSFILES_NO = 
	    "no";
	public static final String DATA_WILDCARDOBSERVATIONSFILES = 
	    "wildcardObservationsFiles";
	public static final String DATA_OMITTEDWILDCARDOBSERVATIONSFILES = 
	    "omittedWildcardObservationsFiles";
	public static final String SETTING_INITIALSTRUCTUREFILE = 
	    "initialStructureFile";
	public static final String SETTING_MUSTBEPRESENTEDGESFILE = 
	    "mustBePresentEdgesFile";
	public static final String SETTING_MUSTNOTBEPRESENTEDGESFILE = 
	    "mustNotBePresentEdgesFile";
	//
	public static final String SETTING_VARCOUNT = "variableCount";
	public static final String SETTING_OBSERVATIONCOUNT = "observationCount";
	public static final String DATA_OBSERVEDOBSERVATIONCOUNT = 
	    "observedObservationCount";
	public static final String DATA_OBSERVEDOBSERVATIONROWCOUNT = 
	    "observedObservationRowCount";

	public static final String SETTING_MAXSEARCHTIME = "maxTime";
	public static final String SETTING_MAXTHREADS = "threadCount";

	public static final String DATA_PROPOSEDNETWORKS = 
	    "proposedNetworks";
	
	public static final String SETTING_MAXPROPOSEDNETWORKS = 
	    "maxProposedNetworks";
	public static final String SETTING_MAXRESTARTS= "maxRestarts";
	public static final String SETTING_MINNETWORKSBEFORECHECKING = 
	    "minNetworksBeforeChecking";
	// Validated as long > 0, with default
	public static final long DEFAULT_MINPROPOSEDNETWORKSHIGHSCORE = 1000;
	//
	public static final String SETTING_MINPROPOSEDNETWORKSAFTERHIGHSCORE =
	    "minProposedNetworksAfterHighScore";
	public static final String SETTING_MINPROPOSEDNETWORKSBEFORERESTART =
	    "minProposedNetworksBeforeRestart";
	public static final String SETTING_MAXPROPOSEDNETWORKSBEFORERESTART = 
	    "maxProposedNetworksBeforeRestart";
	
	public static final String SETTING_MAXMARKOVLAG = "maxMarkovLag";
	// Mandatory. Validated as int >= 0.
	// Throws ERROR_MISSING_MAXMARKOVLAG error when not supplied.
	
	public static final String SETTING_MINMARKOVLAG = "minMarkovLag";
	// Mandatory. Validated as int >= 0.
	// Throws ERROR_MISSING_MINMARKOVLAG error when not supplied.
	
	public static final String SETTING_DBNMANDATORYIDENTITYLAGS = 
	    "dbnMandatoryIdentityLags";
	
	public static final String SETTING_NBEST = "nBestNetworks";
	// Validated as int > 0. Defaults to 1 when not supplied.
	
	public static final String SETTING_MAXPARENTCOUNT = "maxParentCount";
	// Validated as int > 0; 
	// Also apply a "safety net": On PC's with up to 1 Gb of memory,
	// the max. parent count without running out of memory is 10. 
	// (with ca. 30 vars, 300 observations)
	// To lift this restriction, the use of arrays in the evaluator
	// implementations likely has to be rewritten to use sparse array
	// techniques.
	public static final int DEFAULT_MAXPARENTCOUNT = 9;
	
	public static final String SETTING_MAXPARENTCOUNTFORRESTART = 
		"maxParentCountForRestart";
	public static final String SETTING_RESTARTWITHRANDOMNETWORK = 
		"restartWithRandomNetwork";
	public static final String UI_RESTARTWITHRANDOMNETWORK_YES = "yes";
	public static final String UI_RESTARTWITHRANDOMNETWORK_NO = "no";
	
	// Settings that can be specified via command-line parameter:
	public static final String DATA_SPECIFIEDSETTINGSFILE = 
	    "specifiedSettingsFile";
	public static final String DATA_SPECIFIEDSETTINGSFILEDIRECTORY = 
	    "specifiedSettingsFileDirectory";
	
	
	// Annealer related input
	// ----------------------
	// Initial temperature for annealing process
	public static final String SETTING_INITIALTEMPERATURE = "initialTemperature";
	// Values for "initialTemperature":
	// Validated as double > 0, with default if not user-supplied:
	public static final long DEFAULT_INITIALTEMPERATURE = 1000;
	
	// Cooling factor appplied after SETTING_MINNETWORKSBEFORECHECKING loops
	public static final String SETTING_COOLINGFACTOR = "coolingFactor";
	// Values for "initialTemperature":
	// Validated as double > 0, with default if no user-supplied value:
	public static final double DEFAULT_COOLINGFACTOR = 0.9;
	//
	public static final String SETTING_MAXACCEPTEDNETWORKSBEFORECOOLING =
	    "maxAcceptedNetworksBeforeCooling";
	public static final long DEFAULT_MAXACCEPTEDNETWORKSBEFORECOOLING = 1000;
	//
	public static final String SETTING_MAXPROPOSEDNETWORKSBEFORECOOLING = 
	    "maxProposedNetworksBeforeCooling";
	public static final long DEFAULT_MAXPROPOSEDNETWORKSBEFORECOOLING = 10000;
	//
	public static final String SETTING_MINACCEPTEDNETWORKSBEFOREREANNEALING = 
	    "minAcceptedNetworksBeforeReannealing";
	public static final long DEFAULT_MINACCEPTEDNETWORKSBEFOREREANNEALING = 200;
	//
	public static final String SETTING_REANNEALINGTEMPERATURE = 
	    "reannealingTemperature";
	public static final long DEFAULT_REANNEALINGTEMPERATURE = 500;
	
	// BDe metric related input
	// ------------------------
	// Equivalent Sample Size (frequently "alpha" in papers)
	public static final String SETTING_EQUIVALENTSAMPLESIZE = 
	    "equivalentSampleSize";
	// Validated to be double > 0
	// Throws ERROR_INVALID_ESSVALUE error when invalid or not user-supplied
	
	// Misc. inputs
	// ------------
	// Computation choice
	public static final String SETTING_PRECOMPUTE = 
	    "precomputeLogGamma";
	// Values for "precomputeLogGamma":
	public static final String UI_PRECOMPUTE_YES = "yes";
	public static final String UI_PRECOMPUTE_NO = "no";
	// If not supplied, defaults to "yes"
		
	// ------------------------------
	// Pre-processing related input
	// ------------------------------
	// 1. Discretization
	public static final String SETTING_DISCRETIZATIONPOLICY = 
	    "discretizationPolicy";
	public static final String SETTING_DISCRETIZATIONEXCEPTIONS = 
	    "discretizationExceptions";
	public static final String UI_DISCRETIZATIONBYQUANTILE = "q"; //"quantile";
	public static final String UI_DISCRETIZATIONBYINTERVAL = "i"; //"interval";
	public static final String UI_DISCRETIZATIONNONE = "none"; //"none";
	// 
	// Default settings for discretization (used internally only)
	public static final String DATA_DEFAULTDISCRETIZATIONCHOICE = 
	    "defaultDiscretizationChoice";
	public static final String DATA_DEFAULTDISCRETIZATIONPOINTS = 
	    "defaultDiscretizationPoints";
	public static final String DEFAULT_DISCRETIZATIONTYPE = 
	    UI_DISCRETIZATIONNONE;
	public static final int DEFAULT_DISCRETIZATIONPOINTS = 2;
	// Data report (related to discretization)
	public static final String SETTING_DATAREPORT = 
	    "discretizationReport";
	public static final String UI_DATAREPORT_YES = 
	    "yes";
	public static final String UI_DATAREPORT_NO = 
	    "no";
		
	// Project related input
	// ---------------------
	// All input is treated as string and not validated
	public static final String SETTING_PROJECT = "project";
	public static final String SETTING_USER = "user";
	public static final String SETTING_DATASET = "dataset";
	public static final String SETTING_NOTES = "notes";
		
	// Names for search methods and core component choices
	public static final String UI_DEFAULT = "default";
	public static final String UI_SEARCH_GREEDY = "Greedy";
	public static final String UI_SEARCH_SIMANNEAL = "SimAnneal";	
	// Proposers
	public static final String UI_PROP_RANDOMLOCALMOVE = "RandomLocalMove";
	public static final String UI_PROP_ALLLOCALMOVES = "AllLocalMoves";
	public static final String UI_PROP_EXHAUSTIVEMOVES = "ExhaustiveMoves";
	//
	// Evaluators
	public static final String UI_EVAL_BDE = "BDe";
	// Deciders
	public static final String UI_DEC_GREEDY = "Greedy";
	public static final String UI_DEC_METROPOLIS = "Metropolis";
	// Statistics recording
	public static final String UI_RECORDER_STANDARD = "Standard";
	//
	public static final String UI_RECORDER_COMPACT = "Compact";
	public static final String UI_RECORDER_VERBOSE = "Verbose";
	
	public static final String BANJO_FREEFORMINPUT = "freeFormInput";
	//
	public static final String BANJO_NOVALUESUPPLIED_STRING = 
	    "noValueSuppliedByUser";
	// Use this as general purpose indicator that user didn't specify
	// a value for a numeric input (of course, only applicable for
	// data that is supposed to be >=0, which most of ours is; for
	// data that can be negative, may need to use the string, and check
	// before converting setting back to number)
	public static final int BANJO_NOVALUESUPPLIED_NUMBER = 
	    -1;
	// This is the default value used when the user doesn't input a value
	// (could change to "none" or "not specified", etc.
	public static final String BANJO_NOVALUE_INDISPLAY = "";
	

	// Post-processing options
	// -----------------------
	// Not yet used:
	public static final String SETTING_COMPUTEINFLUENCESCORES = 
	    "computeInfluenceScores"; 
	public static final String SETTING_INFLUENCESCORES = "computeInfluenceScores";
	public static final String SETTING_DOTOUTPUT = "createDotOutput";
	public static final String UI_COMPUTEINFLUENCESCORES_YES = "yes";
	public static final String UI_COMPUTEINFLUENCESCORES_NO = "no";
	public static final String UI_CREATEDOTOUTPUT_YES = "yes";
	public static final String UI_CREATEDOTOUTPUT_NO = "no";
	//----------------------------------------------
	// Codes and strings used for EXCEPTION handling
	//----------------------------------------------
	// Internal codes for errors (use for top-level error trapping)
	public static final int ERROR_NOT_YET_REGISTERED = -1;
	public static final int ERROR_BANJO_DEV = 0;
	public static final int ERROR_BANJO_DEV_INPUT = 300;
	public static final int ERROR_GENERAL_USERINPUT = 301;
	public static final int ERROR_INVALIDINPUTDIRECTORY = 302;
	public static final int ERROR_INVALIDOUTPUTDIRECTORY = 303;
	
	public static final int ERROR_MISSING_SETTINGSFILE = 1;
	public static final int ERROR_MISSING_OBSERVATIONSFILE = 2;
	public static final int ERROR_BADOBSERVATIONSDATA = 3;
	public static final int ERROR_MISSING_STRUCTUREFILE = 4;
	public static final int ERROR_MISSING_FILE = 5;
	public static final int ERROR_INVALID_INPUTDATATYPE = 6;
	public static final int ERROR_NULL_SEARCHER = 7;
	public static final int ERROR_CYCLEINMANDATORYEDGES = 8;
	public static final int ERROR_CYCLEININITIALPARENTS = 9;
	public static final int ERROR_DEV_UNKNOWNOUTPUTFILE = 10;
	
	public static final int ERROR_MISSING_VARCOUNT = 11;
	public static final int ERROR_INVALID_OBSERVATIONCOUNT = 12;
	public static final int ERROR_INVALID_VARCOUNTINOBSERVATIONS = 15;
	public static final int ERROR_MISSING_MINMARKOVLAG = 13;
	public static final int ERROR_MISSING_MAXMARKOVLAG = 14;

	public static final int ERROR_MISSING_TEMPERATURE = 23;
	public static final int ERROR_MISSING_COOLINGFACTOR = 24;
	public static final int ERROR_MISSING_EQUIVALENTSAMPLESIZE = 26;
	public static final int ERROR_INVALID_ESSVALUE = 27;
	public static final int ERROR_MISSING_MAXPARENTCOUNT = 28;
	public static final int ERROR_MISSING_MAXPARENTCOUNTFORRESTART = 29;

	public static final int ERROR_INVALID_SEARCHER = 30;
	public static final int ERROR_INVALID_PROPOSER = 31;
	public static final int ERROR_INVALID_EVALUATOR = 32;
	public static final int ERROR_INVALID_DECIDER = 33;
	public static final int ERROR_INVALID_RECORDER = 34;
	public static final int ERROR_INVALID_DISCRETIZATION = 35;
	
	//
	public static final int ERROR_MISSING_MAXSEARCHLOOPS = 40;
	public static final int ERROR_INVALID_MAXSEARCHLOOPS = 41;
	public static final int ERROR_MISSING_MAXRESTARTS = 42;	
	public static final int ERROR_INVALID_MAXRESTARTS = 43;
	public static final int ERROR_MISSING_INNERSEARCHLOOPS = 44;
	public static final int ERROR_MISSING_SEARCHTIME = 45;
	public static final int ERROR_OUTOFRANGE = 50;	
	

	public static final int ERROR_OUTPUTTORESULTSFILE = 100;
	public static final int ERROR_OUTPUTTOSUMMARYFILE = 101;
	public static final int ERROR_OUTPUTTOTRACEFILE = 102;

	public static final int ERROR_INVALIDCHANGETYPE = 120;
	public static final int ERROR_INVALIDCHANGESTATUS = 121;
	
	// Errors in EdgesAsMatrixWithCachedStatistics
	public static final int ERROR_LAGSNOTMATCHING = 130;
	public static final int ERROR_INCONSISTENTNODES = 131;
	public static final int ERROR_INVALIDMINMARKOVLAG = 132;
	public static final int ERROR_INCONSISTENTVARCOUNTS = 133;
	public static final int ERROR_INCONSISTENTOBSCOUNTS = 134;

	public static final int ERROR_RECORDERINTERNAL = 150;
	
	// Finally, errors that can happen in the program, but likely only
	// for pathological network configurations
	public static final int ERROR_COULDNOTFINDVALIDCHANGE = 200;
	public static final int ERROR_COULDNOTSUGGESTSINGLESCHANGE = 201;
	 
	public static final int ERROR_POSTPROC_INFLUENCESCORES = 310;
	public static final int ERROR_POSTPROC_DOTOUTPUT = 311;

	public static final int ERROR_SEARCHABORTED = 900;
	
	// Errors in test environment
	public static final int ERROR_TEST_ERROR = 1000;

	// Errors strings
	public static final String ERRORMSG_MISSING_SETTINGSFILE = 
		"The main settings file could not be loaded.";
	public static final String ERRORMSG_INVALIDSEARCHER = 
		"No valid searcher was specified in the settings file.";
	public static final String ERRORMSG_NULL_SEARCHER = 
		"The application was unable" +
		" to create a searcher object.";
	public static final String ERRORMSG_MISSINGOBSERVATIONS = 
		"Observations file cannot be found.";
	public static final String ERRORMSG_MISSINGSTRUCTUREFILE = 
		"A user-specified structure file cannot be found.";
	public static final String ERRORMSG_MISSINGFILE = 
		"File cannot be found: ";
	public static final String ERRORMSG_COULDNOTFINDVALIDCHANGE = 
		"Tried unsuccessfully to find a valid bayesNetChange.";
	
	BANJO(){};
}