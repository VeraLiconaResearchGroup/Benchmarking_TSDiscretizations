/*
 * Created on Oct 11, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

import java.text.DateFormat;
import java.util.Date;

/**
 * Combines the exception handling for various front-end classes.
 *
 * <p><strong>Details:</strong> <br>
 * 
 * - BayesNetExceptions are handled separately, since their special
 * treatment within our code enables us to provide more detailed
 * feedback to the user about the potential source of the problem. <br>
 * 
 * - All other exceptions are treated fairly generically. <br>
 * 
 * - Output includes writing the error to the designated error file, as well
 * as to the command line. <br>
 * 
 * - Note: for exceptions where the associated message provides exhaustive
 * information, a separate case is listed. Generally, such errors can likely
 * be "fixed" by the user by correcting some input value, etc.
 * All other errors are combined in the default case, since they will likely
 * require developer intervention. <br>

 * <p><strong>Change History:</strong> <br>
 * Created on Oct 11, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class BanjoErrorHandler {
    
    /**
     * Processes any encountered exception (which by now has been "converted"
     * into a BanjoException) at the highest level. <br>
     *  
     * @param e The BanjoException to process.
     */
    public void handleApplicationException( BanjoException e ) {
        
        try {
            
	        String strMessage;
			final long startTime;		
	//		DateFormat timeFormat = DateFormat.getTimeInstance(DateFormat.MEDIUM);
			DateFormat timeFormat = DateFormat.getDateTimeInstance( DateFormat.SHORT, 
			        DateFormat.MEDIUM );
			String timeStamp = timeFormat.format(new Date());
	
			StringBuffer errorMessage = new StringBuffer(100);
			
		    errorMessage.append( "\n[" );
		    errorMessage.append( timeStamp );
		    errorMessage.append( "]" );
		    
		    errorMessage.append( " Network inference cannot proceed because " +
		            BANJO.APPLICATION_NAME + 
		            " has encountered the following problem: \n" );
		    
		    // Note: for exceptions where the associated message provides exhaustive
		    // information, a separate case is listed. Generally, such errors can likely
		    // be "fixed" by the user by correcting some input value, etc.
		    // All other errors are combined in the default case, since they will likely
		    // require developer intervention.
		    
		    int exceptionType = e.getExceptionType();
		    switch (exceptionType)
		    {
		    case BANJO.ERROR_MISSING_SETTINGSFILE:
	    	    
	    	    errorMessage.append( BANJO.ERRORMSG_MISSING_SETTINGSFILE );
	    	    break;
	    	    
	    	case BANJO.ERROR_INVALID_SEARCHER:
	    	    
	    	    errorMessage.append( BANJO.ERRORMSG_INVALIDSEARCHER );
	    	    break;
	    		
	      	case BANJO.ERROR_NULL_SEARCHER:
	    	    
	    	    errorMessage.append( BANJO.ERRORMSG_NULL_SEARCHER );
	    	    break;
	    	    
	      	case BANJO.ERROR_INVALID_INPUTDATATYPE:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	      	case BANJO.ERROR_INVALIDOUTPUTDIRECTORY:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    	    break;
	
	    	    
	      	case BANJO.ERROR_INVALIDINPUTDIRECTORY:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    	    break;
	
	    	    
	      	case BANJO.ERROR_GENERAL_USERINPUT:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    	    break;
	    	        	    
	    	case BANJO.ERROR_MISSING_OBSERVATIONSFILE:
	
	    	    errorMessage.append( BANJO.ERRORMSG_MISSINGOBSERVATIONS );
		    	errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_BADOBSERVATIONSDATA :
	
		    	errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	    
	    	case BANJO.ERROR_INVALID_VARCOUNTINOBSERVATIONS :
	
		    	errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_MISSING_STRUCTUREFILE:
	
	    	    errorMessage.append( BANJO.ERRORMSG_MISSINGSTRUCTUREFILE );
		    	errorMessage.append( e.getMessage() );
	    	    break;
	    	    
		    case BANJO.ERROR_MISSING_VARCOUNT:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_VARCOUNT ));
	    	    break;
	    	    
		    case BANJO.ERROR_INCONSISTENTOBSCOUNTS:
	
		    	errorMessage.append( e.getMessage() );
	    	    break;
	    	    
		    case BANJO.ERROR_INVALID_OBSERVATIONCOUNT:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_OBSERVATIONCOUNT ));
	    	    break;
	    	    
		    case BANJO.ERROR_CYCLEINMANDATORYEDGES:
		        
		        errorMessage.append( 
		                "The mandatory parents file cannot contain a cycle." );
	    		errorMessage.append( e.getMessage() );
	    		break;
	    	    
		    case BANJO.ERROR_MISSING_MINMARKOVLAG:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_MINMARKOVLAG ));
	    	    break;
	    	
		    case BANJO.ERROR_MISSING_MAXMARKOVLAG:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_MAXMARKOVLAG ));
	    	    break;
	    	
	    	// The SearchTime parameter is not necessary in our current implementation.
	    	// Thus, currently, we don't throw this exception in our code.
		    case BANJO.ERROR_MISSING_SEARCHTIME:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_MAXSEARCHTIME ));
	    	    break;
	    	    
	    	case BANJO.ERROR_MISSING_MAXSEARCHLOOPS:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_MAXPROPOSEDNETWORKS ));
	    	    break;
	    	    
	    	case BANJO.ERROR_INVALID_MAXRESTARTS:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    		break;
	  	    
	    	case BANJO.ERROR_MISSING_INNERSEARCHLOOPS:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_MINNETWORKSBEFORECHECKING ));
	    	    break;
	    	    
	    	case BANJO.ERROR_MISSING_TEMPERATURE:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_INITIALTEMPERATURE ));
	    	    break;
	    	    
	    	case BANJO.ERROR_MISSING_COOLINGFACTOR:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_COOLINGFACTOR ));
	    	    break;
	    	    
	    	case BANJO.ERROR_OUTOFRANGE:
	    	    
	    	    errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_MISSING_EQUIVALENTSAMPLESIZE:
	    	    
	    	    errorMessage.append( errorMessageFieldNotFound( 
	    	            BANJO.SETTING_EQUIVALENTSAMPLESIZE ));
	    	    break;
	    	    
	    	case BANJO.ERROR_INVALID_ESSVALUE:
	    	    
	    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	//    	case BANJO.ERROR_BANJO_DEV:
	//    	    
	//    	    strMessage = e.getMessage();
	//    		if (strMessage == null || strMessage.length() == 0 ) {
	//    		    errorMessage.append( 
	//    	            "Internal development-related ERROR " +
	//    	            "(sorry, no specific info available)." );
	//    		}
	//    		else {
	//    		    errorMessage.append( 
	//	            	"Internal development-related ERROR. " );
	//    		    errorMessage.append( e.getMessage() );
	//    		}
	//    	    break;
	    	    
	    	case BANJO.ERROR_BANJO_DEV_INPUT:
	    	    
			    errorMessage.append( 
		            "Development-related ERROR? " +
		            "Some input to the Banjo application was not in a usable format." );
			    errorMessage.append( e.getMessage() );
	    		
	    	    break;
	    	    		    
	    	case BANJO.ERROR_NOT_YET_REGISTERED:
	    	    
	    	    errorMessage.append( 
	    	            "Development-related ERROR. Banjo developer needs to register this error " +
	    	            "to provide meaningful feedback!" );
	    	    break;
	    	    		    	    
	    	case BANJO.ERROR_INVALIDCHANGETYPE:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    		    	    
	    	case BANJO.ERROR_INVALIDCHANGESTATUS:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    		    	    
	    	case BANJO.ERROR_COULDNOTFINDVALIDCHANGE:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_INCONSISTENTNODES:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_INVALIDMINMARKOVLAG:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	case BANJO.ERROR_LAGSNOTMATCHING:
	    	    
		    		errorMessage.append( e.getMessage() );
	    	    break;
	    	    
	    	default: 
	    	    
	    	    // hjs 7/20/05 This may make more sense to the user
	    	    if ( exceptionType == BANJO.ERROR_BANJO_DEV ) {
	    	        
			    	strMessage = e.getMessage();
					if (strMessage == null || strMessage.length() == 0 ) {
			
						errorMessage.append( 
						    "BayesNet error - Please notify the developer!! " +
			    			"\n  [I'm sorry, but there is no specific info available" +
			    			" about this error]. " );
					}
					else {
					    errorMessage.append( 
			            	"BayesNet error - Please notify the developer " +
			            	"\n  that the application provided the following info:\n  " );
					    errorMessage.append( e.getMessage() );
					}
	    	    }
	    	    else {
	    	        
	    	    	errorMessage.append( e.getMessage() );
	    	    }
	
		       	break;
		    }
	
		    // Finally, tack on any known data about the "job"
		    errorMessage.append( "\n" + StringUtil.getBasicJobSignature() );
		    
	        System.out.println( errorMessage.toString() );
	        
		    errorMessage.append( "\n\n*** end of error notification ***" );
		    
		    try {
		        
		        FileUtil.recordError( errorMessage.toString() );
		    }
	        catch ( Exception ex ) {
	            
	            System.out.println( "[BanjoErrorHandler][1] Error trying to record " +
	            		"an error that was encountered while trying to run Banjo." +
	            		"/nThe Banjo developers apologize for this problem." +
	            		"/nPlease record all information pertinent to this error " +
	            		"and contact the Banjo developers. " +
	            		"\nThank you for your cooperation." );
	        }
		    
			
			if ( BANJO.DEBUG ) 
			    e.printStackTrace();
	    }
        catch ( Exception ex ) {
            
            System.out.println( "[BanjoErrorHandler][2] Error trying to process " +
        		"an error that was encountered while trying to run Banjo." +
        		"/nThe Banjo developers apologize for this problem." +
        		"/nPlease record all information pertinent to this error " +
        		"and contact the Banjo developers. " +
        		"\nThank you for your cooperation." );
            
			if ( BANJO.DEBUG ) 
			    e.printStackTrace();
        }
    }

    public void handleGeneralException( Exception e ) {

		System.out.println( "[" + BANJO.APPLICATION_NAME 
		        + " Application] "
				+ "Execution of Banjo has stopped "
				+ "due to the following exception: \n'" 
				+ e.toString() + "'\n");

		if ( BANJO.DEBUG ) 
		    e.printStackTrace();
    }
    
	private String errorMessageFieldNotFound( String dataFieldWithNumberError ) {
	    
	    return "Please specify the value of the setting " +
		        "'" + dataFieldWithNumberError +
		        "' in the settings file '" + 
		        BANJO.DEFAULT_SETTINGSFILENAME + "'.";
	}
}
