/*
 * Created on Aug 12, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

/**
 * Defines the exceptions that the application generates.
 *
 * <p><strong>Details:</strong> <br>
 * - To provide as much meaningful feedback to the user or developer, we use special
 * values for the different exceptions that the application may throw. <br>
 * - (Developer) To add a new BanjoException, simply add a new constant corresponding 
 * to the new exception to the BANJO class' Exception section. <br>
 * - The BanjoErrorHandler class provides a generic high-level handling of the generated
 * exceptions, available to any GUI class that wants to use it. 
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Aug 12, 2004
 * 
* @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class BanjoException extends Exception {
	
	private String message = new String();;
	
	final int exceptionType;

    /**
     * Basic Constructor: creates a BanjoException of one of our defined types. <br>
     * 
     * @param exceptionType The type of the BanjoException to set.
     */
	public BanjoException( final int exceptionType ) {
		    
	    // This is the minimal constructor for throwing your own BanjoException
	    // Make sure that the type value is "registered" in the BANJO class
		this.exceptionType = exceptionType;
	}

    /**
     * Contructor that handles an exception within the code, for which
	 * we didn't attach an additional message. <br>
	 * 
     * @param e The Exception that was originally encountered.
     * @param exceptionType The type of the BanjoException to set.
     */
	public BanjoException( Exception e, final int exceptionType ) {
	    
	    // Contructor that handles an exception within the code, for which
	    // we didn't attach an additional message (e.g., a more generic "issue"
	    // that is handled at the final exception handling place)
	    
	    this( exceptionType );
	    
	    // This is the reason we pass along the original Exception in some
	    // of these constructors:
	    if ( BANJO.DEBUG && BANJO.DEV_PRINTSTACKTRACE ) {

	        System.out.println(
                "A fatal error has occurred while executing the " +
                BANJO.APPLICATION_NAME + " Application.\n" +
        		"You may be able to fix the problem by reviewing the information \n" +
        		"provided about the problem, and try to run the program again. \n ");
	        System.out.println(
	            "Otherwise please provide the information below to the developer\n" +
	        	"as a clue to fixing the problem. Thank you.\n" +
	        	"\n** Start of internal trace info **");
	        e.printStackTrace();
	        System.out.println(
		        	"** End of internal trace info **\n");
	    }
	}

    /**
     * For trapping an existing exception, and attaching both a type and a 
     * message to it. <br>
     * 
     * @param e The Exception that was encountered, and that triggered the
     * creation of this BanjoException. <br>
     * Note: when DEV_PRINTSTACKTRACE is turned on,
     * the original exception will be echo-printed to the standard i/o.
     * @param exceptionType The type of the BanjoException to set.
     * @param customMessage The message to attach to the BanjoException.
     */
	public BanjoException( Exception e, 
	        final int exceptionType, final String customMessage ) {
		
	    // Basic constructor for trapping an existing exception, and
	    // attaching both a type and a message to it.
	    
	    this( e, exceptionType );
	    this.message = new String( customMessage );
	}

    /**
     * For propagating an existing BanjoException.
     * 
     * @param e The BanjoException to propagate.
     */
	public BanjoException( BanjoException e ) {

	    // This constructor is mainly used to propagate an existing exception
	    // of BanjoException "type" 
	    
		this.exceptionType = e.exceptionType;
		if ( e.message != null )
		    this.message = new String( e.getMessage() );
	}

    /**
     * Is used when we didn't encounter an exception in the
     * code, but rather want to flag an "issue" (e.g., unusable input value, etc)
     * 
     * @param exceptionType The type of the BanjoException to set.
     * @param customMessage The message to attach to the BanjoException.
     */
	public BanjoException( final int exceptionType, final String customMessage ) {
		
	    // This constructor is used when we didn't encounter an exception in the
	    // code, but rather want to flag an "issue" (e.g., unusable input value, etc)
	    
	    this( exceptionType );
	    this.message = new String( customMessage );
	}

	/**
	 * @return Returns the exceptionType.
	 */
	public int getExceptionType() {
		return exceptionType;
	}
    /**
     * @return Returns the message.
     */
    public String getMessage() {
        return message;
    }
    /**
     * @param message The message to set.
     */
    public void setMessage(String message) {
        this.message = message;
    }
}
