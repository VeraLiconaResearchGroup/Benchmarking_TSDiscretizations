/*
 * Created on Apr 16, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

//import edu.duke.cs.banjo.data.*;
import java.util.*;
import java.io.*;


/**
 * Handles all file input and output for the application.
 *
 * <p><strong>Details:</strong> <br>
 * 
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 16, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class FileUtil {

	private static FileWriter resultFileWriter;
	private static OutputStreamWriter resultStreamWriter;
	private static PrintWriter resultPrintWriter;
	private static String resultsFileName = new String();
	
	private static String[] cachedFileList;

	// TODO: find better estimate of output amount, if possible
	private static StringBuffer reportBuffer = 
	    new StringBuffer(BANJO.BUFFERLENGTH_STAT);

	// Note: There is no buffer for errors; instead they are reported immediatedly
	
	// Use(d) as raw storage container for the initialSettings as read from the
    // settings file
 	private static Properties settings = new Properties();
	
	private static boolean traceToConsole;
	
	// Flag to avoid setting up the output files multiple times
	private static boolean resultFileReady = false;
	
	public FileUtil() {};
	
	// One-time preparation method for writing to files
	private static void setupOutputFile() throws Exception {
		
	    String errorMessage;
		String resultDirectoryName = settings.getProperty(
		        BANJO.SETTING_OUTPUTDIRECTORY );
		File resultDirectory;
		
		if ( resultDirectoryName == null || resultDirectoryName.equals( "" ) ) {
		    
		    // Use default directory
		    resultDirectoryName = BANJO.DEFAULT_RESULTDIRECTORY;
		    resultDirectory = new File( resultDirectoryName );
		    
		    if ( !resultDirectory.exists() ) resultDirectory.mkdirs();
		}
		else {
		    
		    resultDirectory = new File( resultDirectoryName );
		    
		    if ( !resultDirectory.exists() ) resultDirectory.mkdirs();
		}
		    
	    resultDirectoryName = resultDirectoryName + "/";

	    // In case the files have been set up already, skip this method.
		// (The closeFiles method will reset the flag)
		//if ( outputFilesReady ) return;
		resultFileReady = false;
		
		// TODO: load from settings file
		// For now use config option:
		traceToConsole = BANJO.CONFIG_ECHOOUTPUTTOCMDLINE;
		
		// For now, we route all output to a file (report/summary/trace)
		// Note that writing out an error is handled differently

		try {
			
			resultsFileName = settings.getProperty(BANJO.SETTING_REPORTFILE);
			
			// Do we need to use the default?
			if (resultsFileName == null || resultsFileName.length() < 1 ) 
			    resultsFileName = BANJO.DEFAULT_RESULTSFILE;

			resultsFileName = resultDirectoryName + resultsFileName;
			
			resultStreamWriter = new OutputStreamWriter(
					new FileOutputStream(resultsFileName, true));
			
			resultPrintWriter = new PrintWriter(resultStreamWriter);
			resultFileReady = true;
		}
		catch (IOException e) {
			
			errorMessage = "FileUtil.setupOutputFiles  --  Can't access results file '" + 
					resultsFileName +  "'.";
			System.out.println( errorMessage );
	   		if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL ) 
	   		    e.printStackTrace();
			recordError( errorMessage );
			throw new BanjoException( e,
			        BANJO.ERROR_OUTPUTTORESULTSFILE, errorMessage  );
		}
	}
	
	public static void writeToFile( final Collection outputFileFlags, 
	        final StringBuffer dataToWrite ) throws Exception {
	    
	    Integer fileFlag;
	    
	    setupOutputFile();
	        
	    if (traceToConsole) System.out.println( dataToWrite );
	    
	    Iterator fileFlagIterator = outputFileFlags.iterator();
	    while ( fileFlagIterator.hasNext() ) {
	        
	        fileFlag = (Integer) fileFlagIterator.next();
	    
		    switch (fileFlag.intValue())
		    {
		    case BANJO.FILE_RESULTS:
		    	
		        setupFile(resultFileWriter, resultStreamWriter, 
		                resultPrintWriter, resultsFileName );
		    
		    	resultPrintWriter.println( dataToWrite );
				resultPrintWriter.close();
			    break;
			    
		    default: 
		        
		        // this should never happen:
		        throw new BanjoException(
		                BANJO.ERROR_DEV_UNKNOWNOUTPUTFILE, 
		                "(FileUtil.writeToFile) Dev error: " +
		                "trying to write data to unknown file." );
		    }
	    }
	}
	
	public static void setupFile( FileWriter fileWriter,
	        OutputStreamWriter outputStreamWriter,
	        PrintWriter printWriter,
	        String fileName ) throws Exception {
	    	    
		try {
													
			outputStreamWriter = new OutputStreamWriter(
					new FileOutputStream( fileName, true) );
			printWriter = new PrintWriter(outputStreamWriter);
			resultFileReady = true;
		}
		catch (IOException e) {
			
			String errorMessage = "(FileUtil.setupFile)  --  Can't access output file '" + 
					fileName +  "'.";
			System.out.println( errorMessage );
	   		if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL ) 
	   		    e.printStackTrace();
			recordError( errorMessage );
			throw new BanjoException(  e  , 5, errorMessage );
		}
	}
	
	// Completely separate method for writing out an error
	public static void recordError( String outputString ) throws Exception {
		
		
		FileWriter errorFileWriter;
		OutputStreamWriter errorStreamWriter = null;
		PrintWriter errorPrintWriter = null;

		// Decide to place error file in application directory instead
		//String errorDirectory = new String(); 
	    String errorFileName = new String();
	    
		try {
			
		    errorFileName = settings.getProperty( 
		            BANJO.SETTING_ERRORFILE );
					
			if ( errorFileName == null || errorFileName.length() < 1 ) 
				errorFileName = BANJO.DEFAULT_ERRORFILE;
						
			errorStreamWriter = new OutputStreamWriter(
					new FileOutputStream(errorFileName, true));
			errorPrintWriter = new PrintWriter(errorStreamWriter);		
		
			// For now, write all output to the error file
			errorPrintWriter.println( "\n" + outputString );
						
			errorPrintWriter.close();
		}
		catch (Exception e) {
			
			// Record any IO error separately - could happen for various reasons
		    // that the user could do something about?
			System.out.println("FileUtil  --  Can't access error file  '" + 
					errorFileName +  "'.");
			System.out.println("FileUtil -- " +
					"The following error could not be written to the error file: \n"
					+ outputString );
			

	   		if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL ) 
	   		    e.printStackTrace();
	   		
	   		throw new Exception( e );
		}		
		finally {
		    try {
		        errorPrintWriter.close();
		        errorStreamWriter.close();
		    }
		    catch (Exception e) {
		        
		        // Is there a point to do anything besides telling the user?
		        System.out.println("Error cleaning up after trying " +
		        		"to write to error file.");
		        
		        throw new Exception( e );
		    }
		}
	}
	
	public static Properties loadSettings( 
	        String directoryName, 
	        String inputFileName ) throws Exception {
	    	    
  		File inputFile;
	    
  		try {
  		    
		    // Check if a file name has been supplied:
		    if ( inputFileName != null || inputFileName.length() > 0 ) {
	
		        // Check if a directory name has been supplied:
		        if ( directoryName != null && directoryName.length() > 0 ) {
		            
		            inputFile = new File( directoryName, inputFileName );
		        }
		        else {
		        
		            inputFile = new File( inputFileName );
		        }
		        
		        // Ccheck if the file actually exists
			    if ( !inputFile.exists() ) {
			        
			        // Now try to find the settings file in the default input directory
			        directoryName = BANJO.DEFAULT_LOADDIRECTORY;
			        inputFile = new File( directoryName, inputFileName );
			        
			        if ( !inputFile.exists() ) {
			            
			            // We give up looking for the settings file and tell the
			            // user that the file could not be found
			            // Note: we don't try to recover by trying to find a file with the 
			            // default settings file name
				        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
		                	"The settings file '" +
		                	inputFileName +
		                	"' can not be found at '" +
		                	directoryName +
		                	"'" );
			        }
			    }
		    }
		    else {
		        
		        // No name for the settings file has been provided, so check if the default
		        // file exists
		  		inputFile = new File(BANJO.DEFAULT_LOADDIRECTORY, 
	    				BANJO.DEFAULT_SETTINGSFILENAME);
		  		
	    		// If there is no settings file in the specified LoadDirectory
	    		// then try the directory from where the application is running:
	    		if ( !inputFile.exists() ) {
	    			
	    			inputFile = new File(BANJO.DEFAULT_SETTINGSFILENAME);
	    			if ( !inputFile.exists() ) {
	    				
	    				throw new BanjoException( BANJO.ERROR_MISSING_SETTINGSFILE, 
	    				        "\n *** Settings File: '" + 
	    						inputFile.getAbsolutePath() + "'");
	    			}
	    		}
	    		else {
	    		    
	    		    if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL )
		    			System.out.println( "Setting file '" + 
		    					BANJO.DEFAULT_LOADDIRECTORY 
		    					+ "/" 
		    					+ BANJO.DEFAULT_SETTINGSFILENAME
		    					+ "' loaded successfully." );
	    		}
		    }
		       
		    // We should have a valid file now, which we try to load into the 
		    // properties container
	   		FileInputStream cmdParameterFile = new FileInputStream(inputFile);
	   		
	   		// TODO: (Marker only) This is the place where we can add support for
	   		// other input file formats
			settings.load(cmdParameterFile);	
		}
		catch (Exception e){
			
		    // May not want the internal error message displayed to the end user
		    if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL )
		        System.out.println("\n(FileUtil.LoadSettings) " + e.toString() + "\n" );
		    
			if ( BANJO.DEBUG && BANJO.TRACE_FILEUTIL ) 
			    e.printStackTrace();
			
			// Pass the message on to the caller for final handling
			throw new BanjoException( e, BANJO.ERROR_MISSING_SETTINGSFILE );
		}	
	    
		// Add the input file to the just loaded settings
		settings.setProperty( BANJO.VALIDATED_SETTINGSFILENAME,
		        inputFile.toString() );
		settings.setProperty( BANJO.VALIDATED_SETTINGSFILEWITHPATH,
		        inputFile.getPath() );

		return settings;
	}
}
