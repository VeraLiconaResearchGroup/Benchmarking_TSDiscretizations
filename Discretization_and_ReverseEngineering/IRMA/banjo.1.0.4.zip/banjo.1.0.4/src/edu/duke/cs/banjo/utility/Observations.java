/*
 * Created on Mar 4, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

import java.io.*;
import java.util.*;

//import edu.duke.cs.banjo.utility.*;

/**
 * Loads the observation data necessary for the search.
 *
 * <p><strong>Details:</strong> <br>
 *  - <strong>Important:</strong>
 * The Evaluator class uses the internal representation of the Observations 
 * for performance, thus breaking encapsulation. <br>
 * 
 * - Implementation of a data set, using a simple matrix of <br>
 * 	&nbsp&nbsp&nbsp		n rows of observationDataPoints <br>
 * 	&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp&nbsp	by <br>
 * 	&nbsp&nbsp&nbsp		m columns of variables (nodes) <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 4, 2004 <br>
 * 
 * 4/1/2004	hjs		Change data type for external access to int <br>
 * 7/7/2004	hjs		Change the internal representation from Char to Integer
 * 
 * 9/14/2005 hjs	1.0.4 	Changes to properly handle discretization of multiple 
 * 							observation files
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 * 
 */
public class Observations {

	protected Settings processData;

	private final int variableCount;
	private final int maxMarkovLag;
	
	// The observationRowCount shows the number of rows that were loaded from
	// the associated data file(s) of an observations object
	private final int observationRowCount;
	// The observationCount shows the number of actual observations used in computing
	// the score. Of course, for maxMarkovLag=0, both  observationCount and 
	// observationRowCount are the same. We don't combine both (its possible at a
	// cost of much complexity in the code) because it keeps the code much simpler
	private int observationCount;
	
	// hjs 7/6/04 Allow public access;  We may make entries final after
	// all validation and date correction issues have been resolved
	// hjs 7/7/04 Change the observation matrix from Char to Integer
	// hjs 4/18/04 Add 3rd dimension to store "shifted" data (e.g., to 
	// facilitate easy computations of BDe metric for dbns)
	public int[][][] observationDataPoints; 

	public int[][] observationRowDataPoints;
		
	public String[][] rawObservationRowDataPoints;
	
	// This stores the max number of values that the variables 
	// assume in the observations
	private int[] maxValueCount;
	
	public Observations( final Observations[] _observations,
	        final int _variableCount,
	        final int _maxMarkovLag,
	        final boolean relatedObservations,
	        final Settings _processData ) throws Exception {

	    this.processData = _processData;
	    int sumOfObservationCounts = 0;
		int obsIndexStart = 0;
		int obsIndexEnd;
		Observations singleObservation;
		
	    this.variableCount = _variableCount;
		this.maxMarkovLag = _maxMarkovLag;
		
		// Inner class used for discretization: stores the
		// value associated with each key
		class Counter {
		    int i;
		    public Counter() { i = 1; };
		    public Counter( int _i ) { i = _i; };
		    public String toString() {
		        return Integer.toString( i );
		    }
		}
		
		// Add up the row counts from all the files 
		for ( int i=0; i< _observations.length; i++ ) {
		    
		    sumOfObservationCounts += ((Observations) _observations[i])
		    		.getObservationRowCount();
		}

		this.observationRowCount = sumOfObservationCounts;
		
		// Adjust the total number of observations by maxMarkovLag for each file 
		if ( !relatedObservations ) {
		    
		    sumOfObservationCounts -= _observations.length * maxMarkovLag;
		}
		else {
		    
		    // For "related" observations, only need to subtract the max. lag once
		    sumOfObservationCounts -= maxMarkovLag;		    
		}
		
		this.observationCount = sumOfObservationCounts;

		rawObservationRowDataPoints = new String[observationRowCount]
				                             [variableCount];
		observationRowDataPoints = new int[observationRowCount]
				                             [variableCount];
		observationDataPoints = new int[observationCount]
			                             [variableCount][maxMarkovLag+1];
		
		// Combine all raw data
		int offset = 0;
		for ( int i=0; i < _observations.length; i++ ) {
		    
		    for ( int j=0; j < ((Observations) _observations[i])
    					.getObservationRowCount(); j++ ) {
			    
		        for ( int k=0; k < variableCount; k++ ) {
				    
		            rawObservationRowDataPoints[ offset + j ][ k ] = 
		                ((Observations) _observations[ i ])
		                		.rawObservationRowDataPoints[ j ][ k ];
		        }
		    }
		        
		    offset += ((Observations) _observations[ i ]).observationRowCount;
		}
		    
		// -------------------------
		// Set up the discretization
		// -------------------------
	
		int length;
		int tokenCount;
		final int varCount = this.getVariableCount();
		int observedVarCount;
		final int obsCount = this.getObservationRowCount();
		String currentObservationValue;
	    double[] minObsValue = new double[varCount];
	    for ( int z=0; z<varCount; z++ ) 
	        minObsValue[z] = BANJO.BANJO_LARGEINITIALVALUEFORMINIMUM;
	    double[] maxObsValue = new double[varCount];
	    for ( int z=0; z<varCount; z++ ) 
	        maxObsValue[z] = BANJO.BANJO_SMALLINITIALVALUEFORMAXIMUM;
	    
	    double dblCurrentObsValue;
	    Double tmpDbl;
	    int tmpInt;
		SortedMap[] originalValuesMap = new SortedMap[varCount];
		for ( int z=0; z<varCount; z++ )
		    originalValuesMap[z] = new TreeMap();
		// For temp. output only:
		SortedMap[] tmpOriginalValuesMap = new SortedMap[varCount];
		for ( int z=0; z<varCount; z++ )
		    tmpOriginalValuesMap[z] = new TreeMap();

		String strDiscretizationChoice = 
		    processData.getValidatedProcessParameter( 
		        BANJO.DATA_DEFAULTDISCRETIZATIONCHOICE );
		int defaultDiscretizationPoints = Integer.parseInt(  
				    processData.getValidatedProcessParameter( 
					BANJO.DATA_DEFAULTDISCRETIZATIONPOINTS ) );
		
		if ( defaultDiscretizationPoints > BANJO.CONFIG_MAXVALUECOUNT ) {
            
            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
                    "The number of points ('" + defaultDiscretizationPoints +
                    "') specified in the discretization exception '" + 
                    strDiscretizationChoice + defaultDiscretizationPoints +
                    "'\ncannot exceed Banjo's restriction " +
                    "(via configuration) on " +
                    "the max. number of values \n" +
                    "that a variable can have ('" +
                    BANJO.CONFIG_MAXVALUECOUNT +
                    "')." );
        }
		
		String strDiscretizationExceptions = 
		    processData.getValidatedProcessParameter( 
		        BANJO.SETTING_DISCRETIZATIONEXCEPTIONS );
		
		int itemCount = 0;
		StringTokenizer itemTokenizer;
	    boolean discretizationFlag = false;
		String[] discretizationType = new String[varCount];
		int[] discretizationPoints = new int[varCount];
		int[] intervals = new int[varCount];
		
		// ----------------------------------------------
		// Set up the optional discretization of the data
		// ----------------------------------------------
		
		// Part 1: Apply the discretization policy
		for ( int item=0; item<varCount; item++ ) {
	    	
		    discretizationType[ item ] = strDiscretizationChoice;
		    discretizationPoints[ item ] = defaultDiscretizationPoints;
			intervals[ item ] = defaultDiscretizationPoints - 1;	
		}
		
		if ( !strDiscretizationChoice.equals( BANJO.UI_DISCRETIZATIONNONE )) {
		    
	        discretizationFlag = true;
	    }
		
		// Part 1: Apply the exceptions to the discretization policy
		if ( !strDiscretizationExceptions.equalsIgnoreCase( 
		        BANJO.BANJO_NOVALUESUPPLIED_STRING )) {
		    
		    StringTokenizer exceptionsTokenizer = new StringTokenizer( 
		            strDiscretizationExceptions, BANJO.EXCEPTIONSDELIMITER );
		    int exceptionsCount = exceptionsTokenizer.countTokens();
		    
		    for ( int exception=0; exception<exceptionsCount; exception++ ) {
		        
		        StringTokenizer exceptionItemTokenizer = new StringTokenizer(
		                exceptionsTokenizer.nextToken().trim(), 
			            BANJO.EXCEPTIONITEMDELIMITER );
		        
		        int varIndex = Integer.parseInt( 
		                exceptionItemTokenizer.nextToken().trim() ) - 
		                BANJO.CONFIG_DISCRETIZATIONSTARTINDEX;
		        String exceptionType = exceptionItemTokenizer.nextToken().trim();
		        
		        if ( varIndex >= varCount ) {
		            
		            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
		                    "Invalid variable index ('" + varIndex +
		                    "') specified." );
		        }
		        
		        if ( exceptionType.equalsIgnoreCase( BANJO.UI_DISCRETIZATIONNONE )) {
		            
		            discretizationType[ varIndex ] = BANJO.UI_DISCRETIZATIONNONE;
		        }
		        else {
		            
		            String strExceptionChoice = exceptionType.substring(
		                    0, exceptionType.length()-1 );
		            int exceptionPoints = Integer.parseInt( 
		                    exceptionType.substring( 
		                            exceptionType.length()-1, exceptionType.length()) );
		            
		            if ( exceptionPoints > BANJO.CONFIG_MAXVALUECOUNT ) {
		                
		                throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
			                    "The number of points ('" + exceptionPoints +
			                    "') specified in the discretization exception '" + 
			                    strExceptionChoice + exceptionPoints +
			                    "'\ncannot exceed Banjo's restriction " +
			                    "(via configuration) on " +
			                    "the max. number of values\n" +
			                    "that a variable can assume ('" +
			                    BANJO.CONFIG_MAXVALUECOUNT +
			                    "')." );
		            }
		            
		            discretizationType[ varIndex ] = strExceptionChoice;
				    discretizationPoints[ varIndex ] = exceptionPoints;
					intervals[ varIndex ] = exceptionPoints - 1;
					
					discretizationFlag = true;
		        }
		    }
		}
				
		// Discretize the combined raw data
		
	    // Do the pre-processing for the discretization and the optional
	    // data (discretization) report
	    for ( int j=0; j < this.observationRowCount; j++ ) {

	        for ( int k=0; k < variableCount; k++ ) {
		    
	            dblCurrentObsValue = Double.parseDouble(
	                        rawObservationRowDataPoints[ j ][ k ] );

			    // First check if the current value is a new max or min
			    if ( dblCurrentObsValue < minObsValue[ k ] ) 
			        minObsValue[ k ] = dblCurrentObsValue;
			    if ( dblCurrentObsValue > maxObsValue[ k ] ) 
			        maxObsValue[ k ] = dblCurrentObsValue;
			    
			    // place in valueMap for quantile discretization
			    if ( originalValuesMap[ k ].containsKey( 
			            new Double( dblCurrentObsValue )) ) { 
			        
			        ( (Counter) originalValuesMap[ k ].get( 
			                new Double( dblCurrentObsValue ) )).i++;
			    }
			    else {
			        
			        originalValuesMap[ k ].put( new Double( dblCurrentObsValue ) , 
			                new Counter() );
			    }
			}
		}

	    if ( BANJO.DEBUG && BANJO.TRACE_DISCRETIZATION ) {
	        
			System.out.println();
			for ( int z=0; z<varCount; z++ ) {
				System.out.print( "Var= " + z );
				System.out.print( ", min= " + minObsValue[z] );
				System.out.print( " max= " + maxObsValue[z] );
				System.out.print( "  " );
				System.out.println( originalValuesMap[z] );
			}
	    }
		
		// Apply the discretization to the individual observation data sets
		
		// This creates the "buckets" and fills them with the data
		int discreteValue;
		// Apply the discretization per variable:
		SortedMap[] discreteValuesMap = new SortedMap[varCount];
		for ( int z=0; z<varCount; z++ ) 
		    discreteValuesMap[z] = new TreeMap();
							    
	    Double DblCurrentObsValue; 
	    int[] mapSize = new int[varCount];
	    int cumulativeCount = 0;
	    int discretizedValue = 0;
	    for ( int z=0; z<varCount; z++ ) {
	   
	        discreteValuesMap[z].putAll( originalValuesMap[z] );
	        tmpOriginalValuesMap[z].putAll( originalValuesMap[z] );
	        mapSize[z] = originalValuesMap[z].size();
	    }
	    
	    for ( int z=0; z<varCount; z++ ) {

			// Special rule: only if we found more "buckets" than specified
			// discretization value, do we apply the discretization rules!
			// Otherwise we just use the data in the form that it is in.

	        if ( originalValuesMap[z].size() <= discretizationPoints[z] ) {
	            
	            for ( int m=0; m<mapSize[z]; m++ ) {
	                
	                DblCurrentObsValue = 
			            (Double) originalValuesMap[z].firstKey();
			        						    
				    // Trivial assignment of the new discrete value; 
	                // keep for clarity
					discreteValue = m;
					
					discreteValuesMap[z].put( DblCurrentObsValue, 
				                new Counter( discreteValue ));
					
			        originalValuesMap[z].remove( DblCurrentObsValue );
	            }
	        }
	        else {
	            
	            DblCurrentObsValue = 
		            (Double) originalValuesMap[z].firstKey();
		        discretizedValue = 0;

		        cumulativeCount = 
				      ( (Counter) originalValuesMap[z].get( 
				              DblCurrentObsValue )).i;
		        
		        discreteValuesMap[z].put( DblCurrentObsValue, 
				          new Counter( discretizedValue ));
		        
		        originalValuesMap[z].remove( DblCurrentObsValue );
	        
			    for ( int m=1; m<mapSize[z]; m++ ) {
			        				         
			        if ( discretizationType[z].equals( 
			                BANJO.UI_DISCRETIZATIONBYINTERVAL ) ) {

				        DblCurrentObsValue = 
				            (Double) originalValuesMap[z].firstKey();
				        
					    dblCurrentObsValue = DblCurrentObsValue.doubleValue();
						discreteValue = (int) Math.round( 
						        ( dblCurrentObsValue - minObsValue[z] ) * 
						        intervals[z] / maxObsValue[z] );
						
						 discreteValuesMap[z].put( DblCurrentObsValue, 
					                new Counter( discreteValue ));
				    }
				    else if ( discretizationType[z].equals( 
			                BANJO.UI_DISCRETIZATIONBYQUANTILE ) ) {

				        DblCurrentObsValue = 
				            (Double) originalValuesMap[z].firstKey();

						cumulativeCount += 
						      ( (Counter) originalValuesMap[z].get( 
						              DblCurrentObsValue )).i;
						
						while ( cumulativeCount*discretizationPoints[z] > 
						          obsCount*( discretizedValue+1 ) && 
						          discretizedValue < intervals[z] ) {
						      
						      discretizedValue++;
						}
						  
						discreteValuesMap[z].put( DblCurrentObsValue, 
						          new Counter( discretizedValue ));
				    }
			        
			        originalValuesMap[z].remove( DblCurrentObsValue );
			        if ( !originalValuesMap[z].isEmpty() ) {
				        
			            DblCurrentObsValue = 
				            (Double) originalValuesMap[z].firstKey();
			        }
			    }
		    }
	    }

	    // Create the optional data report
	    if ( processData.getValidatedProcessParameter( 
		        BANJO.SETTING_DATAREPORT ).equals( 
		                BANJO.UI_DATAREPORT_YES )) {
	        
	        StringBuffer dataReport = new StringBuffer( 
	                BANJO.BUFFERLENGTH_STAT );

			String prefix = "\n";
			String newLinePlusPrefix = "\n" + BANJO.FEEDBACKDASH;
			String slash = BANJO.FEEDBACKSLASH;
			int lineLength = BANJO.FEEDBACKLINELENGTH;
			int tabStop1 = "Variable".length();
			int rightDiff1 = 4;
			int tabStop2 = "Discr.".length();
			int rightDiff2 = 3;
			int tabStop3 = "Min. Val.".length();
			int rightDiff3 = 3;
			int tabStop4 = "Max. Val.".length();
			int rightDiff4 = 3;
			int tabStop5 = " Orig. ".length()-1;
			int rightDiff5 = 3;
			int tabStop6 = " Used  ".length()-1;
			int rightDiff6 = 3;
			int tabStop7 = "Original value counts".length();
			int rightDiff7 = 3;
								
			// Add the header "indicator band"
			dataReport.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength )); 
		    dataReport.append( StringUtil.formatRightLeftJustified( 
		            newLinePlusPrefix, " Pre-processing", 
			        "Discretization report", null, lineLength ) );
		    dataReport.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength )); 

		    String headerLine1 = " Variable | Discr. | Min. Val. | Max. Val. |" +
    				"  Orig. |  Used  |";
		    String headerLine2 = "          |        |           |           |" +
    				" points | points |";
		    
		    if ( BANJO.CONFIG_DISPLAYMAPPEDVALUES ) {
		        
		        // Generally, if no variable is tagged to be discretized, then
		        // we don't want to do anything
			    if ( discretizationFlag ) {
			        
			        headerLine1 += "  Mapped values";
			        headerLine2 += " |";
			    }
		    }
		    dataReport.append( StringUtil.formatRightLeftJustified( 
			        prefix, headerLine1,
			        "", null, lineLength ) );
		    dataReport.append( StringUtil.formatRightLeftJustified( 
			        prefix, headerLine2,
			        "", null, lineLength ) );
		    dataReport.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength )); 
		    
		    for ( int z=0; z<varCount; z++ ) {
		    					        
			    dataReport.append( StringUtil.formatRightLeftJustified( 
				        prefix, "", Integer.toString( z ), null, tabStop1 ) );
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff1 ) );
			    
			    if ( discretizationType[z].equals( 
			            BANJO.UI_DISCRETIZATIONNONE )) {
			        
				    dataReport.append( StringUtil.formatRightLeftJustified( 
				            "", "", discretizationType[z], null, tabStop2 ) );
			    }
			    else {
			        
			        dataReport.append( StringUtil.formatRightLeftJustified( 
				            "", "", discretizationType[z] + 
				            discretizationPoints[z], null, tabStop2 ) );
			    }
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff2 ) );
			    
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", Double.toString( minObsValue[z] ), 
				        null, tabStop3 ) );
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff3 ) );
			    
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", Double.toString( maxObsValue[z] ), 
				        null, tabStop4 ) );
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff4 ) );
			    
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", Integer.toString( 
				                tmpOriginalValuesMap[z].size() ), 
				        null, tabStop5 ) );
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff5 ) );

			    if ( discretizationType[z].equals( 
			            BANJO.UI_DISCRETIZATIONNONE )) {
			    
			        dataReport.append( StringUtil.formatRightLeftJustified( 
				            "", "", Integer.toString( 
					                tmpOriginalValuesMap[z].size() ), 
					        null, tabStop6 ) );
			    }
			    else {
			        
			        int pointsUsed = 0;
			        boolean[] valuesTracked = new boolean[discretizationPoints[z]];
			        int usedValue;
					SortedMap tmpValuesMap = new TreeMap();
					tmpValuesMap.putAll( discreteValuesMap[z] );
			        						        
			        for ( int j=0; j<discretizationPoints[z]; j++ ) {
			            valuesTracked[j] = false;
			        }
			        for ( int j=0; j<discreteValuesMap[z].size(); j++ ) {
			            
			            DblCurrentObsValue = 
				            (Double) tmpValuesMap.firstKey();
			            usedValue = ( (Counter) tmpValuesMap.get( 
					              DblCurrentObsValue )).i;
			            tmpValuesMap.remove( DblCurrentObsValue );
			            
			            if ( !valuesTracked[ usedValue ] ) pointsUsed++;
			            valuesTracked[ usedValue ] = true;
			        }
			        
			        dataReport.append( StringUtil.formatRightLeftJustified( 
				            "", "", Integer.toString( pointsUsed ), 
					        null, tabStop6 ) );
			    }
			    dataReport.append( StringUtil.formatRightLeftJustified( 
			            "", "", slash, null, rightDiff6 ) );
			    					    
			    // Useful for examining how the discretization "maps" the 
			    // data values (becomes too much data quickly, though)
			    if ( BANJO.CONFIG_DISPLAYMAPPEDVALUES ) {
			        
				    if ( discretizationType[z].equals( 
				            BANJO.UI_DISCRETIZATIONNONE )) {
				        
				        dataReport.append( StringUtil.formatRightLeftJustified( 
					            "", "", "counts: " + 
					            tmpOriginalValuesMap[z].toString(), 
						        null, tabStop7 ));
				    }
				    else {
				            
				        dataReport.append( StringUtil.formatRightLeftJustified( 
					            "", "", "map: " + 
					            discreteValuesMap[z].toString(),
						        null, tabStop7 ));
				    }
			    }
		    }

			dataReport.append( BANJO.FEEDBACKDASHEDLINE.
			        substring( 0, lineLength )); 
			dataReport.append( "\n" ); 
			
			// Store the report in a dynamic setting
			processData.setDynamicProcessParameter( BANJO.DATA_DISCRETIZATIONREPORT,
			        dataReport.toString() );
		}
	    

		int tmpVariableCount;
		int tmpObsCount;
		for ( int i=0; i < _observations.length; i++ ) {
		    
		    tmpObsCount = ((Observations) _observations[ i ]).observationRowCount;
		    
			for ( int k=0; k < tmpObsCount; k++ ) {
			    
			    tmpVariableCount = ((Observations) _observations[ i ]).variableCount;
		        
				for ( int j=0; j < tmpVariableCount; j++ ) {
				    
				    if ( discretizationType[j].equals( 
				            BANJO.UI_DISCRETIZATIONBYINTERVAL ) ) {
	
					    dblCurrentObsValue = Double.parseDouble( 
					            ((Observations) _observations[ i ]).
					            	rawObservationRowDataPoints[k][j] );
						discreteValue = (int) Math.round( 
						        ( dblCurrentObsValue - minObsValue[j] ) * 
						        intervals[j] / maxObsValue[j] );
						
						((Observations) _observations[ i ]).
							observationRowDataPoints[k][j] = discreteValue;
				    }
				    else if ( discretizationType[j].equals( 
				            BANJO.UI_DISCRETIZATIONBYQUANTILE ) ) {
				        
				        tmpDbl = new Double( ((Observations) _observations[ i ]).
				                rawObservationRowDataPoints[k][j] );
				        
				        discreteValue = ( (Counter) 
				                discreteValuesMap[j].get( tmpDbl )).i;				        
						
				        ((Observations) _observations[ i ]).
				        		observationRowDataPoints[k][j] = discreteValue;
				    }
				}
			}
		}

		// Now compute the observation data points that are used for
		// computing the score (for DBNs, the first maxMarkovLag data
		// rows are time points that are not used by themselves)

		for ( int i=0; i < _observations.length; i++ ) {
		    
		    for ( int lagIndex=0; lagIndex < maxMarkovLag+1; lagIndex++ ) {
		        
		        tmpVariableCount = ((Observations) _observations[ i ]).variableCount;
		        
		        for ( int varIndex=0; varIndex < tmpVariableCount; varIndex++ ) {
		            
				    tmpObsCount = ((Observations) _observations[ i ]).observationRowCount;
				    
		            for ( int rowIndex=maxMarkovLag; 
		            		rowIndex < tmpObsCount; rowIndex++ ) {
			        
		                // Each row of the row observations is shifted by one for each
		                // change by 1 in the Markov lag 
		                ((Observations) _observations[ i ]).
		                	observationDataPoints[rowIndex-maxMarkovLag]
		                                      [varIndex][lagIndex] = 
                              ((Observations) _observations[ i ]).
                                  observationRowDataPoints[rowIndex-lagIndex][varIndex];
		            }
			    }
			}
		    
		    // At this point we don't need the raw data loaded from the individual 
		    // observation files anymore:
		    ((Observations) _observations[ i ]).rawObservationRowDataPoints = null;
		}
				
		// -------------------------
		// Finally, set the combined observations to the discretized values
		// -------------------------
		
		obsIndexEnd = 0;
		if ( maxMarkovLag == 0 ) {
		    
		    for ( int m=0; m < _observations.length; m++ ) {

			    singleObservation = (Observations) _observations[m];
		        obsIndexStart = obsIndexEnd;
			    obsIndexEnd += singleObservation.getObservationRowCount();
			    
			    for (int i=obsIndexStart; i<obsIndexEnd; i++) {
					for (int j=0; j<variableCount; j++) {
					    
				        this.observationDataPoints[i][j][0] = 
						    singleObservation.observationDataPoints
						    	[i-obsIndexStart][j][0];
					}
			    }
		    }
		}
		else {
		    
		    // DBN case

 		    if ( relatedObservations ) {
		        
 	            // Case 1: "seamless stitching" of "related" data (i.e., a time
 		        // series in file N+1 is a continuation of the time series in
 		        // file N.
 		        
 		        // First collect the entire data set (all rows from all files
 		        // in the indicated order)
 		        int rowIndex = 0;
		        for ( int m=0; m < _observations.length; m++ ) {
	
				    singleObservation = (Observations) _observations[m];
				    obsIndexEnd = singleObservation.getObservationRowCount();
				    
				    for (int i=0; i<obsIndexEnd; i++) {
						for (int j=0; j<variableCount; j++) {
						    
					        this.observationRowDataPoints[rowIndex][j] = 
							    singleObservation.observationRowDataPoints
							    	[i][j];
						}
				        rowIndex++;
				    }
			    }
		        
		        // Now "shift" the entire data set into the "lag slots"
	            for ( int row=maxMarkovLag; row<observationRowCount; row++ ) {
			        for ( int varIndex=0; varIndex<variableCount; varIndex++ ) {
			            	for ( int lagIndex=0; lagIndex<maxMarkovLag+1; lagIndex++ ) {
				        
			                // Each row of the row observations is shifted by one for each
			                // change by 1 in the Markov lag 
			                observationDataPoints
			                		[row-maxMarkovLag][varIndex][lagIndex] =
			                    observationRowDataPoints
			                    	[row-lagIndex][varIndex];
			            }
				    }
				}
			    this.observationCount = rowIndex - maxMarkovLag;
		    }
 		    // "unrelated" observations (this is the only supported case as of 5/05)
		    else {
		        
		        // Case 2: Processing "unrelated" observations files (i.e., the
		        // time series in each file are not continuations of any other file)
		        
			    int rowIndex = 0;
			    for ( int m=0; m < _observations.length; m++ ) {
			    	
				    singleObservation = (Observations) _observations[m];
				    // Note that here we use the row count
				    // and assign the RowDataPoints
				    obsIndexEnd = singleObservation.getObservationRowCount();
				    
				    for (int i=0; i<obsIndexEnd; i++) {
						for (int j=0; j<variableCount; j++) {
						    
					        this.observationRowDataPoints[rowIndex][j] = 
							    singleObservation.observationRowDataPoints
							    	[i][j];
					        
					        
						}
				        rowIndex++;
				    }
			    }
			    
			    // Ok, with some tricks we could combine this loop with the above one,
			    // but I prefer simplicity, and we only execute this once at the
			    // setup of the data
			    rowIndex = 0;
			    for ( int m=0; m < _observations.length; m++ ) {
			    	
				    singleObservation = (Observations) _observations[m];
				    // Here we use the observation count (= row count - maxMarkovLag)
				    // and assign the dataPoints
				    obsIndexEnd = singleObservation.getObservationCount();
				    
				    for (int i=0; i<obsIndexEnd; i++) {
						for (int j=0; j<variableCount; j++) {
			        
					        for ( int k=0; k<maxMarkovLag+1; k++ ) {
					            
					            observationDataPoints
			            			[rowIndex][j][k] = 
			            			    singleObservation.observationDataPoints[i][j][k];
					        }
						}
				        rowIndex++;
				    }
			    }
		    }
		}
	}
	
	public Observations( Observations _observationsToAssign ) {
	    
	    this.variableCount = _observationsToAssign.variableCount;
		this.maxMarkovLag = _observationsToAssign.maxMarkovLag;
		this.observationCount = _observationsToAssign.observationCount;
		this.observationRowCount = _observationsToAssign.observationRowCount;
		
		observationRowDataPoints = new int
				[observationRowCount][variableCount];
		observationDataPoints = new int
				[observationCount][variableCount][maxMarkovLag+1];
		maxValueCount = new int[variableCount];
		
		for ( int i=0; i<observationCount; i++ ) {
		    for ( int j=0; j<variableCount; j++ ) {
		        for ( int k=0; k<maxMarkovLag+1; k++ ) {
		            
		            observationDataPoints[i][j][k] = 
		                _observationsToAssign.observationDataPoints[i][j][k]; 
		        }
		    }
		}
		
		for ( int i=0; i<observationCount; i++ ) {
		    for ( int j=0; j<variableCount; j++ ) {
		            
	            observationRowDataPoints[i][j] = 
	                _observationsToAssign.observationRowDataPoints[i][j]; 
		    }
		}
	}
	
	public Observations( final int _observationCount, 
	        final int _variableCount,
	        final int _maxMarkovLag ) throws Exception {
		
		this.observationCount = _observationCount;
		this.variableCount = _variableCount;
		this.maxMarkovLag = _maxMarkovLag;
		this.observationRowCount = _observationCount + _maxMarkovLag;
		
		observationRowDataPoints = new int[observationRowCount]
			                             [variableCount];

		rawObservationRowDataPoints = new String[observationRowCount]
				                             [variableCount];
		
		if ( observationRowCount < maxMarkovLag+1 ) {
		    
		    throw new BanjoException( BANJO.ERROR_BADOBSERVATIONSDATA, 
		            "(Observations constructor) For DBNs, each observations file needs " +
		            "\nto have at least as many rows " +
		            "as the (max. Markov Lag+1).");
		}
		
		observationDataPoints = new int[observationCount]
		                                [variableCount][maxMarkovLag+1];
		maxValueCount = new int[variableCount];
	}
	
	public Observations( final int _observationCount, 
	        final int _variableCount, 
	        final int _maxMarkovLag,
			final String _directory, 
			final String _fileName,
			final Settings _processData ) 
		throws Exception {
		
	    this( _observationCount, _variableCount, _maxMarkovLag );
	    
	    processData = _processData;
		loadObservationsFile( _directory, _fileName );
				
		computeMaxValueCounts();
	}
	
	public int getMaxValueCount( final int _nodeID ) {
		return maxValueCount[_nodeID];
	}
	
	private void setValueCount( final int _nodeID, final int _newValueCount ) {
		maxValueCount[_nodeID] = _newValueCount;
	}
	
	public void computeMaxValueCounts() {
		
		// init the maxValueCount array (i.e., how many values a variable attains)
		int currentObsValue;
		
		for (int i=0; i<observationCount; i++) {
		    
			// Go through the observationDataPoints and find the number of values
			// for each variable (Note: since the values are normalized between
			// 0 and max, we only need to keep track of max)
		    // We only need to examine the data points [.][.][0], because all
		    // other points are obtained via shifts
			for (int j=0; j<variableCount; j++) {
				
				currentObsValue = observationDataPoints[i][j][0]+1;
				
				if ( currentObsValue > this.maxValueCount[j] ) {
				    
					this.maxValueCount[j] = currentObsValue;
				}
			}
		}
	}
	
	public String toString() {
		
		StringBuffer tmpStr = new StringBuffer( 
		        BANJO.BUFFERLENGTH_STRUCTURE_LARGE );
		
		for (int i=0; i<observationRowCount; i++) {
			for (int j=0; j<variableCount; j++) {

				tmpStr.append( observationDataPoints[i][j][0] );
				tmpStr.append( "  " );
			}
			tmpStr.append( "\n" );
		}
		return tmpStr.toString();
	}
	
	public void setObservationValue(
	        final int _observationIndex, 
	        final int _variableIndex, 
	        final int _MarkovLagIndex, 
			final int _observationValue) {
		
		observationDataPoints[_observationIndex][_variableIndex][_MarkovLagIndex] =
		    _observationValue;
	}
	
	public int getObservationValue(
	        final int _observationRow, final int _variableID, final int _MarkovLag ) {
		
		return observationDataPoints[_observationRow][_variableID][_MarkovLag];
	}
	
	/**
	 * @return Returns the observationRowCount.
	 */
	public final int getObservationRowCount() {
		return observationRowCount;
	}

	/**
	 * @param _observations The observationDataPoints to set.
	 */
	public void setObservationDataPoints( final int[][][] _observations ) {
		this.observationDataPoints = _observations;
	}

	/**
	 * @return Returns the variableCount.
	 */
	public final int getVariableCount() {
		return variableCount;
	}
		
	public int findObservationRowCount( 
	        final String _directory, final String _fileName ) throws Exception {
	    
	    int observationRowCountInFile = 0;
	    File dataFile = new File(_directory, _fileName);
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		String itemDelimiter = BANJO.OBSERVATIONSDELIMITER;
		StringTokenizer tokenizer;
		
		try {
		
			if (!dataFile.exists()) {
			    
				throw new BanjoException( 
				        BANJO.ERROR_MISSING_OBSERVATIONSFILE, 
				        "\n *** (Observations.LoadDataFile) " +
				        "Cannot find the file: '" 
				        + _fileName + "' in directory '" + _directory + "'." );
			}
						
			// Load each line 1 by 1:
			bufferedReader = new BufferedReader(
			        new FileReader(_directory + "/" + _fileName));
						
			// Now load the data
			for (;;) {
				
				String line = bufferedReader.readLine();
				if ( line == null ) break;
				
				tokenizer = 
				    new StringTokenizer( line, itemDelimiter );

				int observedVarCount = tokenizer.countTokens();
				if ( observedVarCount > 0 && ! ( line.startsWith( "#" ) ) ) {
				
				    observationRowCountInFile++;
				}
			}
		}
		catch (IOException e) {
			   
		    throw new Exception( e );
		}		
		catch (BanjoException e) {

			throw new BanjoException( e );
		}		
		finally {
			try { 
								
				if (fileReader != null ) fileReader.close();
				if (bufferedReader != null ) bufferedReader.close();
			} 
			catch( IOException e ) {};
			
		}
	    
	    return observationRowCountInFile;
	}
		
	public String getValueCountList() {
		
		StringBuffer valueList = new StringBuffer(
		        BANJO.BUFFERLENGTH_STRUCTURE );
		valueList.append( "Value counts:\n" );
		
		for (int i=0; i< getVariableCount(); i++) {
			valueList.append( i );
			valueList.append( ": " );
			valueList.append( this.maxValueCount[i] );
			valueList.append( "\n" );
		}
		
		return valueList.toString();
	}
    /**
     * @return Returns the observationCount.
     */
    public int getObservationCount() {
        return observationCount;
    }
    

	public void loadObservationsFile(
	        final String _directory, final String _fileName ) 
			throws Exception {
		
	    // 9/14/2005 hjs	1.0.4	Remove discretization code, to properly
	    //							discretize data across multiple observation files
	    
		// For converting char to int for our decimal observation values:
		final int CHAROFFSET = 48;
		
		File dataFile = new File(_directory, _fileName);
		FileReader fileReader = null;
		BufferedReader bufferedReader = null;
		StringTokenizer tokenizer;
		String itemDelimiter = BANJO.OBSERVATIONSDELIMITER;
				
		try {
		
			if (!dataFile.exists()) {
			    
				throw new BanjoException( 
				        BANJO.ERROR_MISSING_OBSERVATIONSFILE, 
				        "\n *** (Observations.LoadDataFile) " +
				        "Cannot find the file: '" 
				        + _fileName + "' in directory '" + _directory + "'." );
			}
			
			int length;		
			int i;
			int tokenCount;
			final int varCount = this.getVariableCount();
			int observedVarCount;
			final int obsCount = this.getObservationRowCount();
			String currentObservationValue;
		    double dblCurrentObsValue;
		    Double tmpDbl;
		    int tmpInt;
		    
			SortedMap[] originalValuesMap = new SortedMap[varCount];
			for ( int z=0; z<varCount; z++ )
			    originalValuesMap[z] = new TreeMap();
			
			// For temp. output only:
			SortedMap[] tmpOriginalValuesMap = new SortedMap[varCount];
			for ( int z=0; z<varCount; z++ )
			    tmpOriginalValuesMap[z] = new TreeMap();

			String strDiscretizationChoice = 
			    processData.getValidatedProcessParameter( 
			        BANJO.DATA_DEFAULTDISCRETIZATIONCHOICE );
			int defaultDiscretizationPoints = Integer.parseInt(  
					    processData.getValidatedProcessParameter( 
						BANJO.DATA_DEFAULTDISCRETIZATIONPOINTS ) );
			
			if ( defaultDiscretizationPoints > BANJO.CONFIG_MAXVALUECOUNT ) {
                
                throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
	                    "The number of points ('" + defaultDiscretizationPoints +
	                    "') specified in the discretization exception '" + 
	                    strDiscretizationChoice + defaultDiscretizationPoints +
	                    "'\ncannot exceed Banjo's restriction " +
	                    "(via configuration) on " +
	                    "the max. number of values \n" +
	                    "that a variable can have ('" +
	                    BANJO.CONFIG_MAXVALUECOUNT +
	                    "')." );
            }
			
			String strDiscretizationExceptions = 
			    processData.getValidatedProcessParameter( 
			        BANJO.SETTING_DISCRETIZATIONEXCEPTIONS );
			
			int itemCount = 0;
			StringTokenizer itemTokenizer;
		    boolean discretizationFlag = false;
			String[] discretizationType = new String[varCount];
			int[] discretizationPoints = new int[varCount];
			int[] intervals = new int[varCount];
			

			// ----------------------------------------------
			// Set up the optional discretization of the data
			// ----------------------------------------------
			
			// Part 1: Apply the discretization policy
			for ( int item=0; item<varCount; item++ ) {
		    	
			    discretizationType[ item ] = strDiscretizationChoice;
			    discretizationPoints[ item ] = defaultDiscretizationPoints;
				intervals[ item ] = defaultDiscretizationPoints - 1;	
			}
			
			if ( !strDiscretizationChoice.equals( BANJO.UI_DISCRETIZATIONNONE )) {
			    
		        discretizationFlag = true;
		    }
			
			// Part 1: Apply the exceptions to the discretization policy
			if ( !strDiscretizationExceptions.equalsIgnoreCase( 
			        BANJO.BANJO_NOVALUESUPPLIED_STRING )) {
			    
			    StringTokenizer exceptionsTokenizer = new StringTokenizer( 
			            strDiscretizationExceptions, BANJO.EXCEPTIONSDELIMITER );
			    int exceptionsCount = exceptionsTokenizer.countTokens();
			    
			    for ( int exception=0; exception<exceptionsCount; exception++ ) {
			        
			        StringTokenizer exceptionItemTokenizer = new StringTokenizer(
			                exceptionsTokenizer.nextToken().trim(), 
				            BANJO.EXCEPTIONITEMDELIMITER );
			        
			        int varIndex = Integer.parseInt( 
			                exceptionItemTokenizer.nextToken().trim() ) - 
			                BANJO.CONFIG_DISCRETIZATIONSTARTINDEX;
			        String exceptionType = exceptionItemTokenizer.nextToken().trim();
			        
			        if ( varIndex >= varCount ) {
			            
			            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
			                    "Invalid variable index ('" + varIndex +
			                    "') specified." );
			        }
			        
			        if ( exceptionType.equalsIgnoreCase( BANJO.UI_DISCRETIZATIONNONE )) {
			            
			            discretizationType[ varIndex ] = BANJO.UI_DISCRETIZATIONNONE;
			        }
			        else {
			            
			            String strExceptionChoice = exceptionType.substring(
			                    0, exceptionType.length()-1 );
			            int exceptionPoints = Integer.parseInt( 
			                    exceptionType.substring( 
			                            exceptionType.length()-1, exceptionType.length()) );
			            
			            if ( exceptionPoints > BANJO.CONFIG_MAXVALUECOUNT ) {
			                
			                throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
				                    "The number of points ('" + exceptionPoints +
				                    "') specified in the discretization exception '" + 
				                    strExceptionChoice + exceptionPoints +
				                    "'\ncannot exceed Banjo's restriction " +
				                    "(via configuration) on " +
				                    "the max. number of values\n" +
				                    "that a variable can assume ('" +
				                    BANJO.CONFIG_MAXVALUECOUNT +
				                    "')." );
			            }
			            
			            discretizationType[ varIndex ] = strExceptionChoice;
					    discretizationPoints[ varIndex ] = exceptionPoints;
						intervals[ varIndex ] = exceptionPoints - 1;
						
						discretizationFlag = true;
			        }
			    }
			}
						
			// Set up the file loading:
			bufferedReader = new BufferedReader(
			        new FileReader(_directory + "/" + _fileName));
					
			// Now read the data
			i = 0;
			for (;;) {
				
				String line = bufferedReader.readLine();
				if ( line == null ) break;
				
				if ( i >= obsCount ) {
				    
				    // If there are more observation rows than there are indicated
				    // we could raise an error. Instead enable as special feature
			        // to allow testing of subsets of data.
				    
//				    if ( !BANJO.DEBUG ) {
//				        
//				        throw new BanjoException(...);
//				    }
				    
				    break;
				}
				
				// ---------------------------------------
				// Process the entries on the current line
				// ---------------------------------------
				tokenizer = 
			        new StringTokenizer( line, itemDelimiter );
				observedVarCount = tokenizer.countTokens();
				
				// this allows us to have a blank line or one that starts with #
				// without upsetting the observation loading
				if ( observedVarCount > 0 && ! ( line.startsWith( "#" ) ) ) {
					
					// Note: we allow that the observation file contains more observations
					// than there are specified variables (the extra values are ignored),
					// but we throw an exception when there are less observations than
					// variables
					//// if ( observedVarCount != varCount ) {
					if ( observedVarCount < varCount ) {
					    
					    throw new BanjoException( 
					            BANJO.ERROR_INVALID_VARCOUNTINOBSERVATIONS,
					            "\n (Observations:LoadData) Row '" + i + 
					            "' in observations file '" + _fileName +
					            "' contains " +
					            observedVarCount + 
					            " data points instead of the expected " + varCount + "." );
					}
					
					// Use varCount as loop conditions
					for ( int j=0; j<varCount; j++ ) {
					
					    currentObservationValue = tokenizer.nextToken();
					    rawObservationRowDataPoints[i][j] = currentObservationValue;
					    
					    if ( currentObservationValue.length() == 0 || 
					            currentObservationValue.equals( "" ) ) {
					        
					        // flag invalid (missing) observation value
					        throw new BanjoException( 
					                BANJO.ERROR_INVALID_VARCOUNTINOBSERVATIONS,
					                "Line '" + i + "' of the observations file is " +
					                "missing a value for variable '" + j + "'." );
					    }
					    else if ( currentObservationValue.length() > 1  ) {
					        
					        // Check if non-numeric. If so, tell the user that we
					        // only support numeric entries at this time
					        try {
					            
					            dblCurrentObsValue = 
					                Double.parseDouble( currentObservationValue );
					        }
							catch (Exception e) {
							    
							    throw new BanjoException( e,
							            BANJO.ERROR_INVALID_VARCOUNTINOBSERVATIONS,
						                "Line '" + i + "' of the observations file " +
						                "contains an invalid value ('" +
						                currentObservationValue +
						                "') for variable '" +
						                j + "'." );
							}
					    }
					    else {
					        
					        // again test against single-letter strings, since we
					        // only support numeric values right at this point
					        
					        try {
					            
					            dblCurrentObsValue = 
					                Integer.parseInt( currentObservationValue );
					        }
							catch (Exception e) {
							    
							    throw new BanjoException( e,
							            BANJO.ERROR_INVALID_VARCOUNTINOBSERVATIONS,
						                "Line '" + i + "' of the observations file " +
						                "contains an invalid value ('" +
						                currentObservationValue +
						                "') for variable '" +
						                j + "'." );
							}
					    }
					    
					    // When no discretization is specified, the data is to be used
					    // in current form
					    if ( discretizationType[j] == BANJO.UI_DISCRETIZATIONNONE ) {
					        				
					      	// When there's no discretization applied to a variable
					        // we need to validate the observation values
					        
					        try {
					            
					            tmpInt = Integer.parseInt( 
					                    currentObservationValue );

					            if ( tmpInt < BANJO.CONFIG_MAXVALUECOUNT ) {
					                
								    observationRowDataPoints[i][j] = 
								        Integer.parseInt( currentObservationValue );
					            }
					            else {
					                
					                throw new BanjoException( 
								            BANJO.ERROR_BADOBSERVATIONSDATA,
							                "Line '" + i + "' of the observations file " +
							                "contains a value ('" +
							                currentObservationValue +
							                "') for variable '" +
							                j + "' that exceeds the max. allowed value " +
							                "('" + (BANJO.CONFIG_MAXVALUECOUNT-1) +
							                "')." );
					            }
					        }
					        catch ( BanjoException e ) {
					        
					            throw new BanjoException( e );
					        }
					        catch ( Exception e ) {
					            
					            throw new BanjoException( e,
							            BANJO.ERROR_BADOBSERVATIONSDATA,
						                "Line '" + i + "' of the observations file " +
						                "contains an invalid value ('" +
						                currentObservationValue +
						                "') for variable '" +
						                j + "'." );
					        }
					    }
					}
					    
					i++;
				}
			}
		}
		catch (IOException e) {
		   
		    throw new Exception( e );
		}		
		catch (BanjoException e) {

			throw new BanjoException( e );
		}		
		finally {
			try { 
								
				if (fileReader != null ) fileReader.close();
				if (bufferedReader != null ) bufferedReader.close();
			} 
			catch( IOException e ) {};
		}
	}	
}

