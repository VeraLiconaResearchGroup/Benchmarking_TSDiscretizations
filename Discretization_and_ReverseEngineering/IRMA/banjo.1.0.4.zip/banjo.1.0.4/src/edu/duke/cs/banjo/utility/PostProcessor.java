/*
 * Created on Mar 29, 2005
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

import edu.duke.cs.banjo.bayesnet.*;

/**
 * 
 * 
 * <p><strong>Details:</strong> <br>
 *  
 * <p><strong>Change History:</strong> <br>
 * Created on Mar 29, 2005
 * 
 * @author hjs <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class PostProcessor {

	protected Settings settings;
	
	// Data that will be part of the underlying problem domain
	protected final int varCount;
	protected final int minMarkovLag;
	protected final int maxMarkovLag;
	
	public PostProcessor( Settings processData ) {

	    this.settings = processData;

	    varCount = Integer.parseInt( 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_VARCOUNT ) );
		minMarkovLag = Integer.parseInt( 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_MINMARKOVLAG ) );
		maxMarkovLag = Integer.parseInt( 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_MAXMARKOVLAG ) );
	}

	public StringBuffer composeDotGraph( 
	        BayesNetStructureI bayesNetStructure) throws Exception {

		StringBuffer dotStructure = new StringBuffer( 
		        BANJO.BUFFERLENGTH_STRUCTURE );
		

		EdgesAsMatrixWithCachedStatistics networkMatrix = 
		    new EdgesAsMatrixWithCachedStatistics(
		        varCount, minMarkovLag, maxMarkovLag);
		
		networkMatrix.reconstructMatrix( 
		        		bayesNetStructure.toString(), 
		                varCount, minMarkovLag, maxMarkovLag );
		
		dotStructure.append( "\ndigraph abstract { \n" );
		dotStructure.append( "\nlabel = \"Banjo Version " 
		        + BANJO.APPLICATION_VERSIONNUMBER );
		double highScore = Math.round( bayesNetStructure.getNetworkScore() * 100 );
		highScore = highScore / 100;
		dotStructure.append( "\\nHigh scoring network, score: " + 
		        highScore );
		dotStructure.append( "\\nProject: " + 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_PROJECT ) );
		dotStructure.append( "\\nUser: " + 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_USER ) );
		dotStructure.append( "\\nData set: " + 
		        settings.getValidatedProcessParameter( 
		                BANJO.SETTING_DATASET ) );
		dotStructure.append( "\\nNetworks searched: " + 
		        settings.getDynamicProcessParameter( 
		                BANJO.DATA_PROPOSEDNETWORKS ) );
		dotStructure.append( "\"; \nlabeljust=\"l\"; \n" );
		
		// Static BN case
		if ( maxMarkovLag == 0 ) {
			
			for ( int i=0; i< varCount; i++ ) {
		        for ( int j=0; j< varCount; j++ ) {
		            
		            // lag is always 0 for static bn's:
		            if ( networkMatrix.getEntry(i, j, 0) == 1 ) {
		                
		                dotStructure.append( "\n    " + j + "->" + i + ";");
		            }
		        }
			}
			
			dotStructure.append( "\n}\n" );
		}
		// When minMarkovLag == maxMarkovLag > 0, we "collapse" the nodes, since
		// it's obvious which are the parents and the children
		else {

		    // Special formatting for DBNs; this is based on Alex's code, but
		    // distinguishes between nodes of different lag
		    
		    if ( minMarkovLag == maxMarkovLag ) {
		    
		        // (Alex's code for minMarkovLag == maxMarkovLag)
				for ( int i=0; i< varCount; i++ ) {
					for ( int j=0; j< varCount; j++ ) {
						if (i==j) continue;
						boolean flag = false;
						for ( int k=minMarkovLag; k<= maxMarkovLag; k++ ) {
				            if (networkMatrix.getEntry(i, j, k) == 1) {
				            	flag = true;
				            	break;
				            }
						}
	
						if (flag == true) {
							dotStructure.append( "\n    " + j + "->" + i + ";");
						}
					}
				}
		    }
		    else {
		        
		        // General DBN case: indicate the lag explicitly. It would be
		        // nice to have special formatting that separates all nodes of
		        // the same lag ... TODO
		        for ( int i=0; i< varCount; i++ ) {
					for ( int j=0; j< varCount; j++ ) {
						if (i==j) continue;
						boolean flag = false;
						int k;
						for ( k=minMarkovLag; k<= maxMarkovLag; k++ ) {
				            if (networkMatrix.getEntry(i, j, k) == 1) {
				            	flag = true;
				            	break;
				            }
						}
	
						if (flag == true) {
							dotStructure.append(
							        "\n    \"(lag " + k + ") " + j + "\"->\"(lag 0) " + 
							        i + "\";");
						}
					}
				}        
		    }		        

			dotStructure.append( "\n}\n" );
		}
	
	    return dotStructure;
	}
}
