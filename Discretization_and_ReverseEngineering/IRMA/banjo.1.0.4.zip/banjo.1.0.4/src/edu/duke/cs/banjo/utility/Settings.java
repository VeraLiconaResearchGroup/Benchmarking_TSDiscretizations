/*
 * Created on May 17, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

import java.util.*;
import java.io.*;

/**
 * Manages the initial, validated, and dynamically updated parameters that are
 * used by the various search algorithms.
 *
 * <p><strong>Details:</strong> <br>
 * Contains the data shared by different object involved in the search process.
 * This includes the initial parameters (i.e., loaded via settings file, in 
 * raw, unvalidated form), their validated counterparts, and the dynamic parameters
 * (the ones that are changing over the life of a search).
 * <p>
 * By keeping this data outside of the core Searcher/Proposer/Evaluator/Decider 
 * objects, we simplify communication between our core objects, without
 * sacrificing performance.
 *   
 * <p><strong>Change History:</strong> <br>
 * Created on May 17, 2004
 * 
 * 9/14/2005 hjs	1.0.4 	Changes to properly handle discretization of multiple 
 * 							observation files
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 */
public class Settings {
	
    // Parameters that cannot be changed
	protected final Properties rawInitialProcessParameters;
	
	// Storage of the validated version of the initial process parameters
	// Note that the validation is handled in 2 steps. A basic, rather general
	// validation is applied within this class immediately after the data from the
	// settings file is loaded. A second, more targetted validation is applied
	// within the classes that consume the data values (i.e., different Searchers
	// may impose a different set of additional "rules" on a parameter's value)
	protected Properties validatedProcessParameters;
	
	// Parameters that change during the search
	protected Properties dynamicProcessParameters;
	
	// Results that were produced by the search
	protected TreeSet highScoreStructureSet;
	
	// General purpose storage container to be used by any object that has
	// access to processData
	protected Set generalProcessDataStorage;
	
	// Observational data associated with this bayesNetManager
	private final Observations observations;

	private final int varCount;
	private final int minMarkovLag;
	private final int maxMarkovLag;
	private final int observationCount;
	
	private class JZOOWildCardFilter implements FilenameFilter
	/*
	 * Copyright (c) 1998 Kevan Stannard. All Rights Reserved.
	 *
	 * Permission to use, copy, modify, and distribute this software
	 * and its documentation for NON-COMMERCIAL or COMMERCIAL purposes and
	 * without fee is hereby granted. 
	 * 
	 * Please note that this software comes with
	 * NO WARRANTY 
	 *
	 * BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY FOR THE PROGRAM, TO THE EXTENT PERMITTED
	 * BY APPLICABLE LAW. EXCEPT WHEN OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
	 * PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED OR IMPLIED, INCLUDING, BUT NOT
	 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. THE ENTIRE RISK AS
	 * TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU. SHOULD THE PROGRAM PROVE DEFECTIVE, YOU ASSUME
	 * THE COST OF ALL NECESSARY SERVICING, REPAIR OR CORRECTION. 
	 * 
	 * IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING WILL ANY COPYRIGHT HOLDER, OR ANY OTHER
	 * PARTY WHO MAY MODIFY AND/OR REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
	 * INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING OUT OF THE USE OR INABILITY TO USE
	 * THE PROGRAM (INCLUDING BUT NOT LIMITED TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED
	 * BY YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER PROGRAMS), EVEN IF SUCH HOLDER
	 * OR OTHER PARTY HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
	 */
	{
	    String wildPattern = null;
	    Vector pattern = new Vector();

	    final String FIND     = "find";
	    final String EXPECT   = "expect";
	    final String ANYTHING = "anything";
	    final String NOTHING  = "nothing";

	    public JZOOWildCardFilter(String wildString)
	    {
	        wildPattern = wildString;

	        // ensure wildString is lowercase for all testing

	        wildString = wildString.toLowerCase();

	        // remove duplicate asterisks

	        int i = wildString.indexOf("**");
	        while ( i >= 0 )
	        {
	            wildString = wildString.substring(0, i+1)
	                       + wildString.substring(i+2);

	            i = wildString.indexOf("**");
	        }

	        // parse the input string

	        StringTokenizer tokens = new StringTokenizer(wildString, "*", true);
	        String token = null;
	        while (tokens.hasMoreTokens())
	        {
	            token = tokens.nextToken();

	            if (token.equals("*"))
	            {
	                pattern.addElement(FIND);
	                if (tokens.hasMoreTokens())
	                {
	                    token = tokens.nextToken();
	                    pattern.addElement(token);
	                }
	                else
	                {
	                    pattern.addElement(ANYTHING);
	                }
	            }
	            else
	            {
	                pattern.addElement(EXPECT);
	                pattern.addElement(token);
	            }
	        }

	        if ( !token.equals("*") )
	        {
	            pattern.addElement(EXPECT);
	            pattern.addElement(NOTHING);
	        }

	    }


	    public boolean accept(File dir, String name)
	    {
	        // allow directories to match all patterns
	        // not sure if this is the best idea, but
	        // suits my needs for now

	        String path = dir.getPath();
	        if ( !path.endsWith("/") && !path.endsWith("\\") )
	        {
	            path += File.separator;
	        }
	        File tempFile = new File(path, name);

	        if ( tempFile.isDirectory() )
	        {
	            // BANJO: don't need any directory returned
	            return false;
	        }

	        // ensure name is lowercase for all testing

	        name = name.toLowerCase();

	        // start processing the pattern vector

	        boolean acceptName = true;

	        String command = null;
	        String param = null;

	        int currPos = 0;
	        int cmdPos = 0;

	        while ( cmdPos < pattern.size() )
	        {
	            command = (String) pattern.elementAt(cmdPos);
	            param = (String) pattern.elementAt(cmdPos + 1);

	            if ( command.equals(FIND) )
	            {
	                // if we are to find 'anything'
	                // then we are done
	                   
	                if ( param.equals(ANYTHING) )
	                {
	                    break;
	                }

	                // otherwise search for the param
	                // from the curr pos

	                int nextPos = name.indexOf(param, currPos);
	                if (nextPos >= 0)
	                {
	                    // found it

	                    currPos = nextPos + param.length();
	                }
	                else
	                {
	                    acceptName = false;
	                    break;
	                }
	            }
	            else
	            {
	                if ( command.equals(EXPECT) )
	                {
	                    // if we are to expect 'nothing'
	                    // then we MUST be at the end of the string

	                    if ( param.equals(NOTHING) )
	                    {
	                        if ( currPos != name.length() )
	                        {
	                            acceptName = false;
	                        }

	                        // since we expect nothing else,
	                        // we must finish here

	                        break;
	                    }
	                    else
	                    { 
	                        // otherwise, check if the expected string
	                        // is at our current position

	                        int nextPos = name.indexOf(param, currPos);
	                        if ( nextPos != currPos )
	                        {
	                            acceptName = false;
	                            break;
	                        }

	                        // if we've made it this far, then we've
	                        // found what we're looking for

	                        currPos += param.length();
	                    }
	                }
	            }

	            cmdPos += 2;
	        }

	        return acceptName;
	    }


	    public String toString()
	    {
	        return wildPattern;
	    }


	    public String toPattern()
	    {
	        StringBuffer out = new StringBuffer();

	        int i=0;
	        while (i<pattern.size())
	        {
	             out.append( "(" );
	             out.append( (String) pattern.elementAt(i) );
	             out.append( " " );
	             out.append( (String) pattern.elementAt(i+1) );
	             out.append( ") " );

	             i += 2;
	        }

	        return out.toString();
	    }
	}
	
	public Settings( final String[] applicationParameters ) throws Exception { 
	
	    // applicationParameters are the runtime parameters supplied by the user
	    // to the application that is the wrapper for executing the search (e.g.,
	    // the commandline application, or a gui)
	    
		String settingsFileName = new String();
		String settingsFileDirectory = new String();
		Properties loadedSettings;
		Properties passedInSettings = new Properties();
	    Set parameterSet;
		Iterator parameterIterator;
		String strNextProperty;
		String strPropertyValue;
		String applicationParameter;
		String strParameterName;
		String strParameterValue;
	    StringTokenizer tokenizer;
		int tokenCount;

		// hjs 4/12/05
		// Change in processing: allow user to specify any settings parameter
		// via item=value pair when running the application. 
		// We now first parse all specified parameters into a holding container,
		// because we need to process the settingsFile and settingsDirectory before
		// we can load a settings file.
		
		for ( int i=applicationParameters.length-1; i >= 0; i-- ) {

		    applicationParameter = applicationParameters[i];
		    
		    if ( applicationParameter.indexOf( "=" ) < 0 ) {
		        
		        // It seems to make no sense to let a parameter be specified without
		        // a value (even an empty one), so tell the user:
		        throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
			            "\n  (Settings) Cannot recognize the input parameter '" + 
			            applicationParameter + 
			            "'. Please use the 'item=value' format." );
		    }
		    else {
		    
				tokenizer = 
			        new StringTokenizer( applicationParameter, "=" );
				tokenCount = tokenizer.countTokens();
				
				// 9/8/2005 hjs	1.0.3	Add a little extra flexibility to the command 
				//						line parameter parsing, by allowing the use 
				//						of empty arguments (e.g., to "cancel" an 
				//						already specified value)
				if ( tokenCount > 2 ) {
				    
				    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
				            "\n (Settings) Cannot recognize the input parameter '" + 
				            applicationParameter + 
				            "'. Please use the 'item=value' format." );
				}
				
				strParameterName = tokenizer.nextToken();
	
				if ( tokenCount == 2 ) {
				    
				    strParameterValue = tokenizer.nextToken();
				}
				else {
				
				    strParameterValue = "";
				}			      
	
				passedInSettings.setProperty( 
				        strParameterName, strParameterValue );
		    }
		}

		settingsFileName = passedInSettings.getProperty( 
		        BANJO.VALIDATED_SETTINGSFILENAME );		
	    if ( settingsFileName == null || settingsFileName.length() < 1 ) {
	        settingsFileName = BANJO.DEFAULT_SETTINGSFILENAME;
	    }
	    
	    settingsFileDirectory = passedInSettings.getProperty( 
		        BANJO.VALIDATED_SETTINGSDIRECTORY );
		if ( settingsFileDirectory == null || settingsFileDirectory.length() < 1 ) {
		    settingsFileDirectory = "";
	    }

	    // Now load the settings. The file needs to adhere to Java's convention of
	    // listing properties and their values.
	    loadedSettings = FileUtil.loadSettings( 
	            settingsFileDirectory, settingsFileName );

	    // Now override the just loaded settings with the passedInSettings
	    parameterSet = passedInSettings.keySet();
		parameterIterator = parameterSet.iterator();
		while (parameterIterator.hasNext()) {
		    
		    strParameterName = (String) parameterIterator.next();
		    strParameterName = strParameterName.trim();

		    strParameterValue = passedInSettings.getProperty( strParameterName ).trim();
		    strParameterValue = StringUtil.removeTrailingComment( strParameterValue );
			
		    loadedSettings.setProperty( 
		            strParameterName, strParameterValue );
		}
	    
		// Create the objects for storing the intial, validated and dynamic parameters.
		// Note: the initial parameter set is simply the loaded "raw" set of data, and 
		// should only be used with caution. The validated data set contains the same
		// info, but has basic checks applied (a numeric property should not be an
		// alphanumneric string after all).
	    rawInitialProcessParameters = new Properties();
		validatedProcessParameters = new Properties();
		dynamicProcessParameters = new Properties();
		generalProcessDataStorage = new HashSet();
	    
	    // Store name and path of settings file
		validatedProcessParameters.setProperty(
		        BANJO.DATA_SPECIFIEDSETTINGSFILE,
		        settingsFileName );
		validatedProcessParameters.setProperty(
		        BANJO.DATA_SPECIFIEDSETTINGSFILEDIRECTORY,
		        settingsFileDirectory );
		
		// Load the "raw" initialSettings: avoid a simple reference to loadedSettings
		// to make rawInitialProcessParameters truly final
	    parameterSet = loadedSettings.keySet();
		parameterIterator = parameterSet.iterator();
		while (parameterIterator.hasNext()) {
		    
			strNextProperty = (String) parameterIterator.next();	
			strPropertyValue = loadedSettings.getProperty(strNextProperty).trim();
			
			// Special cleanup: remove any substring from the end of the property value
			// after a comment symbol is encountered. Then remove white space around
			// the property value.
			strPropertyValue = StringUtil.removeTrailingComment( strPropertyValue )
					.trim();
			
			rawInitialProcessParameters.setProperty( 
			        strNextProperty, strPropertyValue );
			
			// Note that by also assigning properties and values to the 
			// validatedParameters, we rely on the validateParameters() method on
			// proper (and complete) validation
			validatedProcessParameters.setProperty( 
			        strNextProperty, strPropertyValue );
		}
		
		validateSettings();
		
		// ------------------------
		// Process the observations
		// ------------------------

		String strInputDirectory = getValidatedProcessParameter( 
		        BANJO.SETTING_INPUTDIRECTORY );
		File inputDirectory = new File( strInputDirectory );
		if ( !inputDirectory.isDirectory()) {
		    
		    throw new BanjoException( BANJO.ERROR_INVALIDINPUTDIRECTORY,
		            "'"+ strInputDirectory + "' is not a valid (input) directory.");
		}
		//
		String strOutputDirectory = getValidatedProcessParameter( 
		        BANJO.SETTING_OUTPUTDIRECTORY );
		File outputDirectory = new File( strOutputDirectory );
		if ( !outputDirectory.isDirectory()) {
		    
		    throw new BanjoException( BANJO.ERROR_INVALIDOUTPUTDIRECTORY,
		            "'"+ strOutputDirectory + "' is not a valid (output) directory.");
		}
		//
		final String strObservationsFile = getValidatedProcessParameter( 
		        BANJO.SETTING_OBSERVATIONSFILE );
		

		// Store the names in an ordered way (even though this is only used
		// - and useful) for the case where the observations files are "related"
		String[] strArrayObservationFiles = null;
		final int obsFileCount;
		int obsFileIndex = 0;
		
	    // Process potentially multiple files
		StringTokenizer obsFileTokenizer = 
	        new StringTokenizer( strObservationsFile, BANJO.DEFAULT_LISTDELIMITER );

		String strNextFile;
		String[] strTempWildcardFiles;
		FilenameFilter filter;

		// Are wildcards used to describe the files?
		if ( strObservationsFile.indexOf( "*" ) < 0 ) {
		    
		    // Without wildcards we have as many files as there are tokens
		    obsFileCount = obsFileTokenizer.countTokens();
		    strArrayObservationFiles = new String[ obsFileCount  ];
		    
		    while ( obsFileTokenizer.hasMoreTokens() ) {
			    
			    // We simply add each file name to the array
			    strNextFile = obsFileTokenizer.nextToken().trim();
			    strArrayObservationFiles[ obsFileIndex ] = 
			        strNextFile.trim();
			    obsFileIndex++;
		    }
		}
		else {
		    
		    // Wildcard case: allow positive wildcards (files to add)
		    // and negative wildcards (files to omit)
			Set wildcardObservationFiles = new HashSet();
			Set omittedWildcardObservationFiles = new HashSet();
	    
			while ( obsFileTokenizer.hasMoreTokens() ) {
			    
			    // Note: we will validate the individual files (i.e., whether
			    // they exist) when we try to load the data
			    
			    strNextFile = obsFileTokenizer.nextToken().trim();
			    if ( strNextFile.charAt(0) == '-' ) {
					
			        filter = new JZOOWildCardFilter( 
			                strNextFile.substring(1).trim() );
			    }
			    else {
				
			        filter = new JZOOWildCardFilter( strNextFile );
			    }
		        
		        strTempWildcardFiles = inputDirectory.list( filter );
		        
		        if ( strTempWildcardFiles.length < 1 ) {
		            
		            throw new BanjoException( 
		                    BANJO.ERROR_MISSING_OBSERVATIONSFILE, 
		                    "\nThe wildcard specification '" + strNextFile +
		                    "' for the observation file(s) did not result in any " +
		                    "valid file." );
		        }

				String strSettingChoice = getValidatedProcessParameter( 
				        BANJO.SETTING_RELATEDOBSERVATIONSFILES );
				if ( strSettingChoice.equalsIgnoreCase( 
				        BANJO.UI_RELATEDOBSERVATIONSFILES_YES )) {
				    
				    throw new BanjoException( 
		                    BANJO.ERROR_GENERAL_USERINPUT, 
		                    "\nWhen observations files are specified " +
		                    "using wildcards, " +
		                    "\nthe 'related observations' setting cannot " +
		                    "be 'yes', because " +
		                    "\nthe Banjo application cannot apply any " +
		                    "ordering to the files!" );
				}
		        
			    // So we simply add each file name to the respective set
			    for ( int i=0; i < strTempWildcardFiles.length; i++ ) {
			        
			        if ( strNextFile.charAt(0) == '-') {
			            
			            omittedWildcardObservationFiles.add( strTempWildcardFiles[i] );
			        }
			        else {
			            
			            wildcardObservationFiles.add( strTempWildcardFiles[i] );
			        }
			    }
			}
		    		    
			if ( !wildcardObservationFiles.isEmpty() ) {
			    
			  	// Take away any files
				if ( !omittedWildcardObservationFiles.isEmpty() ) {
				
				    wildcardObservationFiles.removeAll( 
				            omittedWildcardObservationFiles );

				    String omittedWildcardFiles = new String();
					Iterator wildcardIterator = 
					    omittedWildcardObservationFiles.iterator();
					
					omittedWildcardFiles = (String) wildcardIterator.next();
					String strNextWildcardFile = null;
					while ( wildcardIterator.hasNext() ) {
					    
					    strNextWildcardFile = (String) wildcardIterator.next();
					    omittedWildcardFiles += "," + strNextWildcardFile;
					}
					
				    setValidatedProcessParameter( 
					        BANJO.DATA_OMITTEDWILDCARDOBSERVATIONSFILES, 
					        omittedWildcardFiles );
				}
			}
			
			// Finally, create the array with the observation files
			if ( !wildcardObservationFiles.isEmpty() ) {

				obsFileCount = wildcardObservationFiles.size();
				strArrayObservationFiles = new String[ 
				         wildcardObservationFiles.size() ];
			    String wildcardFiles = new String();
				Iterator wildcardIterator = wildcardObservationFiles.iterator();
				
				wildcardFiles = (String) wildcardIterator.next();
				strArrayObservationFiles[0] = wildcardFiles;
				int fileIndex = 1;
				String strNextWildcardFile = null;
				while ( wildcardIterator.hasNext() ) {
				    
				    strNextWildcardFile = (String) wildcardIterator.next();
				    wildcardFiles += "," + strNextWildcardFile;
				    strArrayObservationFiles[fileIndex] = strNextWildcardFile;
				    fileIndex++;
				}
			    setValidatedProcessParameter( 
				        BANJO.DATA_WILDCARDOBSERVATIONSFILES, wildcardFiles );
			}
			else {
			    
			    // No valid files found: can't continue
			    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT, 
			            "The input for the observations file setting (=" +
			            strObservationsFile + ") did not yield any usuable file." );
			}
		}

		// -------------------------
		// Load the observation data
		// -------------------------
		varCount = Integer.parseInt( getValidatedProcessParameter(
		        BANJO.SETTING_VARCOUNT ) );
		
	    String strObservationCount = getValidatedProcessParameter(
		        BANJO.SETTING_OBSERVATIONCOUNT );
				
		minMarkovLag = Integer.parseInt( getValidatedProcessParameter(
		        BANJO.SETTING_MINMARKOVLAG) );
		
		maxMarkovLag = Integer.parseInt( getValidatedProcessParameter(
		        BANJO.SETTING_MAXMARKOVLAG) );

		

	    // 1.0.4 Need to validate the discretiztion parameters here:
		
	    String strTmpValidationVar;
	    double dblTmpValidationVar;
	    int intTmpValidationVar;
	    String settingToValidate = new String();
        String settingDataType = new String();
		Set validValues = new HashSet();

	    // Validate the discretization parameters
	    // Part 1: The discretization policy
	    settingToValidate = "discretization policy";
	    settingDataType = "discretizationPolicy";
	    validValues.clear();
	    validValues.add( BANJO.UI_DISCRETIZATIONBYQUANTILE );
	    validValues.add( BANJO.UI_DISCRETIZATIONBYINTERVAL );
	    // Don't specify the BANJO.UI_DISCRETIZATIONNONE choice, because
	    // it is handled separately
	    validateOptionalSetting( BANJO.SETTING_DISCRETIZATIONPOLICY,
	            settingToValidate, settingDataType,
	            BANJO.UI_DISCRETIZATIONNONE,
	            validValues, 
	            BANJO.ERROR_INVALID_DISCRETIZATION );

	    // Part 2: Exceptions to the discretization policy
	    settingToValidate = "discretization exceptions";
	    settingDataType = "discretizationExceptions";
	    validValues.clear();
	    validValues.add( BANJO.UI_DISCRETIZATIONBYQUANTILE );
	    validValues.add( BANJO.UI_DISCRETIZATIONBYINTERVAL );
	    validValues.add( BANJO.UI_DISCRETIZATIONNONE );
	    validateOptionalSetting( BANJO.SETTING_DISCRETIZATIONEXCEPTIONS,
	            settingToValidate, settingDataType,
	            null,
	            validValues, 
	            BANJO.ERROR_INVALID_DISCRETIZATION );
	    
		Set observationsSet =  new HashSet( obsFileCount );
		Observations[] observationsArray = new Observations[ obsFileCount ];
		
		Observations obsFromFile;
		Observations tmpObs = new Observations( 
		        maxMarkovLag+1, varCount, maxMarkovLag );
		String strFileToLoad = null;
		
		for ( int i = 0; i < obsFileCount; i++ ) {
		    		    
		    strFileToLoad = strArrayObservationFiles[i];
			obsFromFile = new Observations( 
			        tmpObs.findObservationRowCount( 
			                strInputDirectory, strFileToLoad ) - maxMarkovLag,
			        varCount, maxMarkovLag,
					strInputDirectory, strFileToLoad,
					this );

			if ( BANJO.DEBUG && BANJO.TRACE_STATISTICS) {
			    
				System.out.println( "Observation count for '" 
				        + strObservationsFile + "': " +
				        obsFromFile.findObservationRowCount( 
				                strInputDirectory, strFileToLoad ) );
			}
		
			observationsArray[i] = obsFromFile;
		}
	    
				
		// This only affects DBNs (i.e. maxMarkovLag > 0) 
		// with multiple observation files
		// Note: boolRelatedObservations must be false (only supported case!)
		final boolean boolRelatedObservations = false;
//		if ( this.getValidatedProcessParameter( 
//		        BANJO.SETTING_RELATEDOBSERVATIONSFILES ).equalsIgnoreCase(
//		                BANJO.UI_RELATEDOBSERVATIONSFILES_YES ) ) {
//		    
//		    boolRelatedObservations  = true;
//		}
		               
		// Now combine the observations from the individual files
		observations = new Observations( 
		        observationsArray, varCount, maxMarkovLag, 
		        boolRelatedObservations,
		        this );
		
		// If the user has supplied us with the number of observations, then we
		// compare, otherwise we get it from the observations object
		if ( strObservationCount == null || strObservationCount.equals( "" ) ) {
		    
		    observationCount = observations.getObservationCount();
		}
		else {

		    observationCount = Integer.parseInt( strObservationCount );
		    
			// Now check the user-supplied observation count against the combined
			// total of rows of data supplied in the observation file(s)
			if ( observations.getObservationCount() != observationCount ) {
			    
			    throw new BanjoException( BANJO.ERROR_INCONSISTENTOBSCOUNTS, 
			            "\nThe observation count supplied in the settings file (=" + 
			            observationCount + 
			            ") does not match " +
			            "\nthe effective number of observations " +
			            " supplied in the observation file(s) (=" +
			            observations.getObservationCount() + "). " +
	            		"\nNote: the number of observations is equal to " +
	            		"the number of rows in the file " +
	            		"\nminus the Markov lag (single file only; " +
	            		"for multiple files one needs to consider " +
	            		"\nalso whether the observations are 'related')." );
			}
		}
		
		// Store the (provided) observation count for use by the search components
	    setValidatedProcessParameter( 
	            BANJO.SETTING_OBSERVATIONCOUNT, 
	            ( new Integer( observationCount )).toString() );
	    
		// Store the observed observation count and row count for display to the user
	    setValidatedProcessParameter( 
	            BANJO.DATA_OBSERVEDOBSERVATIONCOUNT, 
	            ( new Integer( observationCount )).toString() );
	    //
	    setValidatedProcessParameter( 
	            BANJO.DATA_OBSERVEDOBSERVATIONROWCOUNT, 
	            ( new Integer( observations.getObservationRowCount() )).toString() );
	}
		
	public void validateSettings() throws Exception {
		
	    String strTmpValidationVar;
	    double dblTmpValidationVar;
	    int intTmpValidationVar;
	    String settingToValidate = new String();
        String settingDataType = new String();
		Set validValues = new HashSet();
		
	    // NOTE: This validation is performed at a very basic level, i.e., we can only
	    // check for existence of a parameter's value, and its data type. We also 
	    // validate the general rules that apply to all algorithms, e.g., the min.
	    // Markov lag needs to be smaller than the max. Markov lag, etc.
	    //
	    // Any actual "business rule" validation has to happen within the core
	    // classes, such as searcher, evaluator, etc.
	    	    
		try {
		    
		  	// Validate the 'Variable Count'
		    settingToValidate = "variable count (varCount)";
		    settingDataType = "Integer";
		    validateMandatorySetting( BANJO.SETTING_VARCOUNT, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_VARCOUNT );
		    		    
		  	// Validate the 'Max. Markov lag '
		    settingToValidate = "max. Markov lag";
		    settingDataType = "Integer";
		    validateMandatorySetting( BANJO.SETTING_MAXMARKOVLAG, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_MAXMARKOVLAG );
		    
		  	// Validate the 'Min. Markov lag '
		    settingToValidate = "min. Markov lag";
		    settingDataType = "Integer";
		    validateMandatorySetting( BANJO.SETTING_MINMARKOVLAG, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_MINMARKOVLAG );
		    
		    // Special setting-specific validation:
		    int intTmpValidationVar2;
		    intTmpValidationVar = Integer.parseInt( 
		            validatedProcessParameters.getProperty(
	                BANJO.SETTING_MINMARKOVLAG ));
		    intTmpValidationVar2 = Integer.parseInt( 
		            validatedProcessParameters.getProperty(
	                BANJO.SETTING_MAXMARKOVLAG ));
			if ( settingToValidate == "min. Markov lag" && 
			        intTmpValidationVar > intTmpValidationVar2 ) {
				
			    throw new BanjoException( BANJO.ERROR_INVALID_ESSVALUE,
			            "The 'min. Markov lag' needs to be less or equal" +
			            " than the 'max. Markov lag'.");
			}

		  	// Validate the 'Equivalent Sample Size'
		    settingToValidate = "equivalent sample size";
		    settingDataType = "Double";
		    validateMandatorySetting( BANJO.SETTING_EQUIVALENTSAMPLESIZE, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_EQUIVALENTSAMPLESIZE );
		    // Special setting-specific validation:
		    dblTmpValidationVar = Double.parseDouble( 
		            validatedProcessParameters.getProperty(
	                BANJO.SETTING_EQUIVALENTSAMPLESIZE ));
			if ( settingToValidate == settingToValidate && 
			        dblTmpValidationVar <= 0 ) {
				
			    throw new BanjoException( BANJO.ERROR_INVALID_ESSVALUE,
			            "The value for the setting '" +
			            settingToValidate + "' needs to be greater than 0.");
			}
					    			
		  	// Validate the 'Max. Parent Count'
		    settingToValidate = "max. parent count";
		    settingDataType = "Integer";
		    validateMandatorySetting( BANJO.SETTING_MAXPARENTCOUNT, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_MAXPARENTCOUNT );
		    // Special setting-specific validation:
		    int tmpMaxParentCount = Integer.parseInt( 
		            validatedProcessParameters.getProperty(
	                BANJO.SETTING_MAXPARENTCOUNT ));
			// Need to make sure that the max parent count is at least 1 larger
			// than the dbn identiy lag count
			String strDbnMandatoryIdentityLags = validatedProcessParameters.getProperty(
	                BANJO.SETTING_DBNMANDATORYIDENTITYLAGS );
			StringTokenizer dbnMandatoryLags = new StringTokenizer( 
			        strDbnMandatoryIdentityLags, BANJO.DEFAULT_LISTDELIMITER );
		    // Check first that it makes sense to have dbnMandatoryLags
			int tmpMaxMarkovLag = Integer.parseInt( 
		            validatedProcessParameters.getProperty(
			                BANJO.SETTING_MAXMARKOVLAG ));
		    if ( tmpMaxMarkovLag < 1 && dbnMandatoryLags.countTokens() > 0 ) {
		        
		      	// Can't have dbnMandatoryLags for static bayesnet
			    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT, 
		            "The DbnMandatoryIdentityLags cannot be specified " +
		            "when the max. Markov Lag is 0." );
		    }		    
		    // Now check that dbnMandatoryLags makes sense (detailed validation
		    // is done in the BayesNetManager class when the data is being used)
			if ( tmpMaxParentCount <= dbnMandatoryLags.countTokens() ) {
			    
			    // MaxParentCount not large enough
			    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT, 
		            "The max. parent count ('" + tmpMaxParentCount +
		            "') needs to be larger than the number of" +
		            " mandatory parents specified in DbnMandatoryIdentityLags ('" +
		            dbnMandatoryLags.countTokens() + "')." );
			}
		    // Final check: are we within general params?		    
			if ( tmpMaxParentCount > BANJO.DEFAULT_MAXPARENTCOUNT ) {
				
			    validatedProcessParameters.setProperty( 
			            BANJO.SETTING_MAXPARENTCOUNT, 
			            Integer.toString( BANJO.DEFAULT_MAXPARENTCOUNT ));
			}

			// TODO: Add code that only checks for this value when it is really needed
			// Validate the max. parent count for restarting with a new network
		    settingToValidate = "max. parent count for restart";
		    settingDataType = "Integer";
		    validateMandatorySetting( BANJO.SETTING_MAXPARENTCOUNTFORRESTART, 
		            settingToValidate, settingDataType,
		            null, BANJO.ERROR_MISSING_MAXPARENTCOUNTFORRESTART );
		    // Special setting-specific validation:
		    intTmpValidationVar = Integer.parseInt( 
		            validatedProcessParameters.getProperty(
	                BANJO.SETTING_MAXPARENTCOUNTFORRESTART ));
			if ( intTmpValidationVar > tmpMaxParentCount ) {
				
			    validatedProcessParameters.setProperty( 
			            BANJO.SETTING_MAXPARENTCOUNTFORRESTART, 
			            Integer.toString( tmpMaxParentCount ));
			}
			
		    // Validate the 'Max. restarts'
		    settingToValidate = "max. restarts";
		    settingDataType = "Long";
		    validateOptionalSetting( BANJO.SETTING_MAXRESTARTS, 
		            settingToValidate, settingDataType,
		            new Long( BANJO.BANJO_NOVALUESUPPLIED_NUMBER ), 
		            null, BANJO.ERROR_GENERAL_USERINPUT );
			
		    // Validate the 'Max. proposed networks'
		    settingToValidate = "max. proposed networks";
		    settingDataType = "Long";
		    validateOptionalSetting( BANJO.SETTING_MAXPROPOSEDNETWORKS, 
		            settingToValidate, settingDataType,
		            new Long( BANJO.BANJO_NOVALUESUPPLIED_NUMBER ), 
		            null, BANJO.ERROR_GENERAL_USERINPUT );

			// Deprecated:
		  	// Validate the 'Observation Count'
		    settingToValidate = "observation count";
		    settingDataType = "Integer";
		    validateOptionalSetting( BANJO.SETTING_OBSERVATIONCOUNT, 
		            settingToValidate, settingDataType,
		            null, null, BANJO.ERROR_INVALID_OBSERVATIONCOUNT );

		  	// Validate the 'Observation File'
		    settingToValidate = "observations file";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.BANJO_FREEFORMINPUT );
		    validateMandatorySetting( BANJO.SETTING_OBSERVATIONSFILE, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_MISSING_OBSERVATIONSFILE );
		    
		    // Validate the 'Input Directory'
		    settingToValidate = "input directory";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.BANJO_FREEFORMINPUT );
		    validateMandatorySetting( BANJO.SETTING_INPUTDIRECTORY, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALIDINPUTDIRECTORY );
		    
		    // Validate the 'Output Directory'
		    settingToValidate = "output directory";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.BANJO_FREEFORMINPUT );
		    validateMandatorySetting( BANJO.SETTING_OUTPUTDIRECTORY, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALIDOUTPUTDIRECTORY );
		    
		    // Validate the searcher
		    settingToValidate = "searcher choice";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_DEFAULT );
		    validValues.add( BANJO.UI_SEARCH_GREEDY );
		    validValues.add( BANJO.UI_SEARCH_SIMANNEAL );
		    validateMandatorySetting( BANJO.SETTING_SEARCHERCHOICE, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALID_SEARCHER );
		    
		    // Validate the proposer
		    settingToValidate = "proposer choice";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_DEFAULT );
		    validValues.add( BANJO.UI_PROP_RANDOMLOCALMOVE );
		    validValues.add( BANJO.UI_PROP_ALLLOCALMOVES );
		    validValues.add( BANJO.UI_PROP_EXHAUSTIVEMOVES );
		    validateMandatorySetting( BANJO.SETTING_PROPOSERCHOICE, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALID_PROPOSER );
		    
		    // Validate the evaluator
		    settingToValidate = "evaluator choice";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_DEFAULT );
		    validValues.add( BANJO.UI_EVAL_BDE );
		    validateMandatorySetting( BANJO.SETTING_EVALUATORCHOICE, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALID_EVALUATOR );
		    
		    // Validate the decider
		    settingToValidate = "decider choice";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_DEFAULT );
		    validValues.add( BANJO.UI_DEC_GREEDY );
		    validValues.add( BANJO.UI_DEC_METROPOLIS );
		    validateMandatorySetting( BANJO.SETTING_DECIDERCHOICE, 
		            settingToValidate, settingDataType,
		            validValues, BANJO.ERROR_INVALID_DECIDER );
		    
		    // Validate the statistics choice - future feature		    
		    this.setValidatedProcessParameter( BANJO.SETTING_STATISTICSCHOICE,
		            BANJO.UI_RECORDER_STANDARD );
		    
		    // 9/15/2005 hjs 1.0.4 Move to constructor so that we have access
		    // to the discretization values earlier (needed for revamped
		    // processing of observation files)
//		    // Validate the discretization parameters
//		    // Part 1: The discretization policy
//		    settingToValidate = "discretization policy";
//		    settingDataType = "discretizationPolicy";
//		    validValues.clear();
//		    validValues.add( BANJO.UI_DISCRETIZATIONBYQUANTILE );
//		    validValues.add( BANJO.UI_DISCRETIZATIONBYINTERVAL );
//		    // Don't specify the BANJO.UI_DISCRETIZATIONNONE choice, because
//		    // it is handled separately
//		    validateOptionalSetting( BANJO.SETTING_DISCRETIZATIONPOLICY,
//		            settingToValidate, settingDataType,
//		            BANJO.UI_DISCRETIZATIONNONE,
//		            validValues, 
//		            BANJO.ERROR_INVALID_DISCRETIZATION );
//
//		    // Part 2: Exceptions to the discretization policy
//		    settingToValidate = "discretization exceptions";
//		    settingDataType = "discretizationExceptions";
//		    validValues.clear();
//		    validValues.add( BANJO.UI_DISCRETIZATIONBYQUANTILE );
//		    validValues.add( BANJO.UI_DISCRETIZATIONBYINTERVAL );
//		    validValues.add( BANJO.UI_DISCRETIZATIONNONE );
//		    validateOptionalSetting( BANJO.SETTING_DISCRETIZATIONEXCEPTIONS,
//		            settingToValidate, settingDataType,
//		            null,
//		            validValues, 
//		            BANJO.ERROR_INVALID_DISCRETIZATION );

		    // Data report
		    settingToValidate = "data report";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_DATAREPORT_YES );
		    validValues.add( BANJO.UI_DATAREPORT_NO );
		    validateOptionalSetting( BANJO.SETTING_DATAREPORT,
		            settingToValidate, settingDataType,
		            BANJO.UI_DATAREPORT_YES,
		            validValues, 
		            BANJO.ERROR_GENERAL_USERINPUT );
		    		        
//		    // Post-processing options ---- WORK IN PROGRESS (TODO)
//		    // -----------------------
//		    // Compute influence scores
//		    settingToValidate = "compute influence scores";
//		    settingDataType = "";
//		    validValues.clear();
//		    validValues.add( BANJO.UI_COMPUTEINFLUENCESCORES_YES );
//		    validValues.add( BANJO.UI_COMPUTEINFLUENCESCORES_NO );
//		    validateOptionalSetting( BANJO.SETTING_INFLUENCESCORES,
//		            settingToValidate, settingDataType,
//		            BANJO.UI_CREATEDOTOUTPUT_YES,
//		            validValues, 
//		            BANJO.ERROR_GENERAL_USERINPUT );
//
//		    // Create dot output
//		    settingToValidate = "create dot output";
//		    settingDataType = "";
//		    validValues.clear();
//		    validValues.add( BANJO.UI_CREATEDOTOUTPUT_YES );
//		    validValues.add( BANJO.UI_CREATEDOTOUTPUT_NO );
//		    validateOptionalSetting( BANJO.SETTING_DOTOUTPUT,
//		            settingToValidate, settingDataType,
//		            BANJO.UI_COMPUTEINFLUENCESCORES_YES,
//		            validValues, 
//		            BANJO.ERROR_GENERAL_USERINPUT );
		    
		    // ------------------------------------------------
		    // DO NOT USE this parameter in the settings file!!
		    // Validate the 'Related Observations'
		    settingToValidate = "are observations related?";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_RELATEDOBSERVATIONSFILES_YES );
		    validValues.add( BANJO.UI_RELATEDOBSERVATIONSFILES_NO );
		    validateOptionalSetting( BANJO.SETTING_RELATEDOBSERVATIONSFILES, 
		            settingToValidate, settingDataType,
		            BANJO.UI_RELATEDOBSERVATIONSFILES_NO,
		            validValues, BANJO.ERROR_GENERAL_USERINPUT );		    
			                    
		  	// Validate the 'pre-compute LogGamma'
		    settingToValidate = "pre-compute logGamma";
		    settingDataType = "String";
		    validValues.clear();
		    validValues.add( BANJO.UI_PRECOMPUTE_YES );
		    validValues.add( BANJO.UI_PRECOMPUTE_NO );
		    validateOptionalSetting( BANJO.SETTING_PRECOMPUTE, 
		            settingToValidate, settingDataType,
		            BANJO.UI_PRECOMPUTE_YES,
		            validValues, BANJO.ERROR_GENERAL_USERINPUT );
		    
		  	// Validate the 'number of intermediate saves'
		    settingToValidate = "number of intermediate saves";
		    settingDataType = "Integer";
		    validateOptionalSetting( BANJO.SETTING_NUMBEROFINTERMEDIATESAVES, 
		            settingToValidate, settingDataType,
		            new Integer( BANJO.DEFAULT_NUMBEROFINTERMEDIATESAVES ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		  	// Validate the 'number of intermediate progress reports'
		    settingToValidate = "number of intermediate progress reports";
		    settingDataType = "Integer";
		    validateOptionalSetting( BANJO.SETTING_NUMBEROFPROGRESSREPORTS, 
		            settingToValidate, settingDataType,
		            new Integer( BANJO.DEFAULT_NUMBEROFPROGRESSREPORTS ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		  	// Validate the 'progress report interval'
		    settingToValidate = "progress report interval";
		    settingDataType = "Integer";
		    validateOptionalSetting( BANJO.SETTING_PROGRESSREPORTINTERVAL, 
		            settingToValidate, settingDataType,
		            new Integer( BANJO.DEFAULT_FEEDBACKINTERVAL ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    // Searcher-specific settings: Sim. Annealing
		    settingToValidate = "max. accepted networks before cooling";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MAXACCEPTEDNETWORKSBEFORECOOLING,
		            settingToValidate, settingDataType,
		            new Long( BANJO.DEFAULT_MAXACCEPTEDNETWORKSBEFORECOOLING ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    settingToValidate = "max. search iterations before cooling";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MAXPROPOSEDNETWORKSBEFORECOOLING,
		            settingToValidate, settingDataType,
		            new Long( BANJO.DEFAULT_MAXPROPOSEDNETWORKSBEFORECOOLING ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    settingToValidate = "min. accepted networks before reannealing";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MINACCEPTEDNETWORKSBEFOREREANNEALING,
		            settingToValidate, settingDataType,
		            new Long( BANJO.DEFAULT_MINACCEPTEDNETWORKSBEFOREREANNEALING ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    settingToValidate = "initial temperature";
		    settingDataType = "Double";
		    validateOptionalSetting( 
		            BANJO.SETTING_INITIALTEMPERATURE,
		            settingToValidate, settingDataType,
		            new Long( BANJO.DEFAULT_INITIALTEMPERATURE ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    settingToValidate = "reannealing temperature";
		    settingDataType = "Double";
		    validateOptionalSetting( 
		            BANJO.SETTING_REANNEALINGTEMPERATURE,
		            settingToValidate, settingDataType,
		            new Long( BANJO.DEFAULT_REANNEALINGTEMPERATURE ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    settingToValidate = "cooling factor";
		    settingDataType = "Double";
		    validateOptionalSetting( 
		            BANJO.SETTING_COOLINGFACTOR,
		            settingToValidate, settingDataType,
		            new Double( BANJO.DEFAULT_COOLINGFACTOR ),
		            null, BANJO.ERROR_GENERAL_USERINPUT );
		    
		    // Searcher-specific settings: Greedy
		    settingToValidate = "min. proposed networks after high score";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MINPROPOSEDNETWORKSAFTERHIGHSCORE,
		            settingToValidate, settingDataType,
		            null,
		            null, BANJO.ERROR_GENERAL_USERINPUT );

		    settingToValidate = "min. proposed networks before restart";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MINPROPOSEDNETWORKSBEFORERESTART,
		            settingToValidate, settingDataType,
		            null,
		            null, BANJO.ERROR_GENERAL_USERINPUT );

		    settingToValidate = "max. proposed networks before restart";
		    settingDataType = "Long";
		    validateOptionalSetting( 
		            BANJO.SETTING_MAXPROPOSEDNETWORKSBEFORERESTART,
		            settingToValidate, settingDataType,
		            null,
		            null, BANJO.ERROR_GENERAL_USERINPUT ); 
		    
		    // Validate the 'Search Time'
		    settingToValidate = "search time";
		    settingDataType = "Integer or D:H:M:S";
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            BANJO.SETTING_MAXSEARCHTIME );
		    long searchTime;
		    if ( strTmpValidationVar.equals("") || strTmpValidationVar == null ) {
		        
		        // Use "-1" as indicator so that the rest of the search won't use
		        // the search time
		        searchTime = BANJO.BANJO_NOVALUESUPPLIED_NUMBER;
		        validatedProcessParameters.setProperty(
			            BANJO.SETTING_MAXSEARCHTIME,
			            Long.toString( searchTime ));
		    }
		    else {
			    
			    // first check if the value is a number
			    try {
			        
			        // Don't allow a negative number
			        searchTime = Math.abs( Long.parseLong( strTmpValidationVar ));
			        
			        if ( searchTime == 0 ) {
			            
			            validatedProcessParameters.setProperty(
					            BANJO.SETTING_MAXSEARCHTIME,
					            Integer.toString( BANJO.BANJO_NOVALUESUPPLIED_NUMBER ) );
			        }
			        else {
			            
				        // Adjust for milliseconds (i.e., the input is meant in seconds):
				        searchTime *=1000;
				        // Update the validated settings
				        validatedProcessParameters.setProperty(
					            BANJO.SETTING_MAXSEARCHTIME,
					            Long.toString( searchTime ));
			        }
			    }
			    catch ( Exception e ) {
			        // The input was not a number, so assume that it is in the
			        // prescribed "time format" d:h:m:s, and parse the individual
			        // components (we start from the left, and let the user omit
			        // any m and s values)
	
			        searchTime = 0;
			        int[] timeValues = new int[4];
			        for (int i = 0; i< timeValues.length; i++) timeValues[i] = 0;
			        // Convention: i=0 holds days, i=1 holds hours
			        // i=2 holds minutes, and i=3 holds seconds
			        
					StringTokenizer tokenizer;
					int tokenCount;
					tokenizer = 
				        new StringTokenizer( strTmpValidationVar, 
				                BANJO.DEFAULT_ITEMDELIMITER );
					tokenCount = tokenizer.countTokens();
	
					if ( tokenCount > 4 ) {
					    
					    throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
						        "If the 'max. time' is supplied in the 'd:h:m:s' format, " +
						        "it cannot have more than 4 values (supplied= '" +
						        strTmpValidationVar + "').");
					}
					
					
					for (int i=timeValues.length-tokenCount; i<timeValues.length; i++) {
					    
						try {
						    
						    // Again, "fix" any negative number entered by the user
						    timeValues[i] = Math.abs( Integer.parseInt( 
						            tokenizer.nextToken() ) );
						}		
						catch (Exception ex) {
							
						    // If the loaded value is not an integer, tell the user
							throw new BanjoException( ex, 
							        BANJO.ERROR_GENERAL_USERINPUT,
							        "The 'max. time' (=" +
							        strTmpValidationVar +
							        ") is not suppplied in a valid format.");
						}
					}
					searchTime = (((( timeValues[0] ) * 24 + 
					        timeValues[1] ) * 60 +
					        timeValues[2] ) * 60 +
					        timeValues[3] ) * 1000;		  
	
			        validatedProcessParameters.setProperty(
				            BANJO.SETTING_MAXSEARCHTIME,
				            Long.toString( searchTime ));
			    }		        
		    }
		}
		catch ( BanjoException e ) {
			
			throw new BanjoException( e );
		}
		catch ( Exception e ) {
			
		    // End user may not understand 'Double' and 'Long', so "translate"
		    if ( settingDataType.equalsIgnoreCase("Double")) settingDataType = "Real";
		    if ( settingDataType.equalsIgnoreCase("Long")) settingDataType = "Integer";
		    if ( settingDataType.equalsIgnoreCase("StringList")) 
		        settingDataType = "(comma separated) List of Strings";
		    
			throw new BanjoException( 
			        BANJO.ERROR_INVALID_INPUTDATATYPE,
			        "The value of the setting '" +
			        settingToValidate + "' needs to be of type '" +
					settingDataType + "'.");
		}
	}
	
	// Method to validate all mandatory input settings, a) for existence, and b) for
	// proper data type. If a setting is missing, the user is informed, and asked
	// to correct the input.
	private void validateMandatorySetting( String settingName,
	        String settingDescription,
	        String settingDataType, 
	        Object additionalInfo, 
	        int settingErrorLink ) throws Exception {
	    
	    // Streamlined function for handling the different types of validations
	    // (i.e., integer, double, etc)
	    
	    String strTmpValidationVar;
	    int intTmpValidationVar;
	    long longTmpValidationVar;
	    double dblTmpValidationVar;
	    
	    if ( settingDataType.equalsIgnoreCase("Integer")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( strTmpValidationVar == null || strTmpValidationVar.length() < 1 ) {
		        
				throw new BanjoException( settingErrorLink,
				        errorMessageFieldNotFound( 
				                settingDescription, settingName ) );
		    }
		    else {
		        
		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
			    intTmpValidationVar = Integer.parseInt( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("Long")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( strTmpValidationVar == null || strTmpValidationVar.length() < 1 ) {
		        
				throw new BanjoException( settingErrorLink,
				        errorMessageFieldNotFound( 
				                settingDescription, settingName ) );
		    }
		    else {

		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
		        longTmpValidationVar = Long.parseLong( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("Double")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( strTmpValidationVar == null || strTmpValidationVar.length() < 1 ) {
		        
				throw new BanjoException( settingErrorLink,
				        errorMessageFieldNotFound( 
				                settingDescription, settingName ) );
		    }
		    else {

		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
			    dblTmpValidationVar = Double.parseDouble( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("String")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( strTmpValidationVar == null || strTmpValidationVar.length() < 1 ) {
		        
				throw new BanjoException( settingErrorLink,
				        errorMessageFieldNotFound( 
				                settingDescription, settingName) );
		    }
		    else {
		        
		        // Check that value is in supplied set of valid values
		        if ( additionalInfo == null ) {
		            
		            // This ensures that all string input is validated against the set
		            // of possible values (any mandatory setting won't make sense if
		            // it can't supply such a set of values)
		            throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
		                    "\nThere are no valid values supplied for the setting '" +
		                    settingName +"'!" );
		        }
		        
		        try {
			        Set validValues = new HashSet();

			        validValues = (Set) additionalInfo;
			        if ( validValues.contains( strTmpValidationVar ) || 
			                ( validValues.contains( BANJO.BANJO_FREEFORMINPUT ) )) {
			            
			            validatedProcessParameters.setProperty( 
					            settingName, strTmpValidationVar );
			        }
			        else {
			            
			            throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
			                    "\nThe supplied value '" + strTmpValidationVar + 
			                    "' is not a valid option for setting '" + 
			                    settingName + "'." );
			        }
		        }
				catch ( BanjoException e) {
					
					throw new BanjoException( e );
				}
				catch ( Exception e ) {
									    
					throw new BanjoException( 
					        BANJO.ERROR_BANJO_DEV_INPUT,
					        "\nCould not validate the setting '" + 
					        settingName + "' - maybe the valid setting values were " +
					        "not supplied by the developer?");
				}
		    }
	    }
	}

	// Method for validating all optional input settings. If a field is missing, 
	// no action is taken. However, if the setting exists, then it is checked for 
	// the proper data type.
	// The defaultValueToAssign is an Object that needs to be equivalent to the basic
	// data type of settingDataType (e.g., Integer for int, etc). This lets us specify
	// a value that the rest of the program expects (e.g., maxRestarts is optional,  
	// but we need a non-null value)	
	private void validateOptionalSetting( String settingName,
	        String settingDescription,
	        String settingDataType, 
	        Object defaultValueToAssign, 
	        Object additionalInfo, 
	        int settingErrorLink ) throws Exception {
	
	    String strTmpValidationVar;
	    int intTmpValidationVar;
	    long longTmpValidationVar;
	    double dblTmpValidationVar;
	    String strClassName = "";
	        
	    if ( defaultValueToAssign != null ) {
	        
			Object classObj = defaultValueToAssign.getClass();
		    strClassName = new String( classObj.toString() );
			strClassName = strClassName.substring(strClassName.lastIndexOf(".")+1);
	    }

	    if ( settingDataType.equalsIgnoreCase("Integer")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( !( strTmpValidationVar == null || 
		            strTmpValidationVar.length() < 1 )) {

		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
			    intTmpValidationVar = Integer.parseInt( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
		    else if ( defaultValueToAssign != null ) {
		        if ( strClassName.equals( "Integer" ) ) { 
		        
			        validatedProcessParameters.setProperty( 
				            settingName, 
				            (( Integer ) defaultValueToAssign).toString() );
			    }
			    else {
			        
			        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			                "(Settings.validateOptionalSetting[Integer]) " +
			                "\nInvalid defaultValue-type encountered when validating the " +
			                "setting '" + settingDescription + "'." );
			    }
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("Long")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( !( strTmpValidationVar == null || 
		            strTmpValidationVar.length() < 1 )) {

		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
			    longTmpValidationVar = Long.parseLong( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
		    else if ( defaultValueToAssign != null ) { 
		        		        
		        if ( strClassName.equals( "Long" )) { 
		        
			        validatedProcessParameters.setProperty( 
				            settingName, (( Long ) defaultValueToAssign).toString() );
			    }
			    else {
			        
			        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			                "(Settings.validateOptionalSetting[Long]) " +
			                "Invalid defaultValue-type encountered when validating the " +
			                "setting '" + settingDescription + "'." );
			    }
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("Double")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    if ( !( strTmpValidationVar == null || 
		            strTmpValidationVar.length() < 1 )) {

		        // Try to assign the provided value. If the data types don't match
		        // we trap the error and tell the user to fix it.
			    dblTmpValidationVar = Double.parseDouble( strTmpValidationVar );
			    validatedProcessParameters.setProperty( 
			            settingName, strTmpValidationVar );
		    }
		    else if ( defaultValueToAssign != null ) {
		        if ( strClassName.equals( "Double" )) { 
		        
			        validatedProcessParameters.setProperty( 
				            settingName, (( Double ) defaultValueToAssign).toString() );
			    }
			    else {
			        
			        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			                "(Settings.validateOptionalSetting[Double]) " +
			                "Invalid defaultValue-type encountered when validating the " +
			                "setting '" + settingDescription + "'." );
			    }
		    }
	    }
	    else if ( settingDataType.equalsIgnoreCase("String")) {
	        
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    // If the settings file doesn't contain a line with the parameter, then
		    // this setting can be null.
		    if ( strTmpValidationVar == null )
		        strTmpValidationVar = BANJO.BANJO_NOVALUESUPPLIED_STRING;
		    
		    if ( additionalInfo == null ) {
	            
	            // This ensures that all string input is validated against the set
	            // of possible values (any mandatory setting won't make sense if
	            // it can't supply such a set of values)
	            throw new BanjoException( BANJO.ERROR_BANJO_DEV_INPUT,
	                    "\nThere are no valid values supplied for the setting '" +
	                    settingName +"'!" );
	        }
	        
	        try {
		        Set validValues = new HashSet();

		        validValues = (Set) additionalInfo;
		        if ( validValues.contains( strTmpValidationVar ) || 
		                ( validValues.contains( BANJO.BANJO_FREEFORMINPUT ) )) {
		            
		            validatedProcessParameters.setProperty( 
				            settingName, strTmpValidationVar );
		        }
		        else {
		            
		            // Since this is an optional setting, we don't throw an
		            // exception, but instead set the value to a default constant
		            if ( defaultValueToAssign != null ) {
			            
		                if ( strClassName.equals( "String" ) ) { 
					        
					        validatedProcessParameters.setProperty( 
						            settingName, ( String ) defaultValueToAssign );
					    }
					    else {
					        
					        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
					                "(Settings.validateOptionalSetting[String]) " +
					                "Invalid defaultValue-type encountered when " +
					                "validating the setting '" + 
					                settingDescription + "'." );
					    }
			        }
			        else {
			            
			            validatedProcessParameters.setProperty( 
					            settingName, strTmpValidationVar );
			        }
		        }
	        }
			catch ( Exception e ) {
								    
				throw new BanjoException( 
				        BANJO.ERROR_BANJO_DEV_INPUT,
				        "\nCould not validate the setting '" + 
				        settingName + "' - maybe the valid setting values were " +
				        "not supplied by the developer?");
			}
	    }
	    else if ( settingDataType.equalsIgnoreCase("StringList")) {

		    String item;
		    String[] validatedItems;
		    String validatedList = "";
		    String defaultString = "";
		    
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    // Note that the "additional" info (the acceptable values in this case)
		    // will be applied to each item in the list (they each can be different,
		    // but need to be from the supplied set of values, unless freeFormInput
		    // is specified)
		    if ( additionalInfo == null ) {
	            
	            // This ensures that all string input is validated against the set
	            // of possible values (any mandatory setting won't make sense if
	            // it can't supply such a set of values)
	            throw new BanjoException( BANJO.ERROR_BANJO_DEV_INPUT,
	                    "\nThere are no valid values supplied for the setting '" +
	                    settingName +"'!" );
	        }
		    
		    if ( defaultValueToAssign != null ) {
	            
                if ( strClassName.equals( "String" ) ) { 
			        
                    defaultString = ( String ) defaultValueToAssign;
			    }
			    else {
			        
			        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			                "(Settings.validateOptionalSetting[String]) " +
			                "Invalid defaultValue-type encountered when " +
			                "validating the setting '" + 
			                settingDescription + "'." );
			    }
	        }
		    
		    StringTokenizer itemTokenizer = 
		        new StringTokenizer( strTmpValidationVar, 
		                BANJO.DEFAULT_LISTDELIMITER );
		    int itemCount = itemTokenizer.countTokens();
		    validatedItems = new String[ itemCount ];
		    
		    for ( int i=0; i<itemCount; i++ ) {
		        
		        item = itemTokenizer.nextToken().trim();
			    
		        try {
			        Set validValues = new HashSet();
	
			        validValues = (Set) additionalInfo;
			        if ( validValues.contains( item ) || 
			                ( validValues.contains( BANJO.BANJO_FREEFORMINPUT ) )) {
			            
			            validatedItems[i] = item;
			        }
			        else {
			            
			            // Since this is an optional setting, we don't throw an
			            // exception, but instead set the value to a default constant
			            if ( defaultValueToAssign != null ) {
				            
			                validatedItems[i] = defaultString;
				        }
				        else {
				            
				            validatedItems[i] = BANJO.BANJO_NOVALUESUPPLIED_STRING;
				        }
			        }
		        }
				catch ( Exception e ) {
									    
					throw new BanjoException( 
					        BANJO.ERROR_BANJO_DEV_INPUT,
					        "\nCould not validate the setting '" + 
					        settingName + "' - maybe the valid setting values were " +
					        "not supplied by the developer?");
				}
		    }
		    if ( itemCount > 0 ) {

			    validatedList = validatedItems[0];
			    for ( int i=1; i<itemCount; i++ ) {
			        
			        validatedList += BANJO.DEFAULT_LISTDELIMITER + validatedItems[i];
			    }
		    }
		    else {
		        
		        validatedList = BANJO.BANJO_NOVALUESUPPLIED_STRING;
		    }
		    
		    validatedProcessParameters.setProperty( 
		            settingName, validatedList );
	    }
	    else if ( settingDataType.equalsIgnoreCase("IntegerList")) {

		    String item;
		    String[] validatedItems;
		    String validatedList = "";
		    String defaultString = "";
		    
		    strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
		    
		    // Note that the "additional" info (the acceptable values in this case)
		    // will be applied to each item in the list (they each can be different,
		    // but need to be from the supplied set of values, unless freeFormInput
		    // is specified)
//		    if ( additionalInfo == null ) {
//	            
//	            // This ensures that all string input is validated against the set
//	            // of possible values (any mandatory setting won't make sense if
//	            // it can't supply such a set of values)
//	            throw new BanjoException( BANJO.ERROR_BANJO_DEV_INPUT,
//	                    "\nThere are no valid values supplied for the setting '" +
//	                    settingName +"'!" );
//	        }
		    
		    if ( defaultValueToAssign != null ) {
	            
                if ( strClassName.equals( "Integer" ) ) { 
			        
                    // No default value assignable for the list
                    
			    }
			    else {
			        
			        throw new BanjoException( BANJO.ERROR_BANJO_DEV,
			                "(Settings.validateOptionalSetting[String]) " +
			                "Invalid defaultValue-type encountered when " +
			                "validating the setting '" + 
			                settingDescription + "'." );
			    }
	        }
		    
		    StringTokenizer itemTokenizer = 
		        new StringTokenizer( strTmpValidationVar, 
		                BANJO.DEFAULT_LISTDELIMITER );
		    int itemCount = itemTokenizer.countTokens();
		    validatedItems = new String[ itemCount ];
		    
		    for ( int i=0; i<itemCount; i++ ) {
		        
		        item = itemTokenizer.nextToken().trim();
			    
		        try {

				    intTmpValidationVar = Integer.parseInt( item );
				    validatedItems[i] = item;
		        }
				catch ( Exception e ) {
									    
					throw new BanjoException( 
					        BANJO.ERROR_BANJO_DEV_INPUT,
					        "\nCould not validate the setting '" + 
					        settingName + "' - the value of item " + (i+1) + 
					        " (='" + item +
					        "') needs to be an integer." +
					        "\n(Supplied " + settingName + 
					        "='" + strTmpValidationVar + "')." );
				}
		    }
		    validatedList = validatedItems[0];
		    for ( int i=1; i<itemCount; i++ ) {
		        
		        validatedList += BANJO.DEFAULT_LISTDELIMITER + validatedItems[i];
		    }
		    
		    validatedProcessParameters.setProperty( 
		            settingName, validatedList );
	    }
	    else if ( settingDataType.equalsIgnoreCase( "discretizationExceptions" ) ) {
	        
	        // This is a special purpose validation that only applies to a list of inputs
	        // of the form <variableIndex>:<Letter><Numeral>, describing the exceptions
	        // to the discretization policy
	        	        
	        strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
	        
	        // If no value is supplied by the user, we default to "no discretization"
	        if ( strTmpValidationVar == null || strTmpValidationVar.equals("") ) {

		            validatedProcessParameters.setProperty( 
				            settingName, BANJO.BANJO_NOVALUESUPPLIED_STRING );
		            return;
	        }

	        // Now do some basic validation: we split the list into individual items,
	        // then make sure that each item has the required format
	        
		    StringTokenizer exceptionsTokenizer = new StringTokenizer( 
		            strTmpValidationVar, BANJO.EXCEPTIONSDELIMITER );
		    int exceptionsCount = exceptionsTokenizer.countTokens();
		    String nextException;
		    String exceptionType;
		    String strExceptionChoice;
		    int exceptionPoints;
	        int varIndex;
	        // The variable count has been validated earlier
	        int tmpVarCount = Integer.parseInt( 
	                validatedProcessParameters.getProperty( 
	                BANJO.SETTING_VARCOUNT ) );
	        String[] exceptionTracker = new String[tmpVarCount];
	        for ( int i=0; i< tmpVarCount; i++ ) exceptionTracker[i] = "";
		    
		    for ( int exception=0; exception<exceptionsCount; exception++ ) {
		        
		        nextException = exceptionsTokenizer.nextToken().trim();
		        StringTokenizer exceptionItemTokenizer = new StringTokenizer(
		                nextException, BANJO.EXCEPTIONITEMDELIMITER );
		        try {
		            
			        varIndex = Integer.parseInt( 
			                exceptionItemTokenizer.nextToken().trim() ) - 
			                BANJO.CONFIG_DISCRETIZATIONSTARTINDEX;
			        if ( exceptionTracker[varIndex] != "" ) {
			            
			            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION, 
			            	"The variable index ('" + varIndex +
			            	"') of the discretization exception " +
			            	"'" + nextException + "' " +
	                    	"\nmatches the index of the already specified exception '" +
	                    	exceptionTracker[varIndex] + "'." );
			        }
			        exceptionTracker[varIndex] = nextException;
		        }
		        catch ( BanjoException e ) {
		            
		            throw new BanjoException( e );
		        }
		        catch ( Exception e ) {
		            
		            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION, 
		                    "The discretization exception '" + nextException +
		                    "' needs to specify the variable index as integer." );
		        }
		        
		        exceptionType = exceptionItemTokenizer.nextToken().trim();
		        // Take into account that Banjo can be configured to let the user start
		        // their variable indexes at 0 or at 1 via the internal constant
		        // BANJO.CONFIG_DISCRETIZATIONSTARTINDEX
		        if ( varIndex < BANJO.CONFIG_DISCRETIZATIONSTARTINDEX ||
		              varIndex >= tmpVarCount + BANJO.CONFIG_DISCRETIZATIONSTARTINDEX ) {
		            
		            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
		                    "The variable index ('" + varIndex +
		                    "') as specified for the discretization exception '" +
		                    nextException + "'" +
		                    "\nneeds to lie within the variable range " +
		                    "(namely, between " + 
		                    BANJO.CONFIG_DISCRETIZATIONSTARTINDEX + " and " +
		                    ( tmpVarCount-1 + BANJO.CONFIG_DISCRETIZATIONSTARTINDEX ) +
		                    ") of the underlying problem." );
		        }
		        
		        Set validValues = new HashSet();
		        validValues = (Set) additionalInfo;
		        
		        
		        
		        if ( exceptionType.equalsIgnoreCase( BANJO.UI_DISCRETIZATIONNONE )) {
		            
		            // Add the "trimmed" version of the entry to the validated entry
		            
		        }
		        else {
		            
		            if ( ( exceptionType.length() != 
	            		BANJO.UI_DISCRETIZATIONBYQUANTILE.length()+1 || 
	            		exceptionType.length() != 
	                        BANJO.UI_DISCRETIZATIONBYINTERVAL.length()+1 ) || 
	 	               !validValues.contains( exceptionType.substring( 
	 	                       0, exceptionType.length()-1 ) ) ) {
			            
			            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION,
			                    "\nThe supplied value ('" + exceptionType +
			                    "') as part of the setting '" +
			                    settingName + "' is not valid: " +
			                    "\nIt needs to be of the form 't#', " +
			                    "where the discretization type t is either '" +
			                    BANJO.UI_DISCRETIZATIONBYQUANTILE + "' (quantile discr.) or '" +
			                    BANJO.UI_DISCRETIZATIONBYINTERVAL + "' (value discr.)," +
			                    "\nand # is a single digit representing " +
			                    "the number of discretization points " +
			                    "for the selected discretization." );
			        }
		            
		            strExceptionChoice = exceptionType.substring(
		                    0, exceptionType.length()-1 );
		            try {
		                
			            exceptionPoints = Integer.parseInt( exceptionType.substring( 
			                    exceptionType.length()-1, exceptionType.length()) );
		            }
			        catch ( Exception e ) {
			            
			            throw new BanjoException( BANJO.ERROR_INVALID_DISCRETIZATION, 
			                    "The discretization exception '" + exceptionType +
			                    "' needs to specify the number of discretization " +
			                    "points as integer." );
			        }
		            
			        // Add the "trimmed" version of the entry to the validated entry
			        
		        }
		    }
	        
	    }
		else if ( settingDataType.equalsIgnoreCase( "discretizationPolicy" ) ) {
	        
	        // This is a special purpose validation that only applies to input
	        // of the form <Letter><Numeral>, describing the discretization policy
	        	        
	        strTmpValidationVar = rawInitialProcessParameters.getProperty(
		            settingName );
	        
	        if ( strTmpValidationVar == null || strTmpValidationVar.equals("") ||
	             strTmpValidationVar.equalsIgnoreCase( BANJO.UI_DISCRETIZATIONNONE ) ) {

	            validatedProcessParameters.setProperty( 
			            settingName, BANJO.UI_DISCRETIZATIONNONE );

	            validatedProcessParameters.setProperty( 
			            BANJO.DATA_DEFAULTDISCRETIZATIONCHOICE, 
			            BANJO.UI_DISCRETIZATIONNONE );
	            
	            validatedProcessParameters.setProperty( 
			            BANJO.DATA_DEFAULTDISCRETIZATIONPOINTS, 
			            Integer.toString( BANJO.DEFAULT_DISCRETIZATIONPOINTS ) );
	            
	            return;
	        }
            
            Set validValues = new HashSet();
        	validValues = (Set) additionalInfo;
        	
            // all other choices
            if ( ( strTmpValidationVar.length() != 
                		BANJO.UI_DISCRETIZATIONBYQUANTILE.length()+1 || 
                   strTmpValidationVar.length() != 
                       BANJO.UI_DISCRETIZATIONBYINTERVAL.length()+1 ) || 
	               !validValues.contains( strTmpValidationVar.substring( 
	                       0, strTmpValidationVar.length()-1 ) ) ) {
        
                throw new BanjoException( BANJO.ERROR_GENERAL_USERINPUT,
	                    "\nThe supplied value ('" + strTmpValidationVar +
	                    "') for the setting '" +
	                    settingName +"' is not valid: " +
	                    "\nIt needs to be of the form 't#', " +
	                    "where the discretization type t is either '" +
	                    BANJO.UI_DISCRETIZATIONBYQUANTILE + "' (quantile discr.) or '" +
	                    BANJO.UI_DISCRETIZATIONBYINTERVAL + "' (value discr.)," +
	                    "\nand # is a single digit representing " +
	                    "the number of discretization points " +
	                    "for the selected discretization." );
            }
            

            validatedProcessParameters.setProperty( 
		            settingName, strTmpValidationVar );
            
            String defaultDiscretizationType = strTmpValidationVar.substring( 
                    0, strTmpValidationVar.length()-1 );

            String strDefaultDiscretizationPoints = strTmpValidationVar.substring( 
                    strTmpValidationVar.length()-1,
                    strTmpValidationVar.length());
            try {
                
	            int defaultDiscretizationPoints = Integer.parseInt( 
	                    strDefaultDiscretizationPoints );
            }
            catch ( Exception e ) {
			    
				throw new BanjoException( 
				        BANJO.ERROR_GENERAL_USERINPUT,
				        "\nCould not validate the setting '" + 
				        settingName + "': discretization points (" +
				        strDefaultDiscretizationPoints +
				        ") need to be an integer.");
			}

            validatedProcessParameters.setProperty( 
		            BANJO.DATA_DEFAULTDISCRETIZATIONCHOICE, 
		            defaultDiscretizationType );
            validatedProcessParameters.setProperty( 
		            BANJO.DATA_DEFAULTDISCRETIZATIONPOINTS, 
		            strDefaultDiscretizationPoints );
	    }
	}

	private String errorMessageFieldNotFound( 
	        String dataFieldWithNumberError, String settingName ) {
	    
	    return "\nThe entry for the setting '" +
		    dataFieldWithNumberError +
		    "' (" + settingName +
		    ") is required,\nbut could not be found in the settings file.";
	}

	
	// -----------------------------------------
	// Access functions to individual parameters
	// -----------------------------------------
	
	// Use the UnValidated parameters with caution! 
	public String getUnValidatedProcessParameter(String parameterName) {
		
		return rawInitialProcessParameters.getProperty(
		        parameterName);
	}
	
	// Validated data access
	public String getValidatedProcessParameter(String parameterName) {
		
		return validatedProcessParameters.getProperty( 
		        parameterName);
	}
	public void setValidatedProcessParameter(String parameterName, 
	        String parameterValue ) {
		
	    validatedProcessParameters.setProperty( 
	            parameterName, parameterValue);
	}	    
	    
	// Dynamic data: generally data used by core classes in the implementation
	// of a given search strategy
	public String getDynamicProcessParameter(String parameterName) {
		
		return dynamicProcessParameters.getProperty( 
		        parameterName);
	}
	public void setDynamicProcessParameter(String parameterName, 
	        String parameterValue ) {
		
		dynamicProcessParameters.setProperty(
		        parameterName, parameterValue);
	}
	
	/**
	 * @return Returns the dynamicProcessParameters.
	 */
	public Properties getDynamicProcessParameters() {
		return dynamicProcessParameters;
	}
	// Note: DON'T return the rawInitialProcessParameters as an entire set.
	// Instead use the validatedProcessParameters!!
	public Properties getValidatedProcessParameters() {
		return validatedProcessParameters;
	}
	/**
	 * @return Returns the validatedProcessParameters.
	 */
	public Properties getStaticProcessParameters() {
		return validatedProcessParameters;
	}
    /**
     * @return Returns the highScoreStructureSet.
     */
    public TreeSet getHighScoreStructureSet() {
        return highScoreStructureSet;
    }
    /**
     * @param highScoreStructureSet The highScoreStructureSet to set.
     */
    public void setHighScoreStructureSet(TreeSet highScoreStructureSet) {
        this.highScoreStructureSet = highScoreStructureSet;
    }
	/**
	 * @param objectToAdd The object to add to the generalProcessDataStorage set.
	 */
	public void addToGeneralProcessDataStorage( Object objectToAdd ) {
		generalProcessDataStorage.add( objectToAdd );
	}
	/**
	 * @return Returns the generalProcessDataStorage.
	 */
	public Set getGeneralProcessDataStorage() {
		return generalProcessDataStorage;
	}
	/**
	 * @return Returns the size of the generalProcessDataStorage.
	 */
    public int getStorageSize() {
		return generalProcessDataStorage.size();
    }

	/**
	 * @return Returns the observations.
	 */
	public final Observations getObservations() {
		return observations;
	}
}
