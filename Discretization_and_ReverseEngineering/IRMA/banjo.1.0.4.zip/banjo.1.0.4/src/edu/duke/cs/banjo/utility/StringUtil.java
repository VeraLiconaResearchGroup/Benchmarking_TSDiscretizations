/*
 * Created on Apr 2, 2004
 * 
 * This file is part of Banjo (Bayesian	Network Inference with Java	Objects)
 * edu.duke.cs.banjo
 * Banjo is licensed from Duke University.
 * Copyright (c) 2005 by Alexander J. Hartemink.
 * All rights reserved.
 * 
 * License Info:
 * 
 * For non-commercial use, may be licensed under a Non-Commercial Use License.
 * For commercial use, please contact Alexander J. Hartemink or the Office of
 *   Science and Technology at Duke University. More information available at
 *   http://www.cs.duke.edu/~amink/software/banjo
 * 
 */
package edu.duke.cs.banjo.utility;

import java.util.*;

/**
 * Contains a collection of general purpose string-related code.
 * 
 * <p><strong>Details:</strong> <br>
 * 
 * 
 * <p><strong>Change History:</strong> <br>
 * Created on Apr 2, 2004
 * 
 * @author Jurgen Sladeczek (hjs) <br>
 * For the latest info, please visit www.cs.duke.edu.
 *
 */
public class StringUtil {
	
    // Trivial conversion constants
    private static final int MILLISECSPERSECOND = 1000;
    private static final int MILLISECSPERMINUTE = 60*1000;
    private static final int MILLISECSPERHOUR = 60*60*1000;
    private static final int MILLISECSPERDAY = 24*60*60*1000;
     
	StringUtil(){};
	
	// ----------------------------------------------------------------------------
	// TODO: Change all functions to use StringBuffer for performance
	// (low priority, though - used only internally for trace, not within regular search)
	
	// Fills in blank spaces for creating formatted output:
	public static String fillSpaces( final String startString, 
	        final int fillLength) {
		String fillString;
		String blanks = "                                      " +
				"                              ";
		
		if ( startString.length() <= fillLength)  {
		    
		    fillString = new String( 
		            blanks.substring(0, fillLength - startString.length()));
		    return new String( startString + fillString );
		}
		else
		    return new String( startString );
	}
	
	public static String fillSpacesLeft( final String startString, 
	        final int fillLength) {
		String fillString;
		String blanks = "                                      " +
				"                              ";
		
		if ( startString.length() <= fillLength)  {
		    
		    fillString = new String( 
		            blanks.substring(0, fillLength - startString.length()));
		    return new String( fillString + startString );
		}
		else
		    return new String( startString );
	}

	// Removes comments at the end of a line in the settings file
	public static String removeTrailingComment( final String settingToProcess ) {
	    
	    String processedString = new String( settingToProcess );
	    int charPosition = processedString.indexOf( BANJO.DEFAULT_COMMENTCHARACTER );
	    
	    if ( charPosition >= 0 ) 
	        processedString = processedString.substring( 0, charPosition );
	    
	    return processedString;
	}
	
	public static StringBuffer formatRightLeftJustified( 
	        String prefix, String displayItem, String displayItemValue, 
	        String separator, int lineLength ) {
	    
	    StringBuffer formattedString = new StringBuffer();
		String blankSpaces = "                                                      " +
				"                                                                   ";

		formattedString.append( prefix );
		formattedString.append( displayItem );
		int subLength = lineLength - displayItem.length() 
        		- displayItemValue.length() - prefix.length();
		if ( subLength > 0 && subLength < blankSpaces.length() ) {
		    
			formattedString.append( blankSpaces.substring( 0, subLength ));
			formattedString.append( displayItemValue );
		}
		else {
		    
		    // In this case the length of displayItemValue is to long
		    // for the string to fit on a single line. If the separator
		    // is specified, we try to split the string
		    
		    if ( separator == null || separator.length() < 1 ) {
		        
			    formattedString.append( "  " );
				formattedString.append( displayItemValue );
		    }
		    else {
		        
		        formattedString.append( "  " );
				formattedString.append( displayItemValue );
		    }
		}
		    
		        
	    return formattedString;
	}

	public static StringBuffer listSettings( final Properties settingsToList ) {
		
		//loop through the set of properties:
		Set params = settingsToList.keySet();
		Iterator iter = params.iterator();
		String strNextProperty;
		StringBuffer settingsString = 
		    new StringBuffer( BANJO.BUFFERLENGTH_STAT );
		int settingsCount = 0;
		
	    settingsString.append( "Summary of initialSettings as loaded: \n" );
	    settingsString.append( "===================================== \n" );
		while (iter.hasNext()) {
			strNextProperty = (String) iter.next();
			
			settingsString.append( strNextProperty );
			settingsString.append( " = " );
			settingsString.append( StringUtil.fillSpaces(strNextProperty, 28) );
			settingsString.append( "'" );
			settingsString.append( settingsToList.getProperty(strNextProperty) );
			settingsString.append( "'" );
			settingsString.append( "\n" );
			settingsCount++;
		}
		
		settingsString.append( settingsCount );
		settingsString.append( " Loading of initialSettings complete.\n" );
				
	    settingsString.append( "\n" );
	    settingsString.append( "\n" );
	
		return settingsString;
	}

	// Utility function for quick concatenation of the name of the class in which
	// we are (works properly for subclasses)
	public static String getClassName( Object someObj ) {

		Object classObj = someObj.getClass();
	    String strClassName = new String( classObj.toString() );

		strClassName = strClassName.substring(strClassName.lastIndexOf(".")+1);

	    return strClassName;
	}

	// Trivial helper function for quick trace output
	public static String arrayAsString( int[] intArray ) {
	    
	    String strArray = "";
	    
	    for (int i=0; i< intArray.length; i++ )
	        strArray += intArray[i] + " ";
	    
	    return strArray;
	}
	
    public static StringBuffer getBasicJobSignature() {
        
        StringBuffer jobSignature = new StringBuffer(200);

        // Application-specific data (doesn't require processData access)
        jobSignature.append("\n" + BANJO.APPLICATION_NAME +
        		" Information  ");
        jobSignature.append("\n-----------------  ");
        jobSignature.append("\nVersion Number:  ");
        jobSignature.append( formatFeedback(
				BANJO.APPLICATION_VERSIONNUMBER ) );
        jobSignature.append("\nVersion Date:    ");
        jobSignature.append( formatFeedback(
				BANJO.APPLICATION_VERSIONDATE ) );
        jobSignature.append("\nDescription:     ");
        jobSignature.append( formatFeedback(
				BANJO.APPLICATION_VERSIONDESCRIPTION ));
        
        return jobSignature;
    }
    
    public static StringBuffer getJobSignature( Settings processData ) {
        
        StringBuffer jobSignature = new StringBuffer(200);

        // Application-specific data
        jobSignature.append( getBasicJobSignature() );

        // User-specific data
        jobSignature.append("\n\nJob Information  ");
        jobSignature.append("\n---------------  ");
               jobSignature.append("\nProject:  ");
        jobSignature.append( formatFeedback(
                processData.getValidatedProcessParameter(
                        BANJO.SETTING_PROJECT ) ));
        jobSignature.append("\nUser:     ");
        jobSignature.append( formatFeedback(
                processData.getValidatedProcessParameter(
                        BANJO.SETTING_USER ) ));
        jobSignature.append("\nDataset:  ");
        jobSignature.append( formatFeedback(
                processData.getValidatedProcessParameter(
                        BANJO.SETTING_DATASET) ));
        jobSignature.append("\nNotes:    ");
        jobSignature.append( formatFeedback(
                processData.getValidatedProcessParameter(
                        BANJO.SETTING_NOTES) ));
 
        return jobSignature;
    }
    // Almost trivial function to combine code in writing the job signature 
    private static String formatFeedback(String userInputValue) {
        
        if ( userInputValue == null ) 
            return "(not available)";
        else {
            
            // Could do some more if desired, but for now:
            return userInputValue;
        }
    }
        
    // Formatting of the elapsed time, based on some parameters:
    // - decimalsToDisplay controls how many decimals are left after we appply some
    //   rounding
    // - formatFlag determines whether we express the result in [hrs only], [min only],
    //   ..., and a mixed format that folds the elapsed time into the display format.
    // - elapsedTime is provided by the caller in milliseconds
	public static StringBuffer formatElapsedTime( 
	        long elapsedTime, int decimalsToDisplay, int formatFlag ) {
	    
		StringBuffer formattedElapsedTime = new StringBuffer(40);
		double dblElapsedTime;
		int decimalFactor = 1;
		
		if ( elapsedTime < 0 ) elapsedTime = 0;
		
		if ( decimalsToDisplay < 0 ) {
		    decimalsToDisplay = BANJO.OPTION_NUMBEROFDECIMALSINTIMEDISPLAY;
		}
		
		if ( decimalsToDisplay > 0 ) {
		    for (int i=0; i<decimalsToDisplay; i++) decimalFactor *=10;
		}
		
		if ( formatFlag == BANJO.OPTION_TIMEFORMAT_MIXED  ) {
			
		    // Note: the cutoffs for using a different format are somewhat arbitrary
			if ( elapsedTime > BANJO.DEFAULT_DISPLAY_IN_HOUR * MILLISECSPERHOUR ) {
			    
				// Display time in hours
			    dblElapsedTime = Math.round( decimalFactor * 
			            elapsedTime/MILLISECSPERHOUR );
			    dblElapsedTime = dblElapsedTime / decimalFactor;
			    if ( decimalsToDisplay == 0 ) 
			        dblElapsedTime = Math.round( dblElapsedTime );
				formattedElapsedTime.append( dblElapsedTime );
				formattedElapsedTime.append( " " );
				formattedElapsedTime.append( BANJO.DEFAULT_TIME_HOURS );
			}
			else if ( elapsedTime > BANJO.DEFAULT_DISPLAY_IN_MINUTES * 
			        MILLISECSPERMINUTE ) {
			    
				// Display time in minutes
			    dblElapsedTime = Math.round( decimalFactor * 
			            elapsedTime/MILLISECSPERMINUTE );
			    dblElapsedTime = dblElapsedTime / decimalFactor;
			    if ( decimalsToDisplay == 0 ) 
			        dblElapsedTime = Math.round( dblElapsedTime );
				formattedElapsedTime.append( dblElapsedTime );
				formattedElapsedTime.append( " " );
				formattedElapsedTime.append( BANJO.DEFAULT_TIME_MINUTES );
			}
			else if ( elapsedTime > BANJO.DEFAULT_DISPLAY_IN_SECONDS * 
			        MILLISECSPERSECOND ) {
			    
				// Display time in seconds
			    dblElapsedTime = Math.round( decimalFactor * 
			            elapsedTime/MILLISECSPERSECOND );
			    dblElapsedTime = dblElapsedTime / decimalFactor;
			    if ( decimalsToDisplay == 0 ) 
			        dblElapsedTime = Math.round( dblElapsedTime );
				formattedElapsedTime.append( dblElapsedTime );
				formattedElapsedTime.append( " " );
				formattedElapsedTime.append( BANJO.DEFAULT_TIME_SECONDS );
			}
			else {
			    
				// Display time in ms for times <= N seconds (see previous if-condition)
				formattedElapsedTime.append( elapsedTime );
				formattedElapsedTime.append( " " );
				formattedElapsedTime.append( BANJO.DEFAULT_TIME_MILLISECS );
			}
		}
		else if ( formatFlag == BANJO.OPTION_TIMEFORMAT_IN_H ) {		    

		    dblElapsedTime = Math.round( decimalFactor * 
		            elapsedTime/MILLISECSPERHOUR );
		    dblElapsedTime = dblElapsedTime / decimalFactor;
			formattedElapsedTime.append( dblElapsedTime );
			formattedElapsedTime.append( " " );
			formattedElapsedTime.append( BANJO.DEFAULT_TIME_HOURS );
		}
		else if ( formatFlag == BANJO.OPTION_TIMEFORMAT_IN_M ) {		    
		    
		    dblElapsedTime = Math.round( decimalFactor * 
		            elapsedTime/MILLISECSPERMINUTE );
		    dblElapsedTime = dblElapsedTime / decimalFactor;
			formattedElapsedTime.append( dblElapsedTime );
			formattedElapsedTime.append( " " );
			formattedElapsedTime.append( BANJO.DEFAULT_TIME_MINUTES );
		}
		else if ( formatFlag == BANJO.OPTION_TIMEFORMAT_IN_S ) {
			
		    dblElapsedTime = Math.round( decimalFactor * 
		            elapsedTime/MILLISECSPERSECOND );
		    dblElapsedTime = dblElapsedTime / decimalFactor;
			formattedElapsedTime.append( dblElapsedTime );
			formattedElapsedTime.append( " " );
			formattedElapsedTime.append( BANJO.DEFAULT_TIME_SECONDS );
		}
		else if ( formatFlag == BANJO.OPTION_TIMEFORMAT_IN_MS ) {

			formattedElapsedTime.append( elapsedTime );
			formattedElapsedTime.append( " " );
			formattedElapsedTime.append( BANJO.DEFAULT_TIME_MILLISECS );
		}
		else {

		    // default format in ms?
			formattedElapsedTime.append( elapsedTime );
			formattedElapsedTime.append( " " );
			formattedElapsedTime.append( BANJO.DEFAULT_TIME_MILLISECS );
		}
		
		return formattedElapsedTime;
	}
	
	public static double displayWithFixedDecimals( final double numberToFormat,
	        final int numberOfDecimals ) {
	    
	    double formattedNumber;
	    long tmpFactor = 1;
	    for ( int i=0; i<numberOfDecimals; i++ ) tmpFactor *= 10;
	    
	    formattedNumber = Math.round( tmpFactor * numberToFormat );
	    formattedNumber /= tmpFactor;

	    return formattedNumber;
	}
	
	// Useful for testing/debugging
	public static String listNodes( int[][] nodeList ) {
	    
	    String strNodeList;
	    
	    if ( nodeList.length > 0 ) {
	        
		    strNodeList = new String( Integer.toString( nodeList[0][0] ));
		    
		    for (int i = 1; i<nodeList.length; i++ ) {
		        strNodeList = strNodeList + ",  " + nodeList[i][0];
		    }
	    }
	    else {
	        
	        strNodeList = "none";
	    }
	    
	    return strNodeList;	    
	}
}
